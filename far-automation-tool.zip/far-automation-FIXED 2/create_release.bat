@echo off
echo Exporting clean project ZIP without .git directory...
git archive --format=zip HEAD -o far-automation-release.zip
if %ERRORLEVEL% equ 0 (
    echo.
    echo Successfully created far-automation-release.zip!
    echo This zip is safe to share and does not contain any Git history or personal emails.
) else (
    echo.
    echo Error creating zip. Make sure you have committed your changes first.
)
