import os
import re
import logging
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import polars as pl

from .excel_parser import parse_balance_sheet, parse_profit_loss, parse_notes, clear_workbook_cache
from .cache_manager import CacheManager
from .cpp_bridge import compute_variances, compute_ratios_from_raw
from .verify_engine import verify_and_finalize
from .note_mapper import map_bs_to_notes

logger = logging.getLogger(__name__)

cache_mgr = CacheManager()

# Bump this whenever the parsing/extraction logic changes so old on-disk caches
# (keyed only by input-file content) are invalidated and data is re-parsed.
CACHE_VERSION = 'v17-sectioned-ratios+NA-2026-06-19'


def _norm_note(note_str):
    """Normalise a note reference ("Note 3", "No. 3", "3") to bare alphanumerics
    so values from the BS/PL and the note sheets can be matched."""
    if not note_str:
        return ""
    s = str(note_str).upper()
    s = re.sub(r'NOTE', '', s)
    s = re.sub(r'NO\.?', '', s)
    s = re.sub(r'[^A-Z0-9]', '', s)
    return s

def process_file_task(task_type, filepath, **kwargs):
    try:
        if not task_type or not filepath:
            raise ValueError(f"Invalid task_type={task_type} or filepath={filepath}")
        
        if task_type == 'bs':
            result = parse_balance_sheet(filepath)
            if result is None:
                raise ValueError(f"parse_balance_sheet returned None for {filepath}")
            return 'bs', result
        elif task_type == 'pl':
            result = parse_profit_loss(filepath)
            if result is None:
                raise ValueError(f"parse_profit_loss returned None for {filepath}")
            return 'pl', result
        elif task_type == 'notes':
            result = parse_notes(filepath, **kwargs)
            if result is None:
                raise ValueError(f"parse_notes returned None for {filepath}")
            return 'notes', result
        else:
            raise ValueError(f"Unknown task_type: {task_type}")
    except Exception as e:
        logger.error(f"Error processing {task_type} from {filepath}: {e}", exc_info=True)
        return task_type, {'error': str(e)}

class DataEngine:
    def process_far_data(self, form_data, progress_callback=None):
        
        if not form_data or not isinstance(form_data, dict):
            raise ValueError("Invalid form data provided to DataEngine.process_far_data")

        if not form_data.get('bs_file') or not form_data.get('pl_file'):
            raise ValueError("Both 'bs_file' and 'pl_file' must be provided in form_data")

        if 'notes_files' not in form_data or form_data.get('notes_files') is None:
            form_data['notes_files'] = []

        if not form_data.get('notes_required', True):
            form_data['notes_files'] = []


        all_files = [form_data['bs_file'], form_data['pl_file']] + form_data['notes_files']
        cache_key = cache_mgr.generate_hash(
            all_files, {'rounding_unit': form_data['rounding_unit'],
                        'round_off': form_data.get('round_off', True),
                        'code': CACHE_VERSION})
        
        cached_result = cache_mgr.get(cache_key)
        if cached_result:
            if progress_callback: progress_callback(100, "Loaded instantly from Cache!")
            return cached_result
            
        if progress_callback: progress_callback(10, "Extracting Excel data in parallel...")
            
        results = {'notes': []}

        # Parsing is openpyxl/zip IO-bound, so threads (which release the GIL
        # during IO) give the speed-up without the pickling cost of processes.
        with ThreadPoolExecutor(max_workers=os.cpu_count() or 4) as executor:
            # 1. Process BS & PL first
            core_tasks = {
                executor.submit(process_file_task, 'bs', form_data['bs_file']): 'bs',
                executor.submit(process_file_task, 'pl', form_data['pl_file']): 'pl'
            }
            
            for i, future in enumerate(as_completed(core_tasks)):
                task_type = core_tasks[future]
                try:
                    result_val = future.result()
                    if result_val is None:
                        raise RuntimeError(f"Background worker returned None for task {task_type}")
                    res_type, data = result_val
                    if isinstance(data, dict) and 'error' in data:
                        logger.warning(f"Parse error for {res_type}: {data.get('error', 'unknown')}")
                        raise ValueError(f"Failed to parse {res_type.upper()}: {data.get('error')}")
                    results[res_type] = data
                except Exception as e:
                    logger.error("Task generated an exception: %s", e, exc_info=True)
                    raise
                if progress_callback: 
                    progress_callback(10 + int((i+1)/2*15), f"Processed {task_type.upper()}")
            
            # 2. Extract target notes (CY + PY totals) from BS/PL so the notes
            #    parser can pick each note's value column by matching that total.
            def _num(v):
                try:
                    return float(str(v if v not in (None, '-') else 0).replace(',', '').replace(' ', ''))
                except (TypeError, ValueError):
                    return 0.0
            target_notes = {}
            for r in results.get('bs', {}).get('data', []) + results.get('pl', {}).get('data', []):
                n = _norm_note(r.get('note', ''))
                if n:
                    e = target_notes.setdefault(n, {'cy': 0.0, 'py': 0.0})
                    e['cy'] += _num(r.get('cy'))
                    e['py'] += _num(r.get('py'))
                    
            # 3. Process Notes files using target_notes
            note_tasks = {
                executor.submit(process_file_task, 'notes', nf, target_notes=target_notes): 'notes'
                for nf in form_data['notes_files']
            }
            
            for i, future in enumerate(as_completed(note_tasks)):
                try:
                    result_val = future.result()
                    if result_val is not None:
                        res_type, data = result_val
                        if not (isinstance(data, dict) and 'error' in data):
                            results['notes'].append(data)
                except Exception as e:
                    logger.error("Notes task exception: %s", e)
                if progress_callback: 
                    progress_callback(25 + int((i+1)/max(1, len(note_tasks))*15), "Processed NOTES")

        if progress_callback: progress_callback(50, "Applying Polars transformations...")

        clear_workbook_cache()

        bs_parsed = results.get('bs')
        pl_parsed = results.get('pl')
        
        notes_parsed_raw = results.get('notes', [])
        notes_parsed = {}
        notes_sheet_notes = {}
        notes_signatures = {}
        notes_footers = {}
        for nd in notes_parsed_raw:
            if isinstance(nd, dict):
                if 'notes' in nd:
                    notes_parsed.update(nd['notes'])
                if 'sheet_notes' in nd:
                    notes_sheet_notes.update(nd['sheet_notes'])
                if 'signatures' in nd:
                    notes_signatures.update(nd['signatures'])
                if 'footers' in nd:
                    notes_footers.update(nd['footers'])

        if not bs_parsed or 'data' not in bs_parsed or not pl_parsed or 'data' not in pl_parsed:
            raise ValueError("Failed to extract Balance Sheet or P&L data.")

        if not notes_parsed and form_data.get('notes_files'):
            actual_cy = bs_parsed.get('cy_year', 2025)
            actual_py = bs_parsed.get('py_year', 2024)
            for nf in form_data['notes_files']:
                try:
                    nd = parse_notes(nf, cy_year=actual_cy, py_year=actual_py)
                    if isinstance(nd, dict) and 'notes' in nd:
                        notes_parsed.update(nd['notes'])
                        notes_sheet_notes.update(nd.get('sheet_notes', {}))
                        notes_signatures.update(nd.get('signatures', {}))
                        notes_footers.update(nd.get('footers', {}))
                except Exception as e:
                    logger.error("Re-parse notes failed for %s: %s", nf, e)

        # Honor the rounding TOGGLE first: when the user disabled rounding the
        # values stay as-is (factor 1.0) regardless of the unit radio. Only when
        # rounding is enabled do we divide by the selected unit. (Previously the
        # factor came from the unit alone, so unchecking "Enable Rounding" still
        # divided by e.g. 100000 and the output was mislabeled "Actuals".)
        if not form_data.get('round_off', True):
            rounding_factor = 1.0
        else:
            rounding_factor = self._get_rounding_factor(form_data['rounding_unit'])

        df_bs = pl.DataFrame(bs_parsed['data']).lazy().with_columns([
            pl.col('cy').alias('cy_raw'),
            pl.col('py').alias('py_raw'),
            pl.col('cy').cast(pl.Float64, strict=False),
            pl.col('py').cast(pl.Float64, strict=False)
        ])
        df_pl = pl.DataFrame(pl_parsed['data']).lazy().with_columns([
            pl.col('cy').alias('cy_raw'),
            pl.col('py').alias('py_raw'),
            pl.col('cy').cast(pl.Float64, strict=False),
            pl.col('py').cast(pl.Float64, strict=False)
        ])
        
        df_bs = df_bs.with_columns([
            (pl.col('cy') / rounding_factor).alias('cy'),
            (pl.col('py') / rounding_factor).alias('py')
        ]).with_columns([
            pl.col('cy').alias('cy_actual'),
            pl.col('py').alias('py_actual')
        ])
        
        df_pl = df_pl.with_columns([
            (pl.col('cy') / rounding_factor).alias('cy'),
            (pl.col('py') / rounding_factor).alias('py')
        ]).with_columns([
            pl.col('cy').alias('cy_actual'),
            pl.col('py').alias('py_actual')
        ])

        cy_from_dt = datetime.strptime(form_data['cy_from_date'], '%Y-%m-%d').date()
        cy_to_dt = datetime.strptime(form_data['cy_to_date'], '%Y-%m-%d').date()
        py_from_dt = datetime.strptime(form_data['py_from_date'], '%Y-%m-%d').date()
        py_to_dt = datetime.strptime(form_data['py_to_date'], '%Y-%m-%d').date()
        
        cy_days = (cy_to_dt - cy_from_dt).days + 1
        py_days = (py_to_dt - py_from_dt).days + 1
        
        def _get_months(days):
            if days <= 0: return 0.0
            return 12.0 if days >= 365 else round(days / 30.4375, 1)
            
        cy_months = _get_months(cy_days)
        py_months = _get_months(py_days)
        
        cy_coverage = min(100.0, round((cy_days / 365.0) * 100.0, 1))
        py_coverage = min(100.0, round((py_days / 365.0) * 100.0, 1))
        
        cy_factor = 1.0
        py_factor = 1.0
        is_annualized = False
        annualization_msg = ""
        
        if form_data.get('auto_annualize', True) and cy_months != py_months:
            is_annualized = True
            if cy_months < py_months:
                cy_factor = 12.0 / cy_months if cy_months > 0 else 1.0
                annualization_msg = f"Normalized CY P&L values by factor {cy_factor:.3f} (Months: {cy_months})"
                df_pl = df_pl.with_columns([
                    (pl.col('cy') * cy_factor).alias('cy')
                ])
            else:
                py_factor = 12.0 / py_months if py_months > 0 else 1.0
                annualization_msg = f"Normalized PY P&L values by factor {py_factor:.3f} (Months: {py_months})"
                df_pl = df_pl.with_columns([
                    (pl.col('py') * py_factor).alias('py')
                ])
            logger.info(annualization_msg)

        if progress_callback: progress_callback(70, "Computing Variances & Ratios...")

        # Materialise each lazy frame exactly once (previously collected twice).
        bs_list = df_bs.collect().to_dicts()
        pl_list = df_pl.collect().to_dicts()
        
        for r in bs_list:
            if r.get('cy') is None and r.get('cy_raw') == '-': r['cy'] = '-'
            if r.get('py') is None and r.get('py_raw') == '-': r['py'] = '-'
            
        for r in pl_list:
            if r.get('cy') is None and r.get('cy_raw') == '-': r['cy'] = '-'
            if r.get('py') is None and r.get('py_raw') == '-': r['py'] = '-'
        
        bs_variances = compute_variances(bs_list)
        pl_variances = compute_variances(pl_list)

        ratio_results = compute_ratios_from_raw(bs_list, pl_list)

        # Engine 2 — independent verification + finalisation. Recomputes every
        # variance and ratio, cross-checks them, corrects derivable inconsistencies,
        # and reports any value-level disagreement. Non-fatal: a fault in the
        # verifier must never block report generation, so on error we keep Engine-1
        # values and record that verification was skipped.
        try:
            verified = verify_and_finalize(
                bs_variances, pl_variances,
                ratio_results.get('ratios', []),
                ratio_results.get('bs_summary', {}),
                ratio_results.get('pl_summary', {}),
            )
            bs_variances = verified['bs_data']
            pl_variances = verified['pl_data']
            ratio_results['ratios'] = verified['ratios']
            verification_report = verified['verification']
        except Exception as e:
            logger.error("Verification engine failed (non-fatal): %s", e, exc_info=True)
            verification_report = {
                'engine': 'verify_engine', 'ok': None,
                'summary': f'verification skipped: {e}', 'counts': {},
                'mismatches': [], 'corrections': [], 'warnings': [],
            }

        ref_notes = set()
        for r in bs_variances + pl_variances:
            n = _norm_note(r.get('note', ''))
            if n: ref_notes.add(n)

        # Fixed-asset/matrix groups (Intangibles, ROU) whose heading carries no
        # parseable number get note_num=''. Recover it by matching the group
        # heading to the BS/PL line-item that references that note, so the output
        # shows "Note 3b: Intangible Assets" / "Note 11: Right of use asset"
        # instead of "Note : ...".
        import difflib
        from .template_mapper import normalize_name as _nn
        _part_to_note = {}
        for r in bs_variances + pl_variances:
            note = str(r.get('note', '')).strip()
            p = _nn(r.get('particulars', ''))
            if note and p and p not in _part_to_note:
                _part_to_note[p] = note
        for _sheet, _groups in notes_parsed.items():
            for _g in _groups:
                if _g.get('note_num') or not _g.get('is_asset_note'):
                    continue
                _h = _nn(_g.get('note_heading', ''))
                if not _h:
                    continue
                _best, _score = None, 0.0
                for _p, _note in _part_to_note.items():
                    if _h == _p or (len(_p) >= 5 and (_p in _h or _h in _p)):
                        _best, _score = _note, 1.0
                        break
                    _r = difflib.SequenceMatcher(None, _h, _p).ratio()
                    if _r > _score:
                        _best, _score = _note, _r
                if _best and _score >= 0.7:
                    # Keep the sub-part letter from headings like "b. Right of use
                    # asset" so ROU shows as "Note 11(b)" instead of a bare
                    # duplicate "Note 11" colliding with the lease-liabilities note.
                    _heading = str(_g.get('note_heading', ''))
                    _sub = re.match(r'^\s*\(?([a-z])\)?\s*[.\)]\s+', _heading, re.I)
                    if _sub and f'({_sub.group(1).lower()})' not in _best.lower():
                        _g['note_num'] = f"{_best}({_sub.group(1).lower()})"
                        _g['note_heading'] = _heading[_sub.end():].strip()
                    else:
                        _g['note_num'] = _best

        def _keep_note(ng):
            # 1) BS/PL-linked note, or 2) a rebuilt fixed-asset/matrix note
            # (PPE / Intangibles / ROU) — the FA rebuild can't always recover a
            # note number, so without this those whole sheets ('3','4-15') drop.
            if _norm_note(ng.get('note_num', '')) in ref_notes or ng.get('is_asset_note'):
                return True
            # 3) Any other GENUINE note: a real text heading (not a mis-parsed
            # numeric/blank one) plus at least one data row. This keeps the
            # narrative/disclosure notes (Related party, EPS, Financial
            # instruments, etc.) on sheets like '26-37' that aren't tied to a
            # BS/PL line, while still excluding numeric-heading junk and empty
            # shells.
            head = str(ng.get('note_heading', '')).strip()
            return bool(head) and bool(re.search(r'[A-Za-z]', head)) and len(ng.get('data', [])) >= 1

        def _parent_num(ng):
            m = re.match(r'\s*(\d+)', str(ng.get('note_num', '')))
            return int(m.group(1)) if m else None

        def _reorder_asset_notes(groups):
            # Fixed-asset notes (ROU / PPE / Intangibles) are appended at the end
            # of their sheet by the rebuild. Slot each one back in right after the
            # last note at or below its parent number, so e.g. ROU "11(b)" sits
            # between note 11 and note 12 instead of after note 15. Non-asset notes
            # keep their original document order.
            result = [g for g in groups if not g.get('is_asset_note')]
            for ag in (g for g in groups if g.get('is_asset_note')):
                pn = _parent_num(ag)
                if pn is None:
                    result.append(ag)
                    continue
                idx = len(result)
                for i, g in enumerate(result):
                    gp = _parent_num(g)
                    if gp is not None and gp <= pn:
                        idx = i + 1
                result.insert(idx, ag)
            return result

        filtered_notes = {}
        for sheet_name, groups in notes_parsed.items():
            kept_groups = [ng for ng in groups if _keep_note(ng)]
            if kept_groups:
                filtered_notes[sheet_name] = _reorder_asset_notes(kept_groups)
        notes_parsed = filtered_notes
        
        note_mapping = map_bs_to_notes(bs_variances, notes_parsed, rounding_factor)
        
        final_payload = {
            'bs_data': bs_variances,
            'bs_notes': bs_parsed.get('notes', []),
            'bs_signatures': bs_parsed.get('signatures', []),
            'bs_footers': bs_parsed.get('footers', []),
            'pl_data': pl_variances,
            'pl_notes': pl_parsed.get('notes', []),
            'pl_signatures': pl_parsed.get('signatures', []),
            'pl_footers': pl_parsed.get('footers', []),
            'notes_data': notes_parsed,
            'note_mapping': note_mapping,
            'notes_sheet_notes': notes_sheet_notes,
            'notes_signatures': notes_signatures,
            'notes_footers': notes_footers,
            'ratios': ratio_results.get('ratios', []),
            'bs_summary': ratio_results.get('bs_summary', {}),
            'pl_summary': ratio_results.get('pl_summary', {}),
            'verification': verification_report,
            'meta': {
                'client_name': bs_parsed.get('client_name', ''),
                'cy_year': bs_parsed.get('cy_year', 2025),
                'py_year': bs_parsed.get('py_year', 2024),
                'cy_col_letter': bs_parsed.get('cy_col_letter', 'C'),
                'py_col_letter': bs_parsed.get('py_col_letter', 'D'),
                'cy_days': cy_days,
                'py_days': py_days,
                'cy_months': cy_months,
                'py_months': py_months,
                'cy_coverage': cy_coverage,
                'py_coverage': py_coverage,
                'auto_annualize': form_data.get('auto_annualize', True),
                'is_annualized': is_annualized,
                'annualization_msg': annualization_msg,
                'cy_factor': cy_factor,
                'py_factor': py_factor
            }
        }
        
        cache_mgr.set(cache_key, final_payload)
        
        if progress_callback: progress_callback(100, "Processing Complete")
        
        return final_payload

    def _get_rounding_factor(self, unit_str):
        unit = str(unit_str).lower()
        if 'lakh' in unit: return 100000.0
        if 'million' in unit: return 1000000.0
        if 'crore' in unit: return 10000000.0
        if 'thousand' in unit: return 1000.0
        return 1.0

