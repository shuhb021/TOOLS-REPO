
from collections import defaultdict

BALANCE_SHEET_KEYWORDS = {
    "cash":                 ("ASSET",    "Current Asset",      "Liquidity"),
    "bank":                 ("ASSET",    "Current Asset",      "Liquidity"),
    "receivable":           ("ASSET",    "Current Asset",      "Receivable"),
    "debtors":              ("ASSET",    "Current Asset",      "Receivable"),
    "inventory":            ("ASSET",    "Current Asset",      "Inventory"),
    "stock":                ("ASSET",    "Current Asset",      "Inventory"),
    "prepaid":              ("ASSET",    "Current Asset",      "Prepaid"),
    "advance":              ("ASSET",    "Current Asset",      "Advance"),
    "loan":                 ("ASSET",    "Non-Current Asset",  "Loan"),
    "investment":           ("ASSET",    "Non-Current Asset",  "Investment"),
    "fixed asset":          ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "property":             ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "plant":                ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "equipment":            ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "machinery":            ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "vehicle":              ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "furniture":            ("ASSET",    "Non-Current Asset",  "Fixed Asset"),
    "goodwill":             ("ASSET",    "Non-Current Asset",  "Intangible"),
    "intangible":           ("ASSET",    "Non-Current Asset",  "Intangible"),
    "patent":               ("ASSET",    "Non-Current Asset",  "Intangible"),
    "depreciation":         ("ASSET",    "Contra Asset",       "Depreciation"),
    "accumulate":           ("ASSET",    "Contra Asset",       "Depreciation"),
    "payable":              ("LIABILITY","Current Liability",   "Payable"),
    "creditors":            ("LIABILITY","Current Liability",   "Payable"),
    "overdraft":            ("LIABILITY","Current Liability",   "Overdraft"),
    "short term":           ("LIABILITY","Current Liability",   "Short-Term Debt"),
    "current portion":      ("LIABILITY","Current Liability",   "Current Portion LTD"),
    "tax payable":          ("LIABILITY","Current Liability",   "Tax"),
    "provision":            ("LIABILITY","Current Liability",   "Provision"),
    "long term":            ("LIABILITY","Non-Current Liability","Long-Term Debt"),
    "debenture":            ("LIABILITY","Non-Current Liability","Debenture"),
    "mortgage":             ("LIABILITY","Non-Current Liability","Mortgage"),
    "bond":                 ("LIABILITY","Non-Current Liability","Bond"),
    "deferred tax":         ("LIABILITY","Non-Current Liability","Deferred Tax"),
    "equity":               ("EQUITY",   "Equity",             "Equity"),
    "capital":              ("EQUITY",   "Equity",             "Capital"),
    "retained":             ("EQUITY",   "Equity",             "Retained Earnings"),
    "reserve":              ("EQUITY",   "Equity",             "Reserve"),
    "surplus":              ("EQUITY",   "Equity",             "Surplus"),
    "dividend":             ("EQUITY",   "Equity",             "Dividend"),
    "share":                ("EQUITY",   "Equity",             "Share Capital"),
}

PNL_KEYWORDS = {
    "revenue":              ("INCOME",   "Revenue",            "Top Line"),
    "sales":                ("INCOME",   "Revenue",            "Top Line"),
    "turnover":             ("INCOME",   "Revenue",            "Top Line"),
    "income":               ("INCOME",   "Revenue",            "Income"),
    "interest income":      ("INCOME",   "Other Income",       "Interest"),
    "other income":         ("INCOME",   "Other Income",       "Non-Operating"),
    "gain":                 ("INCOME",   "Other Income",       "Gain"),
    "commission":           ("INCOME",   "Revenue",            "Commission"),
    "fee":                  ("INCOME",   "Revenue",            "Fee"),
    "cost of goods":        ("EXPENSE",  "COGS",               "Direct Cost"),
    "cost of sales":        ("EXPENSE",  "COGS",               "Direct Cost"),
    "cogs":                 ("EXPENSE",  "COGS",               "Direct Cost"),
    "direct cost":          ("EXPENSE",  "COGS",               "Direct Cost"),
    "material":             ("EXPENSE",  "COGS",               "Material"),
    "purchases":            ("EXPENSE",  "COGS",               "Purchases"),
    "salary":               ("EXPENSE",  "Operating Expense",  "Payroll"),
    "wages":                ("EXPENSE",  "Operating Expense",  "Payroll"),
    "payroll":              ("EXPENSE",  "Operating Expense",  "Payroll"),
    "rent":                 ("EXPENSE",  "Operating Expense",  "Rent"),
    "utilities":            ("EXPENSE",  "Operating Expense",  "Utilities"),
    "electricity":          ("EXPENSE",  "Operating Expense",  "Utilities"),
    "insurance":            ("EXPENSE",  "Operating Expense",  "Insurance"),
    "marketing":            ("EXPENSE",  "Operating Expense",  "Marketing"),
    "advertising":          ("EXPENSE",  "Operating Expense",  "Marketing"),
    "travel":               ("EXPENSE",  "Operating Expense",  "Travel"),
    "maintenance":          ("EXPENSE",  "Operating Expense",  "Maintenance"),
    "repair":               ("EXPENSE",  "Operating Expense",  "Repair"),
    "legal":                ("EXPENSE",  "Operating Expense",  "Legal"),
    "audit":                ("EXPENSE",  "Operating Expense",  "Professional Fee"),
    "professional":         ("EXPENSE",  "Operating Expense",  "Professional Fee"),
    "software":             ("EXPENSE",  "Operating Expense",  "Software"),
    "subscription":         ("EXPENSE",  "Operating Expense",  "Subscription"),
    "depreciation":         ("EXPENSE",  "Operating Expense",  "Depreciation"),
    "amortization":         ("EXPENSE",  "Operating Expense",  "Amortization"),
    "interest expense":     ("EXPENSE",  "Finance Cost",       "Interest"),
    "interest":             ("EXPENSE",  "Finance Cost",       "Interest"),
    "bank charge":          ("EXPENSE",  "Finance Cost",       "Bank Charge"),
    "tax":                  ("EXPENSE",  "Tax",                "Tax"),
    "profit":               ("INCOME",   "Profit",             "Bottom Line"),
    "loss":                 ("EXPENSE",  "Loss",               "Bottom Line"),
    "ebitda":               ("INCOME",   "Profit",             "EBITDA"),
    "ebit":                 ("INCOME",   "Profit",             "EBIT"),
    "gross profit":         ("INCOME",   "Profit",             "Gross Profit"),
    "net profit":           ("INCOME",   "Profit",             "Net Profit"),
    "net income":           ("INCOME",   "Profit",             "Net Profit"),
}

REMARK_RULES = {
    "zero_value": {
        "cond": lambda v, _p, _a: v == 0,
        "remark": "⚪ Value is zero — confirm whether this account is dormant or awaiting entry.",
        "severity": "INFO"
    },
    "negative_asset": {
        "cond": lambda v, _p, a: v < 0 and a.get("type") == "ASSET",
        "remark": "🔴 Negative asset balance detected — likely a credit balance on an asset account. Investigate for misposting or overdraft.",
        "severity": "CRITICAL"
    },
    "negative_equity": {
        "cond": lambda v, _p, a: v < 0 and a.get("sub") == "Equity",
        "remark": "🔴 Negative equity (capital deficiency) — the company may be technically insolvent. Urgent management review required.",
        "severity": "CRITICAL"
    },
    "large_receivable": {
        "cond": lambda v, _p, a: v > 0 and a.get("sub3") == "Receivable" and a.get("total_revenue", 1) > 0
                                  and v / a.get("total_revenue", 1) > 0.5,
        "remark": "🟠 Receivables exceed 50% of revenue — collection efficiency may be low. Review debtor ageing and credit policy.",
        "severity": "WARNING"
    },
    "high_inventory": {
        "cond": lambda v, _p, a: v > 0 and a.get("sub3") == "Inventory" and a.get("total_revenue", 1) > 0
                                  and v / a.get("total_revenue", 1) > 0.4,
        "remark": "🟠 Inventory > 40% of revenue — potential overstocking or slow-moving goods. Review inventory turnover ratio.",
        "severity": "WARNING"
    },
    "high_payables": {
        "cond": lambda v, _p, a: v > 0 and a.get("sub3") == "Payable" and a.get("total_assets", 1) > 0
                                  and v / a.get("total_assets", 1) > 0.3,
        "remark": "🟠 Payables are >30% of total assets — liquidity pressure. Verify payment schedule alignment with cash inflows.",
        "severity": "WARNING"
    },
    "yoy_spike": {
        "cond": lambda v, p, _a: p != 0 and p is not None and abs((v - p) / abs(p)) > 0.50,
        "remark": lambda v, p: (
            f"{'📈' if v > p else '📉'} {'Increase' if v > p else 'Decrease'} of "
            f"{abs((v-p)/abs(p))*100:.1f}% YoY — "
            + ("Significant growth; verify source and sustainability." if v > p else
               "Sharp decline; investigate root cause immediately.")
        ),
        "severity": "WARNING"
    },
    "yoy_moderate": {
        "cond": lambda v, p, _a: p != 0 and p is not None and 0.10 < abs((v - p) / abs(p)) <= 0.50,
        "remark": lambda v, p: (
            f"{'📈' if v > p else '📉'} {'Rise' if v > p else 'Fall'} of "
            f"{abs((v-p)/abs(p))*100:.1f}% YoY — "
            + ("Moderate growth trend. Monitor for continuation." if v > p else
               "Moderate decline. Track for further movement.")
        ),
        "severity": "INFO"
    },
    "yoy_stable": {
        "cond": lambda v, p, _a: p != 0 and p is not None and abs((v - p) / abs(p)) <= 0.10,
        "remark": lambda v, p: f"✅ Stable YoY movement ({(v-p)/abs(p)*100:+.1f}%) — consistent with prior period.",
        "severity": "OK"
    },
    "revenue_growth": {
        "cond": lambda v, p, a: a.get("sub3") == "Top Line" and p and p > 0 and v > p,
        "remark": lambda v, p: f"✅ Revenue grew by {(v-p)/p*100:.1f}% — positive top-line momentum.",
        "severity": "OK"
    },
    "revenue_decline": {
        "cond": lambda v, p, a: a.get("sub3") == "Top Line" and p and p > 0 and v < p,
        "remark": lambda v, p: f"🔴 Revenue declined by {abs((v-p)/p)*100:.1f}% — business contraction signal. Immediate strategic review needed.",
        "severity": "CRITICAL"
    },
    "expense_creep": {
        "cond": lambda v, p, a: a.get("type") == "EXPENSE" and p and p > 0 and (v - p) / p > 0.20,
        "remark": lambda v, p: f"🟠 Expense increased by {(v-p)/p*100:.1f}% — cost creep detected. Review budget vs actuals.",
        "severity": "WARNING"
    },
    "salary_high": {
        "cond": lambda v, _p, a: a.get("sub3") == "Payroll" and a.get("total_revenue", 1) > 0
                                  and v / a.get("total_revenue", 1) > 0.35,
        "remark": "🟠 Salary/wages >35% of revenue — labour cost ratio is elevated. Assess headcount efficiency.",
        "severity": "WARNING"
    },
    "net_loss": {
        "cond": lambda v, _p, a: v < 0 and a.get("sub3") in ("Net Profit", "Bottom Line"),
        "remark": "🔴 Net loss reported — company is unprofitable this period. Urgent cost review and revenue enhancement plan required.",
        "severity": "CRITICAL"
    },
    "thin_margin": {
        "cond": lambda v, _p, a: a.get("sub3") == "Net Profit" and a.get("total_revenue", 1) > 0
                                  and 0 < v / a.get("total_revenue", 1) < 0.05,
        "remark": lambda v, _p, a: (
            f"🟡 Net margin is thin ({v / a.get('total_revenue', 1) * 100:.1f}%) "
            f"— below 5%. Small shocks could push to loss."
        ),
        "severity": "WARNING"
    },
    "healthy_margin": {
        "cond": lambda v, _p, a: a.get("sub3") == "Net Profit" and a.get("total_revenue", 1) > 0
                                  and v / a.get("total_revenue", 1) >= 0.15,
        "remark": lambda v, _p, a: (
            f"✅ Healthy net margin of {v / a.get('total_revenue', 1) * 100:.1f}% "
            f"— strong profitability."
        ),
        "severity": "OK"
    },
    "no_depreciation": {
        "cond": lambda v, _p, a: a.get("sub3") == "Fixed Asset" and v > 100000
                                  and a.get("total_depreciation", 0) == 0,
        "remark": "🟠 Significant fixed assets but no depreciation found — verify depreciation policy compliance.",
        "severity": "WARNING"
    },
}

def safe_float(val):
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip()
    for curr in ('₹', '$', '€', '£', ' ', '\xa0'):
        s = s.replace(curr, '')
    
    is_neg = False
    if s.startswith('(') and s.endswith(')'):
        is_neg = True
        s = s[1:-1]
        
    last_comma = s.rfind(',')
    last_dot = s.rfind('.')
    
    if last_comma != -1 and last_dot != -1:
        if last_comma > last_dot:
            s = s.replace('.', '').replace(',', '.')
        else:
            s = s.replace(',', '')
    elif last_comma != -1:
        if s.count(',') > 1:
            s = s.replace(',', '')
        else:
            if len(s) - last_comma - 1 in (1, 2):
                s = s.replace(',', '.')
            else:
                s = s.replace(',', '')
    try:
        f = float(s)
        return -f if is_neg else f
    except (ValueError, TypeError):
        return None

def classify_row(label, known_keywords):
    lower = label.lower().strip()
    sorted_kws = sorted(known_keywords.items(), key=lambda x: len(x[0]), reverse=True)
    for kw, (typ, sub, sub3) in sorted_kws:
        if kw in lower:
            return {"type": typ, "sub": sub, "sub3": sub3, "matched_kw": kw}
    return {"type": "UNKNOWN", "sub": "Unknown", "sub3": "Unknown", "matched_kw": None}

def compute_aggregate_context(rows, keyword_map):
    ctx = defaultdict(float)
    for row in rows:
        label = str(row[0]) if row else ""
        val   = safe_float(row[1]) if len(row) > 1 else None
        if val is None:
            continue
        meta = classify_row(label, keyword_map)
        if meta["sub3"] == "Top Line":
            ctx["total_revenue"] += abs(val)
        if meta["sub"] in ("Current Asset",):
            ctx["total_current_assets"] += abs(val)
        if meta["type"] == "ASSET":
            ctx["total_assets"] += abs(val)
        if meta["sub3"] == "Depreciation":
            ctx["total_depreciation"] += abs(val)
        if meta["sub3"] in ("Net Profit", "Bottom Line") and val > 0:
            ctx["net_profit"] = val
    return dict(ctx)

def apply_rules(val, prev_val, meta_plus):
    remarks = []
    if val is None:
        return remarks
    for rule_name, rule in REMARK_RULES.items():
        try:
            if rule["cond"](val, prev_val, meta_plus):
                template = rule["remark"]
                text = template(val, prev_val, meta_plus) if callable(template) else template
                remarks.append((rule["severity"], text))
        except Exception:
            pass
    if not remarks and prev_val is not None and prev_val != 0:
        chg = (val - prev_val) / abs(prev_val) * 100
        if abs(chg) <= 2:
            remarks.append(("OK", f"✅ Virtually unchanged YoY ({chg:+.1f}%) — stable."))
        else:
            dir_sym = "📈" if chg > 0 else "📉"
            remarks.append(("INFO", f"{dir_sym} Changed {chg:+.1f}% from prior period."))
    if not remarks and val is not None:
        remarks.append(("INFO", "ℹ️  Single-period data — no YoY comparison available."))
    return remarks

def load_api_key():
    return "LOCAL_RULE_ENGINE"

def generate_remarks(api_key, items, client_name, financial_year,
                     statement_type, rounding_unit,
                     progress_callback=None, max_workers=5):
    flagged = [(i, item) for i, item in enumerate(items) if item.get('flag', False)]
    if not flagged:
        return {}
    is_bs = 'balance' in statement_type.lower() or 'bs' in statement_type.lower()
    keyword_map = BALANCE_SHEET_KEYWORDS if is_bs else PNL_KEYWORDS
    all_rows = []
    for item in items:
        cy = float(item.get('cy', 0) or 0)
        py = float(item.get('py', 0) or 0)
        label = item.get('particulars', '')
        all_rows.append([label, cy, py])
    ctx = compute_aggregate_context(all_rows, keyword_map)
    results = {}
    total = len(flagged)
    for completed_count, (idx, item) in enumerate(flagged):
        label = item.get('particulars', '')
        cy = float(item.get('cy', 0) or 0)
        py = float(item.get('py', 0) or 0)
        meta = classify_row(label, keyword_map)
        meta_plus = {**meta, **ctx}
        remarks_list = apply_rules(cy, py, meta_plus)
        if remarks_list:
            remark_text = "\n".join([r[1] for r in remarks_list])
        else:
            variance_pct = item.get('display_pct', 'N/A')
            if py != 0:
                direction = "increased" if cy > py else "decreased"
                remark_text = (
                    f"'{label}' has {direction} from ₹{py:,.0f} to ₹{cy:,.0f} "
                    f"({variance_pct} variance). Review the underlying transactions "
                    f"for the period ended {financial_year}."
                )
            else:
                remark_text = (
                    f"'{label}' shows a value of ₹{cy:,.0f} with no prior year comparison. "
                    f"Verify the opening balance and source documentation."
                )
        results[idx] = remark_text
        if progress_callback:
            progress_callback(completed_count + 1, total)
    return results
