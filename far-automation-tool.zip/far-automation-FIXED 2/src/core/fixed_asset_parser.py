"""
fixed_asset_parser.py
=====================

Reads the value for template line-items out of a *fixed-asset / matrix schedule*
note — the kind used for Property Plant & Equipment, Intangible Assets and Right
of Use Assets.

These notes are NOT the simple ``particulars | CY | PY`` layout the ordinary
note parser expects. Instead they are a matrix:

    * columns  = asset classes (Building, Plant, Furniture …) plus a ``Total`` col
    * rows     = "Gross carrying amount …", "Accumulated depreciation …",
                 "Net carrying amount …"
    * often TWO stacked tables, one per year (PY movement then CY movement)

The ordinary parser picks a single CY/PY column and so reads an asset-class
column (e.g. Furniture) instead of the ``Total`` column — which is why the
review panel kept flagging "Gross Block / Accumulated Depreciation / Total" even
though the figures are right there in the sheet.

This module instead, for each section block:

    1. locates that block's own ``Total`` column (it can differ per block),
    2. reads the closing ``Gross carrying amount``, closing
       ``Accumulated depreciation/amortisation`` and ``Net carrying amount``
       from the Total column,
    3. groups them into per-year tables and labels each table with the year in
       its row text, so the latest year is CY and the prior year is PY.

The values are taken from the engine's *visible* grid, so hidden helper columns
never leak in.
"""

import re
import logging

logger = logging.getLogger(__name__)


def _to_number(value):
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    s = str(value).strip()
    if s in ('', '-', '--', '—', '–'):
        return None
    neg = s.startswith('(') and s.endswith(')')
    if neg:
        s = s[1:-1]
    for sym in ('₹', '$', '£', '€', 'Rs.', 'Rs', ',', ' '):
        s = s.replace(sym, '')
    try:
        v = float(s)
        return -v if neg else v
    except (TypeError, ValueError):
        return None


def _is_asset_heading_text(low):
    """True for a fixed-asset section title in any of its common wordings:
    'Property, plant and equipment', 'Property and equipment', 'Intangible
    assets', 'Right of use assets', 'Capital work-in-progress'."""
    return (('property' in low and ('plant' in low or 'equipment' in low))
            or 'intangible' in low
            or ('right' in low and 'use' in low)
            or 'capital work' in low)


def _row_text(row):
    return ' '.join(str(c) for c in row if c not in (None, '')).strip()


def _label_text(row):
    """Join only the NON-numeric cells of a row. Using this for concept / closing
    / year detection avoids reading a stray year out of a value cell (e.g.
    '10.2016' must not be mistaken for the year 2016)."""
    return ' '.join(str(c) for c in row
                    if c not in (None, '') and _to_number(c) is None).strip()


def _is_block_heading(row):
    """Return the heading text when this row STARTS a fixed-asset section, else
    None. Works whether the title is in column A, B or C ('Note 3: Property…',
    '3(a) Property, plant and equipment'). Movement / value rows and footnotes
    are never headings."""
    text = _label_text(row)
    low = text.lower()
    if not low or low.startswith('('):
        return None
    if any(x in low for x in ('as at', 'balance as', '31 march', '1 april', 'additions')):
        return None
    if re.search(r'\bnote\s*\d', low) and len(text) < 100:
        return text
    if len(text) < 70 and _is_asset_heading_text(low):
        return text
    return None


def _concept(text):
    """Which fixed-asset block a row belongs to (or labels)."""
    t = text.lower()
    if 'gross' in t and ('block' in t or 'carrying' in t):
        return 'gross'
    if 'accumulated' in t and ('depreciation' in t or 'amortis' in t or 'amortiz' in t):
        return 'accumdep'
    if 'net block' in t or 'net carrying' in t:
        return 'net'
    return None


def _is_closing(text):
    """A period-end (closing) balance row — not an opening one."""
    t = text.lower()
    if '1 april' in t or '01 april' in t or 'opening' in t:
        return False
    return '31 march' in t or '31st march' in t or 'closing balance' in t


def _year(text):
    m = re.findall(r'((?:19|20)\d{2})', text)
    return int(m[-1]) if m else None


def _total_value(row, total_col):
    """Figure from the Total column; if that cell is blank, sum the numeric
    asset-class cells so notes that leave the Total blank still reconcile."""
    if total_col is not None and total_col < len(row):
        v = _to_number(row[total_col])
        if v is not None:
            return v
    nums = [_to_number(c) for c in row[1:]]
    nums = [n for n in nums if n is not None and not (1900 <= n <= 2100)]
    return sum(nums) if nums else None


def extract_fa_sections(grid):
    """Parse a fixed-asset (matrix) sheet into per-section closing figures,
    handling the common layouts:

      * value rows self-labelled with concept + date ("Gross carrying amount as
        at 31 March 2026"), figures in a Total column;
      * a concept label row ("Gross block" / "I. Gross block") followed by
        "As at 31 March YYYY" / "Balance as at 31 March YYYY" closing rows.

    Returns ``{heading: {'gross':[(year,val)…], 'accumdep':[…], 'net':[…]}}``
    in document order."""
    rows = grid.get('rows', [])
    sections = {}
    heading = None
    total_col = None
    concept = None
    closings = None

    def store():
        if heading is not None and closings and any(closings.values()):
            sections[heading] = closings

    for row in rows:
        label = _label_text(row)        # text cells only (no numbers)
        if not _row_text(row):
            continue

        h = _is_block_heading(row)
        if h:
            store()
            heading, total_col, concept = h, None, None
            closings = {'gross': [], 'accumdep': [], 'net': []}
            continue

        if heading is None:
            continue

        # Header row that names the 'Total' column (can differ per block). When a
        # row has several 'Total' headers (e.g. tangible + intangible side by
        # side) use the FIRST one — the primary asset class for the section.
        tcols = [i for i, c in enumerate(row) if str(c).strip().lower() == 'total']
        if tcols:
            total_col = tcols[0]

        c = _concept(label)
        if c:
            concept = c

        if concept and _is_closing(label):
            val = _total_value(row, total_col)
            if val is not None:
                closings[concept].append((_year(label), val))

    store()
    return sections


def select_cy_py(closings):
    """Pick CY (latest) and PY (prior) closing for each concept from the
    per-section dict returned by :func:`extract_fa_sections`.

    Returns ``{'gross_block': {'cy','py'}, 'accumulated_depreciation': {'cy','py'},
    'total': {'cy','py'}}`` (``total`` = net block)."""
    if not closings or not any(closings.values()):
        return None

    def pick(items):
        if not items:
            return (None, None)
        if all(y for y, _ in items):
            items = sorted(items, key=lambda x: x[0])
        cy = items[-1][1]
        py = items[-2][1] if len(items) >= 2 else None
        return (cy, py)

    g = pick(closings.get('gross', []))
    a = pick(closings.get('accumdep', []))
    n = pick(closings.get('net', []))
    return {
        'gross_block': {'cy': g[0], 'py': g[1]},
        'accumulated_depreciation': {'cy': a[0], 'py': a[1]},
        'total': {'cy': n[0], 'py': n[1]},
    }


def _split_heading(heading):
    """'Note 3. Property, plant and equipment …' -> ('3', 'Property, plant …').

    Also handles headings that lead with the note id and NO 'Note' prefix, e.g.
    '3(a) Property and equipment' -> ('3(a)', 'Property and equipment'). Headings
    with no number (e.g. 'Intangible Assets') return ('', heading)."""
    s = str(heading).strip()
    # Accept a separator (.:-) with no following space — e.g. "Note 4:Intangible
    # assets" — OR plain whitespace, e.g. "Note 3 Property…" / "3(a) Property…".
    m = re.match(r'(?:note\s*)?(\d+\s*\(?[a-z]?\)?)\s*(?:[.:\-]\s*|\s+)(.+)', s, re.I)
    if m:
        num = re.sub(r'\s+', '', m.group(1))   # "3 (a)" -> "3(a)"
        return num, m.group(2).strip(' .:')
    return '', s.strip(' .:')


def build_fa_note_groups(grid):
    """Turn a fixed-asset sheet's visible grid into clean note groups suitable
    for the FAR comparison output: one group per asset section with three
    summary lines (Gross Block / Accumulated Depreciation / Net Block) carrying
    the Total-column CY & PY figures. Returns ``[]`` when the sheet has no
    fixed-asset section."""
    groups = []
    for heading, tables in extract_fa_sections(grid).items():
        chosen = select_cy_py(tables)
        if not chosen:
            continue
        note_num, htext = _split_heading(heading)
        gb, ad, nt = chosen['gross_block'], chosen['accumulated_depreciation'], chosen['total']
        # Skip empty sections (no figures at all).
        if all(v is None for d in (gb, ad, nt) for v in d.values()):
            continue
        groups.append({
            'note_num': note_num,
            'note_heading': htext,
            'data': [
                {'particulars': 'Gross Block', 'cy': gb.get('cy'), 'py': gb.get('py'), 'is_bold': False},
                {'particulars': 'Accumulated Depreciation', 'cy': ad.get('cy'), 'py': ad.get('py'), 'is_bold': False},
                {'particulars': 'Net Block', 'cy': nt.get('cy'), 'py': nt.get('py'), 'is_bold': True},
            ],
            'is_asset_note': True,
        })
    return groups


# Map a template particular onto a fixed-asset field.
def fa_field_for_particular(particular):
    s = re.sub(r'[^a-z0-9]', '', str(particular).lower())
    if 'grossblock' in s or 'grosscarrying' in s:
        return 'gross_block'
    if 'accumulateddepreciation' in s or 'accumulatedamortisation' in s \
            or 'accumulatedamortization' in s:
        return 'accumulated_depreciation'
    if s == 'total' or 'netblock' in s or 'netcarrying' in s or 'netcarryingamount' in s:
        return 'total'
    return None
