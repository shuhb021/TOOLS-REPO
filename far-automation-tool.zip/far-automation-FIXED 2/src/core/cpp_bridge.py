"""
FAR computation engine (pure Python).

History: this module used to be a ctypes bridge to a native ``far_engine.dll``
("C++ engine") with a Python fallback. The native engine was never actually used
at runtime (the app always took the Python path), its ratio logic had drifted
out of sync with the current 15-ratio spec, and bundling a DLL only added
packaging and integrity-check risk. The C++ engine has been removed; these
Python functions are now the single source of truth.
"""

import math
import logging

logger = logging.getLogger(__name__)

def _py_compute_variances(data):
    results = []
    for row in data:
        cy_val = row.get('cy')
        py_val = row.get('py')

        cy_missing = cy_val is None
        py_missing = py_val is None
        cy_dash = cy_val == '-'
        py_dash = py_val == '-'

        cy_absent = cy_missing or cy_dash
        py_absent = py_missing or py_dash

        if cy_absent and py_absent:
            if cy_missing and py_missing:
                disp_cy = '-NA-'
                disp_py = '-NA-'
                display_pct = '-NA-'
            elif cy_dash and py_dash:
                disp_cy = '-'
                disp_py = '-'
                display_pct = '-'
            else:
                disp_cy = '-NA-' if cy_missing else '-'
                disp_py = '-NA-' if py_missing else '-'
                display_pct = '-'
            variance_abs = None
            variance_pct = None
            flag = False
        else:
            cy = float(cy_val) if not cy_absent else 0.0
            py = float(py_val) if not py_absent else 0.0
            variance_abs = cy - py

            if py == 0:
                if cy == 0:
                    variance_pct = 0.0
                    display_pct = '0.0%'
                else:
                    variance_pct = float('inf')
                    display_pct = 'N/A'
            else:
                variance_pct = (variance_abs / abs(py)) * 100.0
                display_pct = f'{variance_pct:.1f}%'

            abs_pct = 0.0 if (py == 0 and cy == 0) else (100.0 if py == 0 else abs(variance_pct))
            flag = abs_pct >= 10.0

        result = dict(row)
        result['variance_abs'] = round(variance_abs, 2) if variance_abs is not None else None
        result['variance_pct'] = round(variance_pct, 2) if (variance_pct is not None and not math.isinf(variance_pct)) else None
        result['display_pct'] = display_pct
        result['flag'] = flag
        results.append(result)
    return results

def _py_compute_ratios(bs_summary, pl_summary):
    def g(d, key):
        v = d.get(key, 0.0)
        try:
            return float(v) if v is not None else 0.0
        except (TypeError, ValueError):
            return 0.0

    # Balance-sheet inputs
    eq_cy, eq_py = g(bs_summary, 'total_equity_cy'), g(bs_summary, 'total_equity_py')
    ca_cy, ca_py = g(bs_summary, 'total_ca_cy'), g(bs_summary, 'total_ca_py')
    cl_cy, cl_py = g(bs_summary, 'total_cl_cy'), g(bs_summary, 'total_cl_py')
    ncl_cy, ncl_py = g(bs_summary, 'total_ncl_cy'), g(bs_summary, 'total_ncl_py')
    at_cy, at_py = g(bs_summary, 'total_assets_cy'), g(bs_summary, 'total_assets_py')
    ltb_cy, ltb_py = g(bs_summary, 'ltb_cy'), g(bs_summary, 'ltb_py')
    stb_cy, stb_py = g(bs_summary, 'stb_cy'), g(bs_summary, 'stb_py')
    has_borrowings = bs_summary.get('has_borrowings', False)
    debt_cy, debt_py = g(bs_summary, 'debtors_cy'), g(bs_summary, 'debtors_py')
    cash_cy, cash_py = g(bs_summary, 'cash_cy'), g(bs_summary, 'cash_py')
    inv_cy, inv_py = g(bs_summary, 'inventory_cy'), g(bs_summary, 'inventory_py')
    # P&L inputs
    rev_cy, rev_py = g(pl_summary, 'revenue_ops_cy'), g(pl_summary, 'revenue_ops_py')
    inc_cy, inc_py = g(pl_summary, 'total_revenue_cy'), g(pl_summary, 'total_revenue_py')
    pbt_cy, pbt_py = g(pl_summary, 'pbt_cy'), g(pl_summary, 'pbt_py')
    pat_cy, pat_py = g(pl_summary, 'pat_cy'), g(pl_summary, 'pat_py')
    fin_cy, fin_py = g(pl_summary, 'finance_cost_cy'), g(pl_summary, 'finance_cost_py')
    com_cy, com_py = g(pl_summary, 'cost_materials_cy'), g(pl_summary, 'cost_materials_py')
    dep_cy, dep_py = g(pl_summary, 'depreciation_cy'), g(pl_summary, 'depreciation_py')

    adebt_cy = (debt_cy + debt_py) / 2.0 if (debt_cy + debt_py) > 0 else 0.0
    adebt_py = debt_py
    aeq_cy = (eq_cy + eq_py) / 2.0
    ainv_cy = (inv_cy + inv_py) / 2.0 if (inv_cy + inv_py) > 0 else 0.0
    ainv_py = inv_py
    borr_cy, borr_py = ltb_cy + stb_cy, ltb_py + stb_py

    def nf(x):
        # Compact human-readable number for the worked formula (2dp, no trailing
        # zeros): 7141.0 -> "7141", 82.327 -> "82.33".
        try:
            s = f'{float(x):.2f}'
        except (TypeError, ValueError):
            return '0'
        return s.rstrip('0').rstrip('.') if '.' in s else s

    def mk(section, key, formula, cy_num, cy_den, py_num, py_den,
           is_pct=False, na_cy=False, na_py=False,
           cy_num_s=None, cy_den_s=None, py_num_s=None, py_den_s=None):
        # A year is "-NA-" when a required input is missing (0) or it would
        # divide by zero — the user wants -NA-, not a misleading 0.
        def one(num, den, na):
            if na or den in (None, 0):
                return None
            v = num / den
            return v * 100.0 if is_pct else v
        cy = one(cy_num, cy_den, na_cy)
        py = one(py_num, py_den, na_py)

        def calc(num, den, num_s, den_s, val):
            # Human-readable "numbers plugged in" formula, e.g. (201+194)/7141 or
            # 6064.09/739*100. Composite figures (a sum of two or more source
            # lines) are shown in full so every number can be traced. Returns
            # None when the ratio is -NA-.
            if val is None:
                return None
            n = num_s if num_s is not None else nf(num)
            d = den_s if den_s is not None else nf(den)
            if any(op in n for op in '+-'):
                n = f'({n})'
            if any(op in d for op in '+-*/'):
                d = f'({d})'
            expr = f'{n}/{d}'
            return expr + '*100' if is_pct else expr
        cy_calc = calc(cy_num, cy_den, cy_num_s, cy_den_s, cy)
        py_calc = calc(py_num, py_den, py_num_s, py_den_s, py)

        if cy is None and py is None:
            change, disp, flag = None, '-NA-', False
        elif cy is None or py is None:
            change, disp, flag = None, '-', False
        elif py == 0:
            change = 0.0 if cy == 0 else 100.0
            disp, flag = ('0.0%', False) if cy == 0 else ('N/A', True)
        else:
            change = ((cy - py) / abs(py)) * 100.0
            disp, flag = f'{change:.1f}%', abs(change) >= 10.0

        def r(x):
            return round(x, 4) if isinstance(x, (int, float)) else None
        return {
            'section': section, 'key': key, 'formula': formula, 'is_pct': is_pct,
            'cy': r(cy), 'py': r(py),
            'change': round(change, 2) if change is not None else None,
            'display_change': disp, 'flag': flag,
            'cy_num': r(cy_num) if cy is not None else None,
            'cy_den': r(cy_den) if cy is not None else None,
            'py_num': r(py_num) if py is not None else None,
            'py_den': r(py_den) if py is not None else None,
            'cy_calc': cy_calc, 'py_calc': py_calc,
        }

    return [
        # ---- Assets Ratio ----
        mk('Assets Ratio', 'Trade Receivables Turnover Ratio',
           'Revenue from Operations / Average Trade Receivables',
           rev_cy, adebt_cy, rev_py, adebt_py,
           na_cy=(adebt_cy == 0), na_py=(adebt_py == 0),
           cy_den_s=f'({nf(debt_cy)}+{nf(debt_py)})/2'),
        mk('Assets Ratio', 'Accounts Receivable Collection Period',
           '365 / Trade Receivables Turnover Ratio',
           365.0 * adebt_cy, rev_cy, 365.0 * adebt_py, rev_py,
           na_cy=(adebt_cy == 0 or rev_cy == 0), na_py=(adebt_py == 0 or rev_py == 0),
           cy_num_s=f'365*{nf(adebt_cy)}', py_num_s=f'365*{nf(adebt_py)}'),
        mk('Assets Ratio', 'Total Assets Ratio',
           'Total Income / Total Assets',
           inc_cy, at_cy, inc_py, at_py,
           na_cy=(at_cy == 0 or inc_cy == 0), na_py=(at_py == 0 or inc_py == 0)),
        # ---- Liquidity Ratios ----
        mk('Liquidity Ratios', 'Net Working Capital Ratio',
           '(Current Assets - Current Liabilities) / Total Assets',
           ca_cy - cl_cy, at_cy, ca_py - cl_py, at_py,
           na_cy=(at_cy == 0), na_py=(at_py == 0),
           cy_num_s=f'{nf(ca_cy)}-{nf(cl_cy)}', py_num_s=f'{nf(ca_py)}-{nf(cl_py)}'),
        mk('Liquidity Ratios', 'Cash Ratio',
           'Cash and Cash Equivalents / Current Liabilities',
           cash_cy, cl_cy, cash_py, cl_py,
           na_cy=(cl_cy == 0 or cash_cy == 0), na_py=(cl_py == 0 or cash_py == 0)),
        mk('Liquidity Ratios', 'Current Ratio',
           'Current Assets / Current Liabilities',
           ca_cy, cl_cy, ca_py, cl_py,
           na_cy=(cl_cy == 0), na_py=(cl_py == 0)),
        # ---- Other Ratios ----
        mk('Other Ratios', 'Debt Equity Ratio',
           '(Long-Term Borrowings + Short-Term Borrowings) / Total Equity',
           borr_cy, eq_cy, borr_py, eq_py,
           na_cy=(not has_borrowings or eq_cy == 0),
           na_py=(not has_borrowings or eq_py == 0),
           cy_num_s=f'{nf(ltb_cy)}+{nf(stb_cy)}', py_num_s=f'{nf(ltb_py)}+{nf(stb_py)}'),
        mk('Other Ratios', 'Return on Equity (ROE)',
           'Profit Before Tax / Average Total Equity × 100',
           pbt_cy, aeq_cy, pbt_py, eq_py, is_pct=True,
           na_cy=(aeq_cy == 0), na_py=(eq_py == 0),
           cy_den_s=f'({nf(eq_cy)}+{nf(eq_py)})/2'),
        mk('Other Ratios', 'GCA Days',
           '(Total Current Assets / Total Revenue) × 365',
           ca_cy * 365.0, inc_cy, ca_py * 365.0, inc_py,
           na_cy=(inc_cy == 0), na_py=(inc_py == 0),
           cy_num_s=f'{nf(ca_cy)}*365', py_num_s=f'{nf(ca_py)}*365'),
        mk('Other Ratios', 'Total Outside Liab. vs Total Equity',
           '(Total Current Liabilities + Total Non-Current Liabilities) / Total Equity',
           cl_cy + ncl_cy, eq_cy, cl_py + ncl_py, eq_py,
           na_cy=(eq_cy == 0), na_py=(eq_py == 0),
           cy_num_s=f'{nf(cl_cy)}+{nf(ncl_cy)}', py_num_s=f'{nf(cl_py)}+{nf(ncl_py)}'),
        mk('Other Ratios', 'Net Profit Ratio',
           'Net Profit After Tax / Revenue from Operations × 100',
           pat_cy, rev_cy, pat_py, rev_py, is_pct=True,
           na_cy=(rev_cy == 0), na_py=(rev_py == 0)),
        mk('Other Ratios', 'Return on Capital Employed (ROCE)',
           '(PBT + Finance Cost) / (Total Equity + LTB + STB) × 100',
           pbt_cy + fin_cy, eq_cy + borr_cy, pbt_py + fin_py, eq_py + borr_py, is_pct=True,
           na_cy=(eq_cy + borr_cy == 0),
           na_py=(eq_py + borr_py == 0),
           cy_num_s=f'{nf(pbt_cy)}+{nf(fin_cy)}', py_num_s=f'{nf(pbt_py)}+{nf(fin_py)}',
           cy_den_s=f'{nf(eq_cy)}+{nf(ltb_cy)}+{nf(stb_cy)}',
           py_den_s=f'{nf(eq_py)}+{nf(ltb_py)}+{nf(stb_py)}'),
        mk('Other Ratios', 'Debt Service Coverage Ratio',
           '(Profit Before Tax + Finance Cost + Depreciation) / Finance Cost',
           pbt_cy + fin_cy + dep_cy, fin_cy, pbt_py + fin_py + dep_py, fin_py,
           na_cy=(fin_cy == 0), na_py=(fin_py == 0),
           cy_num_s=f'{nf(pbt_cy)}+{nf(fin_cy)}+{nf(dep_cy)}',
           py_num_s=f'{nf(pbt_py)}+{nf(fin_py)}+{nf(dep_py)}'),
        mk('Other Ratios', 'Inventory Turnover Ratio',
           'Cost of Materials Consumed / Average Inventory',
           com_cy, ainv_cy, com_py, ainv_py,
           na_cy=(ainv_cy == 0 or com_cy == 0), na_py=(ainv_py == 0 or com_py == 0),
           cy_den_s=f'({nf(inv_cy)}+{nf(inv_py)})/2'),
    ]

def compute_variances(data):
    """Compute per-row variances (abs + %). Pure-Python single source of truth."""
    return _py_compute_variances(data)

def compute_ratios_from_raw(bs_data, pl_data):
    """Extract BS/PL summaries from raw parsed rows and compute the financial
    ratios. Pure-Python single source of truth."""
    from src.core.excel_parser import extract_bs_summary, extract_pl_summary
    bs_summary = extract_bs_summary(bs_data)
    pl_summary = extract_pl_summary(pl_data)
    ratios = _py_compute_ratios(bs_summary, pl_summary)

    return {
        "ratios": ratios,
        "bs_summary": bs_summary,
        "pl_summary": pl_summary
    }
