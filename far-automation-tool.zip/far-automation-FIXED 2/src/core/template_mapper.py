"""
template_mapper.py
==================

Core (non-GUI) logic that backs the Manual Review & Correction Mode.

Responsibilities
----------------
1. Confidence-tier classification for note-mapping results
       > 0.90  -> AUTO     (process automatically)
       0.70-0.90 -> WARNING (proceed, but flag)
       < 0.70  -> MANUAL   (force the review panel)
2. Detection of note-mapping rows that need human review
   (note not found, total mismatch, particular mismatch, low confidence,
   validation failed, template not matched).
3. A persistent ``MappingStore`` so a manual correction made once is
   automatically reused on future runs of the same client/note.
4. Helpers to apply manual overrides back onto the note-mapping +
   balance-sheet data so downstream calculations can continue without
   restarting the whole pipeline.

This module deliberately contains **no PyQt imports** so it stays unit
testable and reusable from both the GUI and headless contexts.
"""

import os
import re
import json
import difflib
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Confidence thresholds (single source of truth for the tier workflow)
# ---------------------------------------------------------------------------
CONF_AUTO = 0.90      # >= this  -> auto process
CONF_WARN = 0.70      # >= this  -> warning (but proceed); below -> force manual

TIER_AUTO = 'AUTO'
TIER_WARNING = 'WARNING'
TIER_MANUAL = 'MANUAL'

# Variance tolerance (in the same scaled unit the mapping uses)
DEFAULT_TOLERANCE = 1.0


def normalize_name(value):
    """Normalise a particular/heading for comparison.

    Removes spaces and special characters and lower-cases the result so that
    ``"Plant & Machinery"`` and ``"plant and machinery"`` compare equal-ish.
    """
    if value is None:
        return ""
    s = str(value).lower()
    s = s.replace('&', 'and')
    s = re.sub(r'[^a-z0-9]', '', s)
    return s


def _to_number(value):
    """Best-effort parse of a cell value to float; ``None`` if not numeric."""
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if s in ('', '-', '--', '—', '–'):
        return None
    neg = s.startswith('(') and s.endswith(')')
    if neg:
        s = s[1:-1]
    for sym in ('₹', '$', '£', '€', 'Rs.', 'Rs', ',', ' '):
        s = s.replace(sym, '')
    try:
        v = float(s)
        return -v if neg else v
    except (TypeError, ValueError):
        return None


def _is_total_particular(particular):
    """True for template line-items that represent a note's total."""
    return 'total' in normalize_name(particular)


def _values_close(a, b, tol=DEFAULT_TOLERANCE):
    """Equal within an absolute floor plus a small relative band (handles
    rounding differences between the BS/PL figure and the note figure)."""
    if a is None or b is None:
        return False
    return abs(a - b) <= max(tol, abs(b) * 0.005)


def _group_reconciles(group):
    """Does the note balance using only its VISIBLE rows? Returns ``{'cy':bool,
    'py':bool}`` — True on an axis when the component rows sum to the note's
    ``Total`` row. When True, any template line missing from the note is genuinely
    0 for this entity (the hidden source rows we excluded were the zero items),
    so it can be auto-filled 0 instead of being flagged for manual entry.
    """
    res = {'cy': False, 'py': False}
    for axis in ('cy', 'py'):
        total = None
        comps = []
        for d in group.get('data', []):
            v = _to_number(d.get(axis))
            name = normalize_name(d.get('particulars', ''))
            if 'total' in name:
                if total is None:
                    total = v
            elif v is not None:
                comps.append(v)
        res[axis] = total is not None and bool(comps) and _values_close(sum(comps), total)
    return res


def _group_supports_total(value, group):
    """Implements the "search the total in the notes sheet" cross-check.

    Returns True when ``value`` (the total taken from the BS/PL) is actually
    present in the note: either it appears directly as one of the note's
    visible CY/PY figures, or the note's component rows add up to it. Only the
    parser's visible data is consulted, so hidden helper figures never count.
    """
    if value is None:
        return False
    cy_components = []
    for d in group.get('data', []):
        cy = _to_number(d.get('cy'))
        py = _to_number(d.get('py'))
        if _values_close(cy, value) or _values_close(py, value):
            return True            # the total figure is printed in the note
        if cy is not None:
            cy_components.append(cy)
    # The note has no explicit total row, but its line items sum to the total.
    return bool(cy_components) and _values_close(sum(cy_components), value)


def classify_confidence(confidence):
    """Map a 0-1 confidence score to one of the three tiers."""
    try:
        c = float(confidence)
    except (TypeError, ValueError):
        c = 0.0
    if c >= CONF_AUTO:
        return TIER_AUTO
    if c >= CONF_WARN:
        return TIER_WARNING
    return TIER_MANUAL


def get_review_items(note_mapping):
    """Return **all** note rows for manual review against the template.

    The earlier multi-rule auto-detection (note-not-found / total mismatch /
    particular mismatch / confidence threshold / validation failed) has been
    removed by request: the panel now lists every note and shows the full
    sheet. The only thing checked is whether the note was placed into the
    template (``template_matched``); this is used for display colour only and
    never hides/filters any row.

    Each returned dict augments the original mapping row with:
        ``template_matched`` – bool, did it map onto the template
        ``review_reason``    – short display label
        ``tier``             – AUTO (matched) / MANUAL (not matched), display only
        ``_index``           – position in the original note_mapping list
    """
    items = []
    for idx, row in enumerate(note_mapping or []):
        status_cy = str(row.get('status_cy', '')).strip().lower()
        matched = (status_cy == 'matched')
        enriched = dict(row)
        enriched['template_matched'] = matched
        enriched['review_reason'] = 'Template matched' if matched else 'Template not matched'
        enriched['tier'] = TIER_AUTO if matched else TIER_MANUAL
        enriched['_index'] = idx
        items.append(enriched)
    return items


def overall_tier(review_items):
    """The strongest tier across all review items (MANUAL > WARNING > AUTO)."""
    if not review_items:
        return TIER_AUTO
    tiers = {it.get('tier', TIER_AUTO) for it in review_items}
    if TIER_MANUAL in tiers:
        return TIER_MANUAL
    if TIER_WARNING in tiers:
        return TIER_WARNING
    return TIER_AUTO


# ---------------------------------------------------------------------------
# Persistent reusable mapping rules
# ---------------------------------------------------------------------------
class MappingStore:
    """Persist manual corrections so they are reused on later runs.

    Keyed by ``normalize(note_num) | normalize(bs_particular)`` which is stable
    across re-runs of the same statement regardless of minor spacing changes.
    """

    def __init__(self, path=None):
        if path is None:
            base = os.environ.get('APPDATA') or os.path.expanduser('~')
            cfg_dir = os.path.join(base, 'FAR_Automation')
            os.makedirs(cfg_dir, exist_ok=True)
            path = os.path.join(cfg_dir, 'manual_mappings.json')
        self.path = path
        self._rules = {}
        self.load()

    @staticmethod
    def make_key(note_num, bs_particular):
        return f"{normalize_name(note_num)}|{normalize_name(bs_particular)}"

    def load(self):
        try:
            if os.path.exists(self.path) and os.path.getsize(self.path) > 0:
                with open(self.path, 'r', encoding='utf-8') as f:
                    self._rules = json.load(f) or {}
        except Exception as e:  # noqa: BLE001 - corrupt store should not crash app
            logger.warning("Could not load mapping store %s: %s", self.path, e)
            self._rules = {}
        return self._rules

    def save(self):
        try:
            with open(self.path, 'w', encoding='utf-8') as f:
                json.dump(self._rules, f, ensure_ascii=False, indent=2)
        except Exception as e:  # noqa: BLE001
            logger.warning("Could not save mapping store %s: %s", self.path, e)

    def get(self, note_num, bs_particular):
        return self._rules.get(self.make_key(note_num, bs_particular))

    def put(self, note_num, bs_particular, override):
        """Store a reusable override dict {cy, py, source_sheet, cells}."""
        key = self.make_key(note_num, bs_particular)
        record = dict(override)
        record['note_num'] = note_num
        record['bs_particular'] = bs_particular
        self._rules[key] = record
        self.save()
        return key

    def all(self):
        return dict(self._rules)


# ---------------------------------------------------------------------------
# Applying overrides back onto the data
# ---------------------------------------------------------------------------
def apply_overrides(note_mapping, overrides, tolerance=DEFAULT_TOLERANCE):
    """Return a new note_mapping with manual overrides applied.

    ``overrides`` is a dict keyed by the original mapping-row index, each value
    a dict that may contain ``cy`` and/or ``py`` corrected note totals plus
    optional ``source`` metadata. Status is recomputed against the BS amount so
    downstream validation reflects the correction.
    """
    if not overrides:
        return note_mapping

    updated = [dict(r) for r in note_mapping]
    for idx_str, ov in overrides.items():
        try:
            idx = int(idx_str)
        except (TypeError, ValueError):
            continue
        if idx < 0 or idx >= len(updated):
            continue
        row = updated[idx]

        def _num(v):
            try:
                return float(str(v).replace(',', '').strip())
            except (TypeError, ValueError):
                return None

        bs_cy = _num(row.get('bs_cy'))
        bs_py = _num(row.get('bs_py'))

        if ov.get('cy') is not None:
            note_cy = _num(ov.get('cy'))
            row['note_cy'] = note_cy
            if note_cy is not None and bs_cy is not None:
                row['variance_cy'] = abs(bs_cy - note_cy)
                row['status_cy'] = 'Matched' if row['variance_cy'] <= tolerance else 'Mismatch'
        if ov.get('py') is not None:
            note_py = _num(ov.get('py'))
            row['note_py'] = note_py
            if note_py is not None and bs_py is not None:
                row['variance_py'] = abs(bs_py - note_py)
                row['status_py'] = 'Matched' if row['variance_py'] <= tolerance else 'Mismatch'

        if ov.get('source_row'):
            row['note_total_row'] = ov.get('source_row')
        row['matched_by'] = 'Manual'
        row['match_confidence'] = 1.0
        logger.info(
            "MANUAL OVERRIDE applied | Note %s | '%s' | note_cy=%s note_py=%s | "
            "status CY=%s PY=%s | source=%s",
            row.get('note_num'), row.get('bs_particular'),
            row.get('note_cy'), row.get('note_py'),
            row.get('status_cy'), row.get('status_py'), ov.get('source'))
    return updated


# ---------------------------------------------------------------------------
# Template (Template_FAR.xlsx) matching  --  the ONLY check that drives Review
# ---------------------------------------------------------------------------
def _project_root():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def default_template_path():
    return os.path.join(_project_root(), 'templates', 'Template_FAR.xlsx')


# Parsed template structure is cached in-process. Template_FAR.xlsx is a static
# shipped file, but opening it with openpyxl costs ~1.6s; without this cache that
# price was paid on every single generation. Keyed by (path, mtime, size) so a
# swapped-in template is still picked up automatically.
_TEMPLATE_STRUCTURE_CACHE = {}


def load_template_structure(template_path=None):
    """Parse Template_FAR.xlsx and return its fixed note line-items.

    Each note sheet (e.g. ``3-4``, ``5-9``) holds one or more sections. A
    section heading row is marked by the legend cells C='a', D='b' with the
    heading text in column B; the rows below ("Gross Block", "Total", …) are the
    particular lines that must be populated.

    Returns a list of dicts: ``{'sheet','row','section','particular'}``.

    The result is memoised by file identity (path/mtime/size); re-parsing only
    happens if the template file actually changes on disk.
    """
    from openpyxl import load_workbook
    path = template_path or default_template_path()
    items = []
    if not os.path.exists(path):
        logger.warning("Template not found: %s", path)
        return items

    try:
        st = os.stat(path)
        cache_key = (os.path.abspath(path), st.st_mtime, st.st_size)
    except OSError:
        cache_key = None

    if cache_key is not None and cache_key in _TEMPLATE_STRUCTURE_CACHE:
        # Return a shallow copy so callers can't mutate the cached structure.
        return [dict(it) for it in _TEMPLATE_STRUCTURE_CACHE[cache_key]]

    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        for sn in wb.sheetnames:
            low = sn.strip().lower()
            # Template matching is for NOTE sheets only — never BS / PL / Ratio /
            # cover / dashboard / blank helper sheets.
            if low.startswith('sheet'):
                continue
            if any(x in low for x in ('bs', 'balance sheet', 'pl', 'p&l',
                                      'profit', 'ratio', 'cover', 'dashboard', 'index')):
                continue
            ws = wb[sn]
            current_section = None
            for r_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
                b = row[1] if len(row) > 1 else None
                c = row[2] if len(row) > 2 else None
                d = row[3] if len(row) > 3 else None
                btxt = str(b).strip() if b is not None else ''
                if not btxt:
                    continue
                is_heading = (str(c).strip().lower() == 'a' and str(d).strip().lower() == 'b')
                if is_heading:
                    current_section = btxt
                    continue
                if btxt.lower() in ('particulars', 'remarks'):
                    continue
                if current_section:
                    items.append({'sheet': sn, 'row': r_idx,
                                  'section': current_section, 'particular': btxt})
    finally:
        try:
            wb.close()
        except Exception:
            pass
    logger.info("Loaded %d template line-items from %s", len(items), os.path.basename(path))
    if cache_key is not None:
        _TEMPLATE_STRUCTURE_CACHE[cache_key] = [dict(it) for it in items]
    return items


def _flatten_note_groups(notes_data):
    groups = []
    for _sheet, glist in (notes_data or {}).items():
        if isinstance(glist, list):
            groups.extend(glist)
    return groups


def match_to_template(template_items, notes_data, note_totals=None):
    """Match extracted note data onto the template line-items.

    For each template section the best-matching extracted note group is found by
    heading similarity; then each template particular is filled from that
    group's data rows by normalised-name match. Items that cannot be filled are
    flagged (``template_matched=False``) for manual review.

    ``note_totals`` (optional) is ``{normalised_note_num: {'cy':.., 'py':..}}``
    built from the BS/PL ↔ note linkage. For a ``Total`` line that name-matching
    could not fill, the BS/PL total is taken and cross-checked against the note:
    if that figure is found in the note it is used automatically; otherwise the
    line is left for the user to confirm (with the BS/PL figure pre-filled as a
    suggestion).
    """
    note_totals = note_totals or {}
    groups = _flatten_note_groups(notes_data)
    norm_groups = [(normalize_name(g.get('note_heading', '')), g) for g in groups]

    # Match each distinct template section to a note group once.
    section_match = {}
    for sec in {it['section'] for it in template_items}:
        ns = normalize_name(sec)
        best, best_score = None, 0.0
        for nh, g in norm_groups:
            if not nh:
                continue
            score = difflib.SequenceMatcher(None, ns, nh).ratio()
            if ns and (ns in nh or nh in ns):
                score = max(score, 0.9)
            if score > best_score:
                best_score, best = score, g
        section_match[sec] = best if best_score >= 0.6 else None

    # Per section: does the matched note balance using only its visible rows?
    section_reconcile = {
        sec: (_group_reconciles(g) if g else {'cy': False, 'py': False})
        for sec, g in section_match.items()
    }

    # A note row may fill at most one template line; otherwise a single
    # "Interest income" row gets copied onto every "Interest income …" template
    # line (triplicating the figure). Track consumed rows per note group.
    consumed = {}

    result = []
    for i, it in enumerate(template_items):
        g = section_match.get(it['section'])
        value_cy = value_py = None
        matched = False
        matched_note = g.get('note_heading', '') if g else ''
        if g:
            used = consumed.setdefault(id(g), set())
            pn = normalize_name(it['particular'])
            data = g.get('data', [])
            best_ri, best_exact = None, False
            best_fuzzy_ri, best_fuzzy = None, 0.0
            for ri, d in enumerate(data):
                if ri in used:
                    continue
                dn = normalize_name(d.get('particulars', ''))
                if not (pn and dn):
                    continue
                if pn == dn:                       # exact wins immediately
                    best_ri, best_exact = ri, True
                    break
                if (pn in dn or dn in pn) and best_ri is None:
                    best_ri = ri                   # first loose match, keep looking for exact
                # Track the closest fuzzy candidate among rows that carry a value.
                if d.get('cy') is not None or d.get('py') is not None:
                    sc = difflib.SequenceMatcher(None, pn, dn).ratio()
                    if sc > best_fuzzy:
                        best_fuzzy, best_fuzzy_ri = sc, ri
            # High-confidence fuzzy fallback — catches near-identical labels
            # (singular/plural, punctuation, e.g. "Receivable from related parties"
            # vs "Receivables from related parties"). Threshold is deliberately
            # high (0.85) so genuinely-different source labels are NOT mis-mapped;
            # those stay flagged for manual user input. (Empirically, wrong
            # matches on real data score < 0.55, so 0.85 is safe.)
            if best_ri is None and best_fuzzy_ri is not None and best_fuzzy >= 0.85:
                best_ri = best_fuzzy_ri
            if best_ri is not None:
                d = data[best_ri]
                value_cy = d.get('cy')
                value_py = d.get('py')
                matched = value_cy is not None
                if matched or best_exact:
                    used.add(best_ri)

        # --- Reconciled section: a line missing from a note that already balances
        # with its visible rows is genuinely 0 (the hidden source rows we excluded
        # were the zero items) -> auto-fill 0 instead of flagging it.
        zero_reason = None
        if not matched and g is not None and not _is_total_particular(it['particular']):
            rec = section_reconcile.get(it['section'], {})
            if rec.get('cy') or rec.get('py'):
                if rec.get('cy'):
                    value_cy = 0.0
                if rec.get('py'):
                    value_py = 0.0
                matched = value_cy is not None
                zero_reason = 'Not in note — set to 0 (note reconciles)'

        # --- Total fallback: take the total from BS/PL and verify it in the note.
        # Applies only to "Total" lines that name-matching could not fill.
        suggested_cy = suggested_py = None
        total_reason = None
        if not matched and g is not None and _is_total_particular(it['particular']):
            tot = note_totals.get(normalize_name(g.get('note_num', '')))
            if tot:
                tcy = _to_number(tot.get('cy'))
                tpy = _to_number(tot.get('py'))
                if tcy is not None or tpy is not None:
                    if _group_supports_total(tcy if tcy is not None else tpy, g):
                        value_cy, value_py = tcy, tpy
                        matched = True
                        total_reason = 'Total taken from BS/PL (found in note)'
                    else:
                        # Found in BS/PL but NOT in the note -> ask the user,
                        # pre-filling the BS/PL figure as a suggestion.
                        suggested_cy, suggested_py = tcy, tpy
                        total_reason = 'Total from BS/PL not found in note — please confirm'

        enriched = dict(it)
        enriched['_index'] = i
        enriched['template_matched'] = matched
        enriched['value_cy'] = value_cy
        enriched['value_py'] = value_py
        enriched['suggested_cy'] = suggested_cy
        enriched['suggested_py'] = suggested_py
        enriched['matched_note'] = matched_note
        # aliases so the Review panel (built for note rows) renders unchanged
        enriched['note_num'] = it['section']
        enriched['bs_particular'] = it['particular']
        enriched['bs_cy'] = value_cy if value_cy is not None else '-'
        enriched['bs_py'] = value_py if value_py is not None else '-'
        enriched['note_cy'] = value_cy if value_cy is not None else '-'
        enriched['note_py'] = value_py if value_py is not None else '-'
        if total_reason:
            enriched['review_reason'] = total_reason
        elif zero_reason:
            enriched['review_reason'] = zero_reason
        else:
            enriched['review_reason'] = 'Template matched' if matched else 'Template not matched'
        enriched['tier'] = TIER_AUTO if matched else TIER_MANUAL
        result.append(enriched)
    return result


def note_totals_from_mapping(note_mapping):
    """Build ``{normalised_note_num: {'cy':.., 'py':..}}`` from the BS/PL ↔ note
    mapping, so a note's total can be anchored to the authoritative BS/PL figure."""
    totals = {}
    for row in note_mapping or []:
        key = normalize_name(row.get('note_num', ''))
        if not key:
            continue
        cy = _to_number(row.get('bs_cy'))
        py = _to_number(row.get('bs_py'))
        if cy is None and py is None:
            continue
        # Keep the first non-empty total seen for a note number.
        totals.setdefault(key, {'cy': cy, 'py': py})
    return totals


def _bs_value_for_keywords(note_mapping, keywords):
    """Find a concept's BS/PL figure from the BS<->note mapping by matching a
    keyword (e.g. ``"deferred tax"``) against the mapped BS particular or the
    matched note heading. Used to suggest a value when the note-number link is
    missing or misaligned. Returns ``{'cy':.., 'py':..}`` or ``{}``."""
    kws = [normalize_name(k) for k in keywords if k]
    for row in note_mapping or []:
        hay = normalize_name(row.get('bs_particular', '')) + \
            normalize_name(row.get('matched_note', ''))
        if not any(k and k in hay for k in kws):
            continue
        cy = _to_number(row.get('bs_cy'))
        py = _to_number(row.get('bs_py'))
        if cy is None and py is None:
            continue
        return {'cy': cy, 'py': py}
    return {}


def _apply_fixed_asset_sections(review, notes_data, filepath):
    """Override ``Gross Block`` / ``Accumulated Depreciation`` / ``Total`` lines
    of fixed-asset (matrix) sections with the value read from the note's own
    ``Total`` column. The ordinary parser reads an asset-class column for these
    notes, so its figures are wrong — this is the authoritative source for them.
    """
    if not filepath:
        return
    try:
        from src.core.visible_data_engine import read_visible_grid
        from src.core.fixed_asset_parser import (
            extract_fa_sections, select_cy_py, fa_field_for_particular)
    except Exception as e:  # noqa: BLE001
        logger.warning("Fixed-asset parser unavailable: %s", e)
        return

    fa = []   # [(normalised_heading, chosen_values)]
    for sheet in (notes_data or {}).keys():
        try:
            grid = read_visible_grid(filepath, sheet)
        except Exception:  # noqa: BLE001
            continue
        for heading, tables in extract_fa_sections(grid).items():
            chosen = select_cy_py(tables)
            if chosen:
                fa.append((normalize_name(heading), chosen))
    if not fa:
        return

    for it in review:
        field = fa_field_for_particular(it.get('particular', ''))
        if not field:
            continue
        sec = normalize_name(it.get('section', ''))
        chosen = None
        # Require a reasonably long, specific section name so a short token can't
        # accidentally match the wrong fixed-asset block.
        if sec and len(sec) >= 8:
            for nh, ch in fa:
                if sec in nh or nh in sec:
                    chosen = ch
                    break
        if not chosen:
            continue
        vals = chosen.get(field) or {}
        cy, py = vals.get('cy'), vals.get('py')
        if cy is None and py is None:
            continue
        it['value_cy'], it['value_py'] = cy, py
        it['bs_cy'] = cy if cy is not None else '-'
        it['bs_py'] = py if py is not None else '-'
        it['note_cy'] = cy if cy is not None else '-'
        it['note_py'] = py if py is not None else '-'
        it['suggested_cy'] = it['suggested_py'] = None
        it['template_matched'] = cy is not None
        it['tier'] = TIER_AUTO if cy is not None else TIER_MANUAL
        it['review_reason'] = 'Matched from fixed-asset schedule (Total column)'


def _value_present_for_section(value, notes_data, section):
    """True if ``value`` appears in the VISIBLE data of the note that matches
    ``section`` — used to stop a stale reusable rule (saved from another file)
    from being applied to a note where that figure does not actually exist."""
    if value is None:
        return False
    ns = normalize_name(section)
    for g in _flatten_note_groups(notes_data):
        nh = normalize_name(g.get('note_heading', ''))
        if not nh:
            continue
        related = (ns in nh or nh in ns
                   or difflib.SequenceMatcher(None, ns, nh).ratio() >= 0.6)
        if not related:
            continue
        for d in g.get('data', []):
            for axis in ('cy', 'py'):
                f = _to_number(d.get(axis))
                if f is not None and _values_close(f, value):
                    return True
    return False


# Notes that must ALWAYS be surfaced in the Manual Review panel (lifted in
# as-is) because their structure is unreliable to auto-extract — the auditor
# verifies / maps them by hand.
# Note types lifted into review as ONE clean suggestion line anchored to the BS
# figure (the user confirms/overrides). Intangibles and Right-of-use are handled
# instead by forcing their existing template SECTION to manual (see below), so we
# don't dump their whole movement schedule into the panel.
FORCE_REVIEW_KEYWORDS = {
    'share capital': 'Share Capital',
    'deferred tax': 'Deferred Tax & Liabilities',
    'income tax': 'Income Tax',
}

# Template sections that must ALWAYS show for manual verification (suggest-only).
FORCE_REVIEW_SECTIONS = ('intangible', 'right of use', 'rightofuse')


def _force_review_notes(review, notes_data, note_totals=None, note_mapping=None):
    """Force notes into review:
      * **Intangible Assets** — flag the existing template section so it always
        appears for manual verification;
      * **Share Capital** — anchored to the BS amount: if the BS already has it,
        it is NOT shown in review (resolved); otherwise ONE line is surfaced for
        the user to select the amount manually;
      * **Deferred Tax** — ALWAYS surfaced as one user-selection line (even when
        the source notes carry no deferred-tax note), with the BS figure
        suggested. The BS value is resolved by note number first, then by name
        from ``note_mapping`` so a missing/misaligned note link still suggests.

    ``note_totals`` is ``{normalised_note_num: {'cy':.., 'py':..}}`` from the
    BS/PL ↔ note mapping (the authoritative figures).
    """
    # 1) Always flag the Intangibles + Right-of-use template sections for review.
    for it in review:
        sec = normalize_name(it.get('section', ''))
        if any(normalize_name(k) in sec for k in FORCE_REVIEW_SECTIONS):
            it['template_matched'] = False
            it['tier'] = TIER_MANUAL
            it['review_reason'] = 'Forced manual review — verify against the note'

    # 2) Lift Share Capital + Deferred Tax notes in as-is, each line flagged.
    idxs = [int(it['_index']) for it in review
            if str(it.get('_index', '')).lstrip('-').isdigit()]
    next_idx = (max(idxs) + 1) if idxs else len(review)
    seen = set()
    deferred_added = False  # ensure deferred tax is always surfaced once
    for sheet, groups in (notes_data or {}).items():
        for g in groups:
            hnorm = normalize_name(g.get('note_heading', ''))
            for kw, label in FORCE_REVIEW_KEYWORDS.items():
                if normalize_name(kw) not in hnorm:
                    continue
                tag = (label, str(g.get('note_num', '')), sheet)
                if tag in seen:
                    continue
                seen.add(tag)

                # Share Capital: anchor to the authoritative BS figure. If the BS
                # already carries this note's amount, the share capital is
                # resolved (it shows in the BS Analysis sheet) — do NOT clutter
                # the Review panel with the note's many sub-rows. Only when the BS
                # amount is missing do we surface ONE line for the user to select
                # the amount manually.
                if kw == 'share capital':
                    bs_total = (note_totals or {}).get(
                        normalize_name(g.get('note_num', '')), {})
                    if bs_total.get('cy') is not None or bs_total.get('py') is not None:
                        continue  # found in BS -> not shown in review
                    review.append({
                        'section': label,
                        'particular': 'Issued, Subscribed and Paid-up',
                        'sheet': sheet, 'row': '-',
                        'note_num': g.get('note_num', ''),
                        'value_cy': None, 'value_py': None,
                        'matched_note': g.get('note_heading', ''),
                        'bs_particular': 'Issued, Subscribed and Paid-up',
                        'bs_cy': '-', 'bs_py': '-', 'note_cy': '-', 'note_py': '-',
                        'suggested_cy': None, 'suggested_py': None,
                        'template_matched': False,
                        'tier': TIER_MANUAL,
                        'review_reason': 'Share capital not found in BS — select the amount',
                        '_index': next_idx,
                    })
                    next_idx += 1
                    continue

                # Deferred / Income tax are multi-table movement schedules the
                # parser splits/mislabels. Show just ONE ending line — the net —
                # with the authoritative BS figure suggested, instead of dumping
                # the messy movement rows into the panel.
                if kw in ('deferred tax', 'income tax'):
                    # Income tax and deferred tax often share ONE source note
                    # (e.g. note 26 "Deferred and Income tax"), so anchoring by
                    # note number cross-wires the two — the income-tax line would
                    # get the deferred-tax figure. Resolve the BS figure by NAME
                    # first (which distinguishes them), and only fall back to the
                    # note-number total when the name lookup finds nothing.
                    kwbs = _bs_value_for_keywords(note_mapping, [kw])
                    cy, py = kwbs.get('cy'), kwbs.get('py')
                    if cy is None and py is None:
                        bs_total = (note_totals or {}).get(
                            normalize_name(g.get('note_num', '')), {})
                        cy, py = bs_total.get('cy'), bs_total.get('py')
                    if kw == 'deferred tax':
                        deferred_added = True
                    net_name = ('Deferred tax assets (net)' if kw == 'deferred tax'
                                else 'Income tax assets (net)')
                    review.append({
                        'section': label,
                        'particular': net_name,
                        'sheet': sheet, 'row': '-',
                        'note_num': g.get('note_num', ''),
                        'value_cy': None, 'value_py': None,
                        'matched_note': g.get('note_heading', ''),
                        'bs_particular': net_name,
                        'bs_cy': cy if cy is not None else '-',
                        'bs_py': py if py is not None else '-',
                        'note_cy': cy if cy is not None else '-',
                        'note_py': py if py is not None else '-',
                        'suggested_cy': cy, 'suggested_py': py,
                        'template_matched': False,
                        'tier': TIER_MANUAL,
                        'review_reason': (f'{net_name} — confirm the BS figure'
                                          if cy is not None
                                          else f'{net_name} — select the amount'),
                        '_index': next_idx,
                    })
                    next_idx += 1
                    continue

                lines = [d for d in g.get('data', [])
                         if str(d.get('particulars', '')).strip()]
                if not lines:
                    lines = [{'particulars': g.get('note_heading', label) or label,
                              'cy': None, 'py': None}]
                for d in lines:
                    cy, py = d.get('cy'), d.get('py')
                    review.append({
                        'section': label,
                        'particular': d.get('particulars', ''),
                        'sheet': sheet,
                        'row': d.get('row_num', '-'),
                        'note_num': g.get('note_num', ''),
                        'value_cy': cy, 'value_py': py,
                        'matched_note': g.get('note_heading', ''),
                        'bs_particular': d.get('particulars', ''),
                        'bs_cy': cy if cy is not None else '-',
                        'bs_py': py if py is not None else '-',
                        'note_cy': cy if cy is not None else '-',
                        'note_py': py if py is not None else '-',
                        'suggested_cy': None, 'suggested_py': None,
                        'template_matched': False,
                        'tier': TIER_MANUAL,
                        'review_reason': 'Forced manual review (note lifted as-is)',
                        '_index': next_idx,
                    })
                    next_idx += 1

    # Deferred tax must ALWAYS be available as a user-selection line — even when
    # the source notes carry no deferred-tax note at all. Suggest the BS figure
    # (resolved by name from the mapping); if none exists, surface an empty line
    # for the user to fill. Applying the suggestion sets this single net figure.
    if not deferred_added:
        kwbs = _bs_value_for_keywords(note_mapping, ['deferred tax'])
        cy, py = kwbs.get('cy'), kwbs.get('py')
        net_name = 'Deferred tax assets (net)'
        review.append({
            'section': 'Deferred Tax & Liabilities',
            'particular': net_name,
            'sheet': '-', 'row': '-',
            'note_num': '',
            'value_cy': None, 'value_py': None,
            'matched_note': '',
            'bs_particular': net_name,
            'bs_cy': cy if cy is not None else '-',
            'bs_py': py if py is not None else '-',
            'note_cy': cy if cy is not None else '-',
            'note_py': py if py is not None else '-',
            'suggested_cy': cy, 'suggested_py': py,
            'template_matched': False,
            'tier': TIER_MANUAL,
            'review_reason': (f'{net_name} — confirm the BS figure'
                              if cy is not None
                              else f'{net_name} — select the amount'),
            '_index': next_idx,
        })
        next_idx += 1
    return review


def build_template_review(notes_data, template_path=None, store=None,
                          note_mapping=None, filepath=None):
    """Top-level: build the template-driven review list, applying any reusable
    rules saved from previous manual corrections.

    ``note_mapping`` (the BS/PL ↔ note linkage) lets ``Total`` lines be anchored
    to the BS/PL figure and verified against the note (see ``match_to_template``).
    ``filepath`` enables reading fixed-asset (matrix) schedules from the source
    workbook's ``Total`` column.
    """
    items = load_template_structure(template_path)
    note_totals = note_totals_from_mapping(note_mapping)
    review = match_to_template(items, notes_data, note_totals=note_totals)
    _apply_fixed_asset_sections(review, notes_data, filepath)
    if store is None:
        try:
            store = MappingStore()
        except Exception:
            store = None
    if store:
        for it in review:
            if it['template_matched']:
                continue
            rule = store.get(it['section'], it['particular'])
            if not (rule and rule.get('cy') is not None):
                continue
            # Only reuse a saved rule when its figure actually exists in this
            # file's visible note — otherwise a stale rule from another client
            # would silently fill a wrong value and hide a real problem.
            if not _value_present_for_section(rule.get('cy'), notes_data, it['section']):
                continue
            it['value_cy'] = rule.get('cy')
            it['bs_cy'] = rule.get('cy')
            it['note_cy'] = rule.get('cy')
            if rule.get('py') is not None:
                it['value_py'] = rule.get('py')
                it['bs_py'] = rule.get('py')
                it['note_py'] = rule.get('py')
            it['template_matched'] = True
            it['tier'] = TIER_AUTO
            it['review_reason'] = 'Template matched (reused rule)'

    # Force Share Capital / Deferred Tax / Intangible Assets into the review.
    _force_review_notes(review, notes_data, note_totals=note_totals,
                        note_mapping=note_mapping)

    # Don't nag the user to "fill" breakdown lines that aren't separately in the
    # source. If a section's Total is already captured, its un-matchable sub-lines
    # carry no figure to enter (you can't provide what isn't in the sheet) — mark
    # them as covered by the total so the panel stops flagging them. Forced lines
    # that carry a BS/PL suggestion (share capital / tax) are untouched, and
    # sections whose Total is NOT captured stay flagged (a real gap).
    _matched_total_secs = {
        it.get('section') for it in review
        if it.get('template_matched') and _is_total_particular(it.get('particular', ''))
    }
    for it in review:
        if (it.get('section') in _matched_total_secs
                and not it.get('template_matched')
                and not _is_total_particular(it.get('particular', ''))
                and it.get('value_cy') is None and it.get('value_py') is None
                and it.get('suggested_cy') is None and it.get('suggested_py') is None):
            it['template_matched'] = True
            it['tier'] = TIER_AUTO
            it['review_reason'] = 'Covered by section total — not separately disclosed in source'

    return review


def overrides_from_store(note_mapping, store):
    """Build an overrides dict from any reusable rules matching the mapping.

    Returns ``{index: override}`` for every mapping row that has a stored rule.
    """
    auto = {}
    for idx, row in enumerate(note_mapping or []):
        rule = store.get(row.get('note_num', ''), row.get('bs_particular', ''))
        if rule:
            auto[str(idx)] = {
                'cy': rule.get('cy'),
                'py': rule.get('py'),
                'source': rule.get('source', 'stored rule'),
                'source_row': rule.get('source_row'),
            }
    return auto
