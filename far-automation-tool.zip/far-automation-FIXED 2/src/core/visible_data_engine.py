"""
visible_data_engine.py
======================

Dedicated "human-visible data" engine.

This is the SINGLE authority that decides what a human actually sees on an Excel
sheet. Every consumer (the parser that builds the report values AND the Manual
Review grid in the GUI) reads through this engine, so the numbers shown in the
UI always match the numbers extracted into the report — and never include data
the user deliberately hid.

A cell is treated as INVISIBLE (and therefore dropped) when any of these hold:

  * its sheet is hidden / very-hidden            -> the whole sheet is skipped
  * its row is hidden (``hidden``, ``ht=0``, or a collapsed outline group)
  * its column is hidden (``hidden``, ``width=0``, or a collapsed outline group)
  * its number format hides the value (``;;;`` / ``;;`` "hide cell contents")
  * its font is invisible against the fill (classic white-on-white text)

The engine never trusts openpyxl's drifting read-only row index for the hidden
test: hidden rows/cols come straight from the sheet XML (the source of truth),
and per-cell style invisibility comes from the cell's real ``cell.row`` /
``cell.column``.
"""

import io
import os
import re
import logging
import zipfile
import datetime as _dt
import xml.etree.ElementTree as ET

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

# Last-resort guard against a pathological multi-million-row workbook locking the
# UI. Normal note sheets are far below these, so the whole visible sheet shows.
MAX_ROWS = 200000
MAX_COLS = 256

_NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
_R_NS = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
_PKG_NS = '{http://schemas.openxmlformats.org/package/2006/relationships}'

# Scan cache keyed by (filepath, mtime, sheet) so the parser and the GUI don't
# read the same sheet twice.
_SCAN_CACHE = {}
_SCAN_CACHE_MAX = 64


# Value formatting (how Excel shows a cell)
def format_cell(v):
    """Render a value the way Excel displays it, so the UI grid matches the
    source sheet: whole numbers without a trailing ``.0``, dates as dd-Mon-yy."""
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'TRUE' if v else 'FALSE'
    if isinstance(v, _dt.datetime):
        if v.hour == 0 and v.minute == 0 and v.second == 0:
            return v.strftime('%d-%b-%y')
        return v.strftime('%d-%b-%y %H:%M')
    if isinstance(v, _dt.date):
        return v.strftime('%d-%b-%y')
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return repr(v) if len(repr(v)) < 16 else f'{v:g}'
    return str(v)


# Invisibility predicates
def _numfmt_hides(fmt):
    """True for the deliberate "hide cell contents" formats ``;;`` and ``;;;``
    (every section empty), which leave a value in the cell but show nothing."""
    if not fmt:
        return False
    return bool(re.fullmatch(r'\s*;{2,3}\s*', str(fmt)))


def _is_white_color(color):
    """True only when we are confident the colour is white (explicit white RGB,
    or theme 0 / 'Background 1' un-darkened). Conservative on purpose: we never
    want to drop legitimately-coloured, readable text."""
    if color is None:
        return False
    try:
        ctype = getattr(color, 'type', None)
        if ctype == 'rgb':
            rgb = color.rgb
            return isinstance(rgb, str) and rgb.upper() in ('FFFFFFFF', '00FFFFFF', 'FFFFFF')
        if ctype == 'theme':
            tint = getattr(color, 'tint', 0) or 0
            return getattr(color, 'theme', None) == 0 and tint >= 0
    except Exception:  # noqa: BLE001
        return False
    return False


def _fill_is_white_or_none(fill):
    """True when the cell has no fill (default white background) or a white
    fill — i.e. white text on it would be invisible."""
    try:
        if fill is None:
            return True
        if not getattr(fill, 'patternType', None):
            return True
        return _is_white_color(getattr(fill, 'fgColor', None))
    except Exception:  # noqa: BLE001
        return True


def _cell_is_invisible_by_style(cell):
    """Per-cell style invisibility: hidden number format or white-on-white."""
    try:
        if _numfmt_hides(getattr(cell, 'number_format', None)):
            return True
    except Exception:  # noqa: BLE001
        pass
    try:
        font = getattr(cell, 'font', None)
        if font is not None and _is_white_color(getattr(font, 'color', None)) \
                and _fill_is_white_or_none(getattr(cell, 'fill', None)):
            return True
    except Exception:  # noqa: BLE001
        pass
    return False


# Hidden rows / columns (straight from the sheet XML — the source of truth)
def get_hidden_rows_cols(filepath, sheet_name):
    """Return ``(hidden_rows, hidden_cols)`` (1-based) for a sheet, covering the
    ``hidden`` flag, zero height/width, and collapsed outline groups."""
    hidden_rows, hidden_cols = set(), set()
    try:
        with zipfile.ZipFile(filepath, 'r') as z:
            wb_root = ET.fromstring(z.read('xl/workbook.xml'))
            r_id = None
            for sheet in wb_root.findall(f'.//{_NS}sheet'):
                if sheet.get('name') == sheet_name:
                    r_id = sheet.get(f'{_R_NS}id')
                    break
            if not r_id:
                return hidden_rows, hidden_cols

            rels_root = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
            target = None
            for rel in rels_root.findall(f'.//{_PKG_NS}Relationship'):
                if rel.get('Id') == r_id:
                    target = rel.get('Target')
                    break
            if not target:
                return hidden_rows, hidden_cols

            target_clean = target.lstrip('/')
            target_path = target_clean if target_clean.startswith('xl/') else 'xl/' + target_clean

            sheet_xml = z.read(target_path)
            for _evt, elem in ET.iterparse(io.BytesIO(sheet_xml), events=('start',)):
                tag = elem.tag.split('}')[-1]
                if tag == 'col':
                    hidden = elem.get('hidden') in ('1', 'true')
                    width = elem.get('width')
                    if width is not None:
                        try:
                            hidden = hidden or float(width) == 0
                        except ValueError:
                            pass
                    if hidden:
                        try:
                            c_min, c_max = int(elem.get('min')), int(elem.get('max'))
                            hidden_cols.update(range(c_min, c_max + 1))
                        except (TypeError, ValueError):
                            pass
                elif tag == 'row':
                    hidden = elem.get('hidden') in ('1', 'true')
                    ht = elem.get('ht')
                    if ht is not None:
                        try:
                            hidden = hidden or float(ht) == 0
                        except ValueError:
                            pass
                    if hidden:
                        try:
                            hidden_rows.add(int(elem.get('r')))
                        except (TypeError, ValueError):
                            pass
                elem.clear()
    except Exception as e:  # noqa: BLE001
        logger.warning("Hidden-row/col scan failed for sheet '%s': %s", sheet_name, e)
    return hidden_rows, hidden_cols


def visible_sheet_names(filepath):
    """Names of sheets that are not hidden / very-hidden."""
    try:
        wb = load_workbook(filepath, data_only=True, read_only=True)
        names = [n for n in wb.sheetnames
                 if getattr(wb[n], 'sheet_state', 'visible') == 'visible']
        wb.close()
        return names
    except Exception as e:  # noqa: BLE001
        logger.error("visible_sheet_names failed for %s: %s", filepath, e)
        return []


# Core scan: one pass that yields everything the consumers need
def _scan_sheet(filepath, sheet_name):
    """Scan one sheet and return a dict with the visible-value map plus the
    hidden/invisible sets. Cached by (filepath, mtime, sheet)."""
    try:
        mtime = os.path.getmtime(filepath)
    except OSError:
        mtime = 0
    key = (filepath, mtime, sheet_name)
    cached = _SCAN_CACHE.get(key)
    if cached is not None:
        return cached

    hidden_rows, hidden_cols = get_hidden_rows_cols(filepath, sheet_name)
    cells = {}                 # (row, col) -> raw value, visible only
    invisible_cells = set()    # (row, col) dropped by number-format / font
    max_row = max_col = 0

    wb = load_workbook(filepath, data_only=True, read_only=True)
    try:
        ws = wb[sheet_name]
        seen = 0
        for row in ws.iter_rows():
            seen += 1
            if seen > MAX_ROWS:
                break
            for cell in row:
                # read_only mode can yield EmptyCell objects with no row/column.
                r = getattr(cell, 'row', None)
                c = getattr(cell, 'column', None)
                if r is None or c is None or c > MAX_COLS:
                    continue
                if r in hidden_rows or c in hidden_cols:
                    continue
                if cell.value is None:
                    continue
                if _cell_is_invisible_by_style(cell):
                    invisible_cells.add((r, c))
                    continue
                cells[(r, c)] = cell.value
                if r > max_row:
                    max_row = r
                if c > max_col:
                    max_col = c
    finally:
        try:
            wb.close()
        except Exception:  # noqa: BLE001
            pass

    result = {
        'hidden_rows': hidden_rows,
        'hidden_cols': hidden_cols,
        'invisible_cells': invisible_cells,
        'cells': cells,
        'max_row': max_row,
        'max_col': min(max_col, MAX_COLS),
    }
    if len(_SCAN_CACHE) >= _SCAN_CACHE_MAX:
        _SCAN_CACHE.clear()
    _SCAN_CACHE[key] = result
    return result


def get_sheet_visibility(filepath, sheet_name):
    """Return ``(hidden_rows, hidden_cols, invisible_cells)`` for a sheet from a
    single cached scan, so the parser doesn't parse the sheet XML twice (once for
    hidden rows/cols and again for invisible cells)."""
    try:
        scan = _scan_sheet(filepath, sheet_name)
        return (set(scan['hidden_rows']), set(scan['hidden_cols']),
                set(scan['invisible_cells']))
    except Exception as e:  # noqa: BLE001
        logger.warning("get_sheet_visibility failed for '%s': %s", sheet_name, e)
        return set(), set(), set()


def read_visible_grid(filepath, sheet_name):
    """Build the Manual Review grid for one sheet using ONLY human-visible data.

    Returns ``{'col_letters', 'row_numbers', 'rows', 'n_rows', 'n_cols'}`` with
    real Excel row numbers / column letters preserved so the grid lines up with
    the source sheet."""
    scan = _scan_sheet(filepath, sheet_name)
    cells = scan['cells']
    hidden_rows, hidden_cols = scan['hidden_rows'], scan['hidden_cols']
    max_row, max_col = scan['max_row'], scan['max_col']

    if not cells:
        return {'col_letters': [], 'row_numbers': [], 'rows': [],
                'n_rows': 0, 'n_cols': 0}

    visible_cols = [c for c in range(1, max_col + 1) if c not in hidden_cols]
    col_letters = [get_column_letter(c) for c in visible_cols]

    rows, row_numbers = [], []
    for r in range(1, max_row + 1):
        if r in hidden_rows:
            continue
        out = [format_cell(cells.get((r, c))) for c in visible_cols]
        rows.append(out)
        row_numbers.append(r)

    return {
        'col_letters': col_letters,
        'row_numbers': row_numbers,
        'rows': rows,
        'n_rows': len(rows),
        'n_cols': len(visible_cols),
    }


def load_visible_workbook(filepath):
    """Load every visible sheet into review-grid form. Returns the payload the
    GUI expects: ``{'sheets': [...], 'grids': {name: grid}}``."""
    sheets, grids = [], {}
    for name in visible_sheet_names(filepath):
        try:
            grids[name] = read_visible_grid(filepath, name)
            sheets.append(name)
        except Exception as e:  # noqa: BLE001
            logger.warning("Failed to read visible grid for '%s': %s", name, e)
    return {'sheets': sheets, 'grids': grids}
