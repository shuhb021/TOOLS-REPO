import re
import os
import logging
import threading
from collections import OrderedDict
from openpyxl import load_workbook

from src.core.visible_data_engine import get_sheet_visibility

_WB_CACHE = OrderedDict()
_WB_CACHE_MAX = 10
_WB_CACHE_LOCK = threading.RLock()

def _return_and_evict(filepath):
    while len(_WB_CACHE) > _WB_CACHE_MAX:
        _, oldest_wb = _WB_CACHE.popitem(last=False)
        try: oldest_wb.close()
        except Exception: pass
    return _WB_CACHE[filepath]

def get_cached_workbook(filepath):
    with _WB_CACHE_LOCK:
        if not os.path.exists(filepath):
            raise FileNotFoundError(filepath)

        ext = os.path.splitext(filepath)[1].lower()
        if ext not in ('.xlsx', '.xls', '.xlsb', '.xlsm'):
            raise ValueError(f"Unsupported file type: {ext}")

        with open(filepath, 'rb') as f:
            magic = f.read(4)
        if ext in ('.xlsx', '.xlsm') and magic != b'PK\x03\x04':
            raise ValueError("File does not appear to be a valid Excel file")

        size_mb = os.path.getsize(filepath) / (1024 * 1024)
        if size_mb > 100:
            raise ValueError(f"File too large ({size_mb:.0f} MB). Maximum is 100 MB.")

        if filepath in _WB_CACHE:
            _WB_CACHE.move_to_end(filepath)
            return _WB_CACHE[filepath]

        logging.getLogger(__name__).info("Loading workbook into cache (read_only=True): %s", filepath)
        try:
            _WB_CACHE[filepath] = load_workbook(filepath, data_only=True, read_only=True)
            return _return_and_evict(filepath)
        except Exception as e:
            error_msg = str(e)
            if '.xlsb' in filepath.lower() or 'binary' in error_msg.lower():
                try:
                    import shutil, subprocess, tempfile, glob
                    soffice = shutil.which('soffice') or shutil.which('libreoffice')
                    if soffice:
                        tmpdir = tempfile.mkdtemp(prefix='far_xlsb_conv_')
                        try:
                            cmd = [soffice, '--headless', '--convert-to', 'xlsx', filepath, '--outdir', tmpdir]
                            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                            converted = glob.glob(os.path.join(tmpdir, '*.xlsx'))
                            if converted:
                                conv_path = converted[0]
                                logging.getLogger(__name__).info("Converted .xlsb to .xlsx via LibreOffice: %s", conv_path)
                                _WB_CACHE[filepath] = load_workbook(conv_path, data_only=True, read_only=True)
                                return _return_and_evict(filepath)
                        finally:
                            shutil.rmtree(tmpdir, ignore_errors=True)
                except Exception:
                    pass



                try:
                    try:
                        import pyxlsb2 as _pyxlsb_mod
                        try:
                            from collections import defaultdict
                            if hasattr(_pyxlsb_mod, 'ptgs') and hasattr(_pyxlsb_mod.ptgs, 'function_names'):
                                _pyxlsb_mod.ptgs.function_names = defaultdict(lambda: [''], _pyxlsb_mod.ptgs.function_names)
                        except Exception:
                            pass
                        xlsb_open = _pyxlsb_mod.open_workbook
                    except Exception:
                        try:
                            from pyxlsb import open_workbook as xlsb_open
                        except Exception:
                            raise

                    class _XlsbSheet:
                        def __init__(self, sheet):
                            self._sheet = sheet
                            self._rows = list(sheet.rows())
                            self.max_row = len(self._rows)
                            self.max_column = 0
                            for r in self._rows:
                                self.max_column = max(self.max_column, len(r))
                            self.sheet_state = 'visible'

                        def iter_rows(self, values_only=False):
                            for r in self._rows:
                                cells = []
                                for v in r:
                                    val = None
                                    try:
                                        val = v.v
                                    except Exception:
                                        try:
                                            val = v.value
                                        except Exception:
                                            val = v
                                    class _Cell:
                                        def __init__(self, value):
                                            self.value = value
                                            self.font = type('F', (), {'bold': False})()
                                    cells.append(_Cell(val))
                                yield tuple(cells)

                    class _XlsbWB:
                        def __init__(self, path):
                            self._sheets = {}
                            self.sheetnames = []
                            self._wb = xlsb_open(path)
                            try:
                                names = list(self._wb.sheets)
                            except Exception:
                                try:
                                    names = list(self._wb.sheet_names)
                                except Exception:
                                    names = []
                            for name in names:
                                self.sheetnames.append(name)
                                sh = self._wb.get_sheet(name)
                                self._sheets[name] = _XlsbSheet(sh)

                        def __contains__(self, name):
                            return name in self._sheets

                        def __getitem__(self, name):
                            return self._sheets[name]
                            
                        def close(self):
                            if hasattr(self, '_wb') and self._wb:
                                self._wb.close()

                    wb_xlsb = _XlsbWB(filepath)
                    _WB_CACHE[filepath] = wb_xlsb
                    logging.getLogger(__name__).info("Loaded .xlsb via pyxlsb fallback: %s", filepath)
                    return _return_and_evict(filepath)
                except Exception as e2:
                    logging.getLogger(__name__).exception("pyxlsb fallback failed")
                    raise ValueError(
                        f"ERROR: openpyxl cannot read .xlsb (Excel binary) files.\n"
                        f"File: {filepath}\n"
                        f"Please convert this file to .xlsx format first, or ensure 'pyxlsb2' is installed.\n"
                        f"Original error: {error_msg}\nFallback error: {e2}"
                    ) from e2
            else:
                raise ValueError(f"Failed to load workbook {filepath}: {error_msg}") from e

        return _return_and_evict(filepath)

def clear_workbook_cache():
    global _WB_CACHE
    for wb in _WB_CACHE.values():
        wb.close()
    _WB_CACHE.clear()

# Lightweight, reusable cell/font stubs. SheetWrapper.cell() used to define a
# fresh class on *every* call (~8.5 us/call); for big sheets the parser makes
# tens of thousands of cell() calls, so that overhead dominated parsing. Callers
# only ever read .value and .font.bold (never mutate), so we can share immutable
# stub instances instead.
class _FontStub:
    __slots__ = ('bold',)
    def __init__(self, bold):
        self.bold = bold

class _CellStub:
    __slots__ = ('value', 'font')
    def __init__(self, value, font):
        self.value = value
        self.font = font

_FONT_BOLD = _FontStub(True)
_FONT_NORMAL = _FontStub(False)
_EMPTY_CELL = _CellStub(None, None)

class SheetWrapper:
    def __init__(self, ws, hidden_rows=None, hidden_cols=None, invisible_cells=None):
        from openpyxl.utils import column_index_from_string
        self.cells = {}
        self.hidden_rows = hidden_rows if hidden_rows is not None else set()
        self.hidden_cols = hidden_cols if hidden_cols is not None else set()
        # Cells that hold a value but are invisible to a human (hidden number
        # format like ';;;', or white-on-white font). Supplied by
        # visible_data_engine so extraction never picks up hidden helper data.
        self.invisible_cells = invisible_cells if invisible_cells is not None else set()

        # IMPORTANT: use each cell's ACTUAL row/column (cell.row / cell.column),
        # NOT the enumerate() position. In read_only mode the iteration index can
        # drift from the real Excel row number (bad <dimension>, merged headers),
        # which made hidden-row exclusion line up with the wrong rows and let
        # hidden data leak into extraction. cell.row matches the XML row numbers
        # that get_hidden_rows_cols() reports, so hidden rows are skipped exactly.
        actual_max_row = 0
        actual_max_col = 0
        for row in ws.iter_rows(values_only=False):
            for cell in row:
                # read_only mode can yield EmptyCell objects with no row/column.
                r_idx = getattr(cell, 'row', None)
                c_idx = getattr(cell, 'column', None)
                if r_idx is None or c_idx is None:
                    continue
                if isinstance(c_idx, str):
                    c_idx = column_index_from_string(c_idx)
                if r_idx in self.hidden_rows or c_idx in self.hidden_cols:
                    continue
                if (r_idx, c_idx) in self.invisible_cells:
                    continue
                if cell.value is not None:
                    try:
                        is_bold = bool(cell.font and cell.font.bold)
                    except Exception:
                        is_bold = False
                    self.cells[(r_idx, c_idx)] = (cell.value, is_bold)
                    if r_idx > actual_max_row:
                        actual_max_row = r_idx
                    if c_idx > actual_max_col:
                        actual_max_col = c_idx

        # Robust extents even if the sheet's declared dimension is wrong.
        self.max_row = max(ws.max_row or 0, actual_max_row)
        self.max_column = max(ws.max_column or 0, actual_max_col)

    def cell(self, row, column):
        data = self.cells.get((row, column))
        if data is None:
            return _EMPTY_CELL
        return _CellStub(data[0], _FONT_BOLD if data[1] else _FONT_NORMAL)

logger = logging.getLogger(__name__)

def _is_bold(cell):
    try:
        return cell.font and cell.font.bold
    except Exception:
        return False

def _get_value(cell):
    v = cell.value
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        stripped = v.strip()
        if stripped == '':
            return None
        if stripped in ('-', '--', '—', '–', 'nil', 'n/a', 'na', 'N/A', 'NA', 'Nil'):
            return '-'
        cleaned = stripped.replace(',', '').replace(' ', '')
        
        for sym in ('₹', '$', '£', '€', 'Rs.', 'Rs'):
            cleaned = cleaned.replace(sym, '')
            
        if cleaned.startswith('(') and cleaned.endswith(')'):
            cleaned = '-' + cleaned[1:-1]
        try:
            return float(cleaned)
        except (ValueError, TypeError):
            return None
    return None

def _get_text(cell):
    v = cell.value
    if v is None:
        return ''
    return str(v).strip()

def _extract_client_name(ws):
    candidates = []
    reject_words = ('balance', 'sheet', 'profit', 'loss', 'statement', 'as at', 'for the',
                    'audited', 'particular', 'amount', 'lacs', 'lakhs', 'year ended',
                    'figures', 'note no', 'in rs', 'in ₹', 'rupees')
    for r in range(1, 7):
        for c in range(1, 7):
            try:
                cell = ws.cell(row=r, column=c)
            except Exception:
                continue
            txt = _get_text(cell)
            if not txt:
                continue
            low = txt.lower()
            if any(w in low for w in reject_words):
                continue
            # A client name contains letters. Reject dates, datetimes and pure
            # numbers — e.g. a '31 March 2025' header cell stringifies to
            # '2025-03-31 00:00:00' and was previously picked as the client name.
            if not re.search(r'[A-Za-z]', txt) or len(txt.strip()) < 3:
                continue
            is_bold = False
            try:
                is_bold = bool(cell.font and getattr(cell.font, 'bold', False))
            except Exception:
                is_bold = False
            candidates.append((txt, is_bold))

    if not candidates:
        return ''

    bolds = [t for t, b in candidates if b]
    if bolds:
        return max(bolds, key=lambda s: len(s)).strip()
    return max([t for t, b in candidates], key=lambda s: len(s)).strip()

def _find_date_columns(ws, search_rows=range(5, 12), default_cy_year=2025, default_py_year=2024):
    date_cells = []
    hidden_rows = getattr(ws, 'hidden_rows', set())
    hidden_cols = getattr(ws, 'hidden_cols', set())

    for row_idx in search_rows:
        if row_idx > ws.max_row:
            continue
        if row_idx in hidden_rows:
            continue
        for col_idx in range(2, ws.max_column + 1):
            if col_idx in hidden_cols:
                continue
            cell = ws.cell(row=row_idx, column=col_idx)
            val = cell.value
            year = None

            if hasattr(val, 'year') and hasattr(val, 'month'):
                if val.month == 3 and val.day == 31:
                    year = val.year

            elif isinstance(val, (int, float)):
                if val == int(val) and 2000 <= int(val) <= 2099:
                    year = int(val)

            elif isinstance(val, str):
                stripped = val.strip()
                if len(stripped) < 40:
                    m = re.search(r'\b(20\d{2})\b', stripped)
                    if m:
                        year = int(m.group(1))
                    else:
                        m2 = re.search(r'\b(?:march|mar|april|apr)\s*\'?(\d{2})\b', stripped, re.IGNORECASE)
                        if m2:
                            year = 2000 + int(m2.group(1))
                        else:
                            stripped_lower = stripped.lower()
                            if 'current year' in stripped_lower or 'cy' in stripped_lower.split():
                                year = default_cy_year
                            elif 'previous year' in stripped_lower or 'py' in stripped_lower.split():
                                year = default_py_year

            if year is not None:
                date_cells.append((row_idx, col_idx, year))

    if len(date_cells) < 2:
        return None, None, default_cy_year, default_py_year, None

    distinct_years = sorted(set(y for _, _, y in date_cells), reverse=True)

    cy_year_found = distinct_years[0]
    py_year_found = distinct_years[1] if len(distinct_years) >= 2 else cy_year_found - 1

    cy_candidates = [(r, c) for r, c, y in date_cells if y == cy_year_found]
    py_candidates = [(r, c) for r, c, y in date_cells if y == py_year_found]

    cy_row_set = set(r for r, c in cy_candidates)
    py_row_set = set(r for r, c in py_candidates)
    shared_rows = cy_row_set & py_row_set

    if shared_rows:
        header_row = min(shared_rows)
        def _score_col(c):
            # score the column header text to prefer "total" or "net"
            score = 0
            val = str(ws.cell(row=header_row, column=c).value or '').lower()
            if 'total' in val or 'net' in val or 'amount' in val: score += 10
            if 'gross' in val or 'addition' in val or 'deletion' in val: score -= 10
            return (score, c) # if tie, pick rightmost column
            
        cy_col = max([c for r, c in cy_candidates if r == header_row], key=_score_col)
        py_col = max([c for r, c in py_candidates if r == header_row], key=_score_col)
    else:
        header_row = cy_candidates[0][0]
        cy_col = cy_candidates[-1][1] # take rightmost
        py_col = py_candidates[-1][1] if py_candidates else cy_col + 1

    logging.getLogger(__name__).info(
        "Date headers found: CY=%d (col %d), PY=%d (col %d), header_row=%d",
        cy_year_found, cy_col, py_year_found, py_col, header_row
    )
    return cy_col, py_col, cy_year_found, py_year_found, header_row

def _find_part_note_columns(ws, header_row, default_part=1, default_note=3):
    logger = logging.getLogger(__name__)
    part_col   = default_part
    note_col   = default_note
    found_part = False
    found_note = False
    hidden_rows = getattr(ws, 'hidden_rows', set())
    hidden_cols = getattr(ws, 'hidden_cols', set())

    for r in range(max(1, header_row - 2), min(ws.max_row + 1, header_row + 2)):
        if r in hidden_rows:
            continue
        for c in range(1, ws.max_column + 1):
            if c in hidden_cols:
                continue
            val = str(ws.cell(row=r, column=c).value or '').lower().strip()
            if not found_part and ('particular' in val or 'description' in val):
                part_col = c
                found_part = True
            elif not found_note and ('note' in val or 'sch' in val):
                note_col = c
                found_note = True

    if not found_part:
        col_lengths = {1: 0, 2: 0, 3: 0, 4: 0}
        for r in range(header_row + 1, min(ws.max_row + 1, header_row + 15)):
            if r in hidden_rows:
                continue
            for c in range(1, 5):
                if c in hidden_cols:
                    continue
                val = str(ws.cell(row=r, column=c).value or '').strip()
                if not re.match(r'^[\d\.,\(\)\-]+$', val):
                    col_lengths[c] += len(val)

        best_col = max(col_lengths.items(), key=lambda x: x[1])
        if best_col[1] > 20:
            part_col = best_col[0]
            logger.info("Heuristic determined Particulars is in column %d (length sum=%d)", part_col, best_col[1])

    return part_col, note_col

def _append_adjustments(ws, row_idx, part_text, part_col, cy_col, py_col):
    for c in range(1, ws.max_column + 1):
        if c in (part_col, cy_col, py_col):
            continue
        val = _get_text(ws.cell(row=row_idx, column=c))
        if val and any(x in val.lower() for x in ['manual adj', 'round off adj', 'rounding off adj', 'matching']):
            clean_val = val.strip()
            if clean_val.lower() not in part_text.lower():
                return f"{part_text} ({clean_val})"
    return part_text

def parse_balance_sheet(filepath):
    wb = get_cached_workbook(filepath)

    target_sheet_name = None
    for name in ['BS', 'Balance Sheet', 'BalanceSheet']:
        if name in wb.sheetnames and wb[name].sheet_state == 'visible':
            target_sheet_name = name
            break
            
    if target_sheet_name is None:
        for name in wb.sheetnames:
            if wb[name].sheet_state == 'visible':
                target_sheet_name = name
                break
                
    if target_sheet_name is None:
        raise ValueError("No visible worksheets found in the workbook.")

    ws_obj = wb[target_sheet_name]
    hidden_rows, hidden_cols, invisible_cells = get_sheet_visibility(filepath, target_sheet_name)
    ws = SheetWrapper(ws_obj, hidden_rows=hidden_rows, hidden_cols=hidden_cols,
                      invisible_cells=invisible_cells)

    client_name = _extract_client_name(ws)

    cy_col, py_col, cy_year, py_year, header_row = _find_date_columns(ws)
    if cy_col is None:
        logger.warning("Could not find year headers in BS. Falling back to cols 3 and 4.")
        cy_col, py_col = 3, 4
        header_row = 5

    part_col, note_col = _find_part_note_columns(ws, header_row, default_part=1, default_note=3)
    logger.info("BS columns detected: Particulars=col %d, Notes=col %d", part_col, note_col)

    data = []
    notes = []
    signatures = []
    footers = []
    is_table_closed = False
    start_row = header_row + 1

    for row_idx in range(start_row, ws.max_row + 1):
        if row_idx in ws.hidden_rows:
            continue

        part_text = _get_text(ws.cell(row=row_idx, column=part_col))
        cy_val = _get_value(ws.cell(row=row_idx, column=cy_col))
        py_val = _get_value(ws.cell(row=row_idx, column=py_col))
        is_bold = _is_bold(ws.cell(row=row_idx, column=part_col))
        note_text = _get_text(ws.cell(row=row_idx, column=note_col))

        if part_text in ('', '-') and cy_val in (None, '-') and py_val in (None, '-'):
            continue

        row_class = _classify_row(ws, row_idx, part_text, cy_val, py_val, is_bold)

        if row_class == 'HEADER':
            continue

        if is_table_closed:
            row_cells = _extract_row_cells(ws, row_idx)
            if any(c not in ('', '-', None) for c in row_cells):
                if row_class == 'SIGNATURE':
                    signatures.append(row_cells)
                elif row_class == 'NOTE' or _is_narrative_text(part_text) or len(str(part_text)) > 40:
                    notes.append(row_cells)
                else:
                    footers.append(row_cells)
            continue

        if row_class == 'SIGNATURE':
            is_table_closed = True
            signatures.append(_extract_row_cells(ws, row_idx))
            continue

        if row_class == 'NOTE':
            notes.append(_extract_row_cells(ws, row_idx))
            continue

        if row_class == 'FOOTER':
            footers.append(_extract_row_cells(ws, row_idx))
            continue

        part_text = _append_adjustments(ws, row_idx, part_text, part_col, cy_col, py_col)
        row_data = {
            'particulars': part_text,
            'note': note_text,
            'cy': cy_val if cy_val is not None else None,
            'py': py_val if py_val is not None else None,
            'is_bold': is_bold,
            'row_num': row_idx
        }
        data.append(row_data)

        part_lower = part_text.lower().strip()

        # NOTE: In the standard Schedule III layout "Total equity and liabilities"
        # appears in the MIDDLE of the sheet (the ASSETS section follows it), so it
        # must NOT hard-close the table. Like any other total, only close the table
        # if no further financial-data rows follow (the genuine end is "Total assets").
        if "total" in part_lower:
            close_table = True
            for next_row_idx in range(row_idx + 1, min(row_idx + 11, ws.max_row + 1)):
                if next_row_idx in ws.hidden_rows:
                    continue
                next_part = _get_text(ws.cell(row=next_row_idx, column=part_col))
                if not next_part or next_part.strip() == '':
                    continue
                next_cy = _get_value(ws.cell(row=next_row_idx, column=cy_col))
                next_py = _get_value(ws.cell(row=next_row_idx, column=py_col))
                next_bold = _is_bold(ws.cell(row=next_row_idx, column=part_col))
                next_class = _classify_row(ws, next_row_idx, next_part, next_cy, next_py, next_bold)
                if next_class == 'FINANCIAL_DATA':
                    if next_cy is not None or next_py is not None:
                        close_table = False
                        break
            if close_table:
                is_table_closed = True

    notes = _meaningful_extra_rows(notes)
    signatures = _meaningful_extra_rows(signatures)
    footers = _meaningful_extra_rows(footers)

    logger.info("Parsed BS: %d rows, CY=%d, PY=%d, notes=%d, signatures=%d, footers=%d",
                len(data), cy_year, py_year, len(notes), len(signatures), len(footers))

    return {
        'data': data,
        'notes': notes,
        'signatures': signatures,
        'footers': footers,
        'cy_year': cy_year,
        'py_year': py_year,
        'client_name': client_name,
        'cy_col_letter': _col_letter(cy_col),
        'py_col_letter': _col_letter(py_col)
    }

def parse_profit_loss(filepath):
    wb = get_cached_workbook(filepath)

    target_sheet_name = None
    for name in ['PL', 'P&L', 'Profit & Loss', 'Profit and Loss', 'ProfitLoss']:
        if name in wb.sheetnames and wb[name].sheet_state == 'visible':
            target_sheet_name = name
            break
            
    if target_sheet_name is None:
        for name in wb.sheetnames:
            name_lower = name.lower()
            if wb[name].sheet_state == 'visible' and not any(x in name_lower for x in ['bs', 'balance sheet', 'cover page', 'dashboard']):
                target_sheet_name = name
                break

    if target_sheet_name is None:
        for name in wb.sheetnames:
            if wb[name].sheet_state == 'visible':
                target_sheet_name = name
                break

    if target_sheet_name is None:
        raise ValueError("No visible worksheets found in the workbook.")

    ws_obj = wb[target_sheet_name]
    hidden_rows, hidden_cols, invisible_cells = get_sheet_visibility(filepath, target_sheet_name)
    ws = SheetWrapper(ws_obj, hidden_rows=hidden_rows, hidden_cols=hidden_cols,
                      invisible_cells=invisible_cells)

    client_name = _extract_client_name(ws)

    cy_col, py_col, cy_year, py_year, header_row = _find_date_columns(ws)
    if cy_col is None:
        logger.warning("Could not find year headers in PL. Falling back to cols 3 and 4.")
        cy_col, py_col = 3, 4
        header_row = 5

    part_col, note_col = _find_part_note_columns(ws, header_row, default_part=1, default_note=2)
    if note_col == cy_col or note_col == py_col:
        note_col = None
    logger.info("PL columns detected: Particulars=col %d, Notes=col %s", part_col, note_col)

    data = []
    notes = []
    signatures = []
    footers = []
    is_table_closed = False
    start_row = header_row + 1

    for row_idx in range(start_row, ws.max_row + 1):
        if row_idx in ws.hidden_rows:
            continue

        part_text = _get_text(ws.cell(row=row_idx, column=part_col))
        cy_val = _get_value(ws.cell(row=row_idx, column=cy_col))
        py_val = _get_value(ws.cell(row=row_idx, column=py_col))
        is_bold = _is_bold(ws.cell(row=row_idx, column=part_col))
        note_text = _get_text(ws.cell(row=row_idx, column=note_col)) if note_col else ''

        if part_text in ('', '-') and cy_val in (None, '-') and py_val in (None, '-'):
            continue

        row_class = _classify_row(ws, row_idx, part_text, cy_val, py_val, is_bold)

        if row_class == 'HEADER':
            continue

        if is_table_closed:
            row_cells = _extract_row_cells(ws, row_idx)
            if any(c not in ('', '-', None) for c in row_cells):
                if row_class == 'SIGNATURE':
                    signatures.append(row_cells)
                elif row_class == 'NOTE' or _is_narrative_text(part_text) or len(str(part_text)) > 40:
                    notes.append(row_cells)
                else:
                    footers.append(row_cells)
            continue

        if row_class == 'SIGNATURE':
            is_table_closed = True
            signatures.append(_extract_row_cells(ws, row_idx))
            continue

        if row_class == 'NOTE':
            notes.append(_extract_row_cells(ws, row_idx))
            continue

        if row_class == 'FOOTER':
            footers.append(_extract_row_cells(ws, row_idx))
            continue

        part_text = _append_adjustments(ws, row_idx, part_text, part_col, cy_col, py_col)
        row_data = {
            'particulars': part_text,
            'note': note_text,
            'cy': cy_val if cy_val is not None else None,
            'py': py_val if py_val is not None else None,
            'is_bold': is_bold,
            'row_num': row_idx
        }
        data.append(row_data)

        part_lower = part_text.lower().strip()
        
        if any(term in part_lower for term in ['total comprehensive income', 'profit / (loss) for the year', 'profit/(loss) for the year']):
            is_table_closed = True
            
        elif "total" in part_lower or "profit" in part_lower or "loss" in part_lower:
            close_table = True
            for next_row_idx in range(row_idx + 1, min(row_idx + 11, ws.max_row + 1)):
                if next_row_idx in ws.hidden_rows:
                    continue
                next_part = _get_text(ws.cell(row=next_row_idx, column=part_col))
                if not next_part or next_part.strip() == '':
                    continue
                next_cy = _get_value(ws.cell(row=next_row_idx, column=cy_col))
                next_py = _get_value(ws.cell(row=next_row_idx, column=py_col))
                next_bold = _is_bold(ws.cell(row=next_row_idx, column=part_col))
                next_class = _classify_row(ws, next_row_idx, next_part, next_cy, next_py, next_bold)
                if next_class == 'FINANCIAL_DATA':
                    if next_cy is not None or next_py is not None:
                        close_table = False
                        break
            if close_table:
                is_table_closed = True

    notes = _meaningful_extra_rows(notes)
    signatures = _meaningful_extra_rows(signatures)
    footers = _meaningful_extra_rows(footers)

    logger.info("Parsed PL: %d rows, CY=%d, PY=%d, notes=%d, signatures=%d, footers=%d",
                len(data), cy_year, py_year, len(notes), len(signatures), len(footers))

    return {
        'data': data,
        'notes': notes,
        'signatures': signatures,
        'footers': footers,
        'cy_year': cy_year,
        'py_year': py_year,
        'client_name': client_name,
        'cy_col_letter': _col_letter(cy_col),
        'py_col_letter': _col_letter(py_col)
    }

def parse_notes(filepath, cy_year=2025, py_year=2024, target_notes=None):
    wb = get_cached_workbook(filepath)

    notes_sheet_names = []
    for sheet_name in wb.sheetnames:
        name_lower = sheet_name.lower().strip()
        
        if wb[sheet_name].sheet_state != 'visible':
            continue
            
        if any(x in name_lower for x in ['bs', 'balance sheet', 'pl', 'p&l', 'profit']):
            continue
        if name_lower in ['dashboard', 'ratios', 'cover page']:
            continue
            
        if re.search(r'\d', sheet_name) or 'note' in name_lower or 'sch' in name_lower:
            notes_sheet_names.append(sheet_name)
            
    notes_dict = {}
    sheet_notes_dict = {}
    signatures_dict = {}
    footers_dict = {}

    for sheet_name in notes_sheet_names:
        if sheet_name not in wb.sheetnames:
            logger.debug("Notes sheet '%s' not found in workbook", sheet_name)
            continue

        hidden_rows, hidden_cols, invisible_cells = get_sheet_visibility(filepath, sheet_name)
        ws = SheetWrapper(wb[sheet_name], hidden_rows=hidden_rows, hidden_cols=hidden_cols,
                          invisible_cells=invisible_cells)
        notes_groups, sheet_notes, signatures, footers = _parse_notes_sheet(ws, cy_year, py_year, target_notes)

        # Fixed-asset / matrix schedules (PPE, Intangibles, ROU) cannot be read by
        # the row-based note parser — it picks a single asset-class column and
        # produces empty "Note 3(a)" fragments. Rebuild such sheets from the
        # note's own Total column so the output shows real Gross Block /
        # Accumulated Depreciation / Net Block figures.
        try:
            from src.core.visible_data_engine import read_visible_grid
            from src.core.fixed_asset_parser import build_fa_note_groups
            fa_groups = build_fa_note_groups(read_visible_grid(filepath, sheet_name))
            if fa_groups:
                # Mixed sheets (e.g. '4-15') hold real row-based notes (4..15)
                # ALONGSIDE an asset matrix (ROU). Keep the regular groups that
                # actually carry data and append the rebuilt FA groups; only the
                # empty single-column fragments that a PURE matrix sheet (e.g.
                # '3') produces get dropped. Previously fa_groups REPLACED
                # everything, silently discarding real notes 4..15.
                from src.core.template_mapper import normalize_name as _norm_h
                def _has_vals(g):
                    return any(d.get('cy') not in (None, '-') or d.get('py') not in (None, '-')
                               for d in g.get('data', []))
                _fa_heads = {_norm_h(g.get('note_heading', '')) for g in fa_groups}
                _real_regular = [g for g in notes_groups
                                 if _has_vals(g)
                                 and _norm_h(g.get('note_heading', '')) not in _fa_heads]
                notes_groups = _real_regular + fa_groups
        except Exception as e:  # noqa: BLE001
            logger.warning("Fixed-asset rebuild skipped for sheet '%s': %s", sheet_name, e)

        if notes_groups:
            notes_dict[sheet_name] = notes_groups
        if sheet_notes:
            sheet_notes_dict[sheet_name] = sheet_notes
        if signatures:
            signatures_dict[sheet_name] = signatures
        if footers:
            footers_dict[sheet_name] = footers

    if not notes_dict:
        logger.warning("No notes were parsed. This usually happens if you load a blank template instead of actual client data.")
    else:
        logger.info("Parsed notes from %d sheets, footers from %d sheets", len(notes_dict), len(footers_dict))
    return {
        'notes': notes_dict,
        'sheet_notes': sheet_notes_dict,
        'signatures': signatures_dict,
        'footers': footers_dict
    }

def _is_note_heading(ws, row_idx):
    if row_idx in getattr(ws, 'hidden_rows', set()):
        return None, None, None

    hidden_cols = getattr(ws, 'hidden_cols', set())

    def is_valid_note_num(val_str):
        m = re.match(r'^(\d+)(?:[A-Za-z]|\([a-zA-Z]\))?\+?$', val_str)
        if m:
            try:
                num_val = int(m.group(1))
                if num_val == 0 or num_val > 100:
                    return False
            except ValueError:
                return False
            return True
        return False

    for col_idx in range(1, min(10, ws.max_column + 1)):
        if col_idx in hidden_cols:
            continue
        cell = ws.cell(row=row_idx, column=col_idx)
        if cell.value is not None:
            val_str = str(cell.value).strip()
            m = re.match(r'^Note\s*(\d+(?:\.\d+)?(?:[A-Za-z]|\([a-zA-Z]\))?\+?)\s*[:\-]?\s*(.*)$', val_str, re.IGNORECASE)
            if m:
                note_num = m.group(1)
                # Clean common trailing characters like '+' or '.' from note numbers
                note_num = note_num.strip().rstrip('.+').strip()
                note_heading = m.group(2).strip()
                heading_col_idx = col_idx
                if not note_heading and col_idx + 1 <= ws.max_column:
                    note_heading = _get_text(ws.cell(row=row_idx, column=col_idx + 1))
                    heading_col_idx = col_idx + 1
                heading_clean = note_heading.lower().strip()
                _is_numeric_heading = bool(re.match(r'^[\d\.\,\(\)\-\s]+$', heading_clean))
                _is_decimal_note_num = bool(re.search(r'\d+\.\d+', note_num))
                _is_zero_note = (note_num.strip() == '0')
                if (heading_clean
                        and not _is_numeric_heading
                        and not _is_decimal_note_num
                        and not _is_zero_note
                        and heading_clean not in ['particulars', 'total', 'amount', 'rs', 'in lakhs', 'in lacs', 'in millions', 'in thousands', 'rs.', 'rupees']):
                    return note_num, note_heading, heading_col_idx

    for col_idx in range(1, min(10, ws.max_column)):
        if col_idx in hidden_cols or col_idx + 1 in hidden_cols:
            continue
        num_cell = ws.cell(row=row_idx, column=col_idx)
        heading_cell = ws.cell(row=row_idx, column=col_idx + 1)
        if num_cell.value is not None:
            num_val = str(num_cell.value).strip()
            if is_valid_note_num(num_val):
                # Clean common trailing characters like '+' or '.' from note numbers
                num_val_clean = num_val.rstrip('.+').strip()
                heading = _get_text(heading_cell)
                heading_clean = heading.lower().strip()
                # A real note heading is never a pure number — reject e.g.
                # note '11' paired with heading '-23226532' (junk that otherwise
                # printed as "Note 11: -23226532"). The first loop already guards
                # this; the second loop didn't.
                _is_numeric_heading = bool(re.match(r'^[\d\.\,\(\)\-\s]+$', heading_clean))
                if (heading and not _is_numeric_heading
                        and heading_clean not in ['particulars', 'total', 'amount', 'rs', 'in lakhs', 'in lacs', 'in millions', 'in thousands', 'rs.', 'rupees']):
                    if col_idx == 1 or _is_bold(num_cell) or _is_bold(heading_cell):
                        return num_val_clean, heading, col_idx + 1

    # A fixed-asset / deferred-tax MATRIX column-header row (e.g.
    # "Building | Plant and equipment | … | Total" or the deferred-tax
    # "… | Right-of-use assets | Total") is NOT a note heading. Such a row carries
    # a standalone "Total" header cell — skip the bold-asset fallback for it, else
    # a column-class name ("Plant and equipment", "Right-of-use assets") is
    # mis-read as a separate note (3(a)/3A). The dedicated FA-matrix rebuild
    # (fixed_asset_parser) already extracts these matrix sheets correctly.
    _row_has_total = any(
        ws.cell(row=row_idx, column=c).value is not None
        and str(ws.cell(row=row_idx, column=c).value).strip().lower() == 'total'
        for c in range(1, min(12, ws.max_column + 1)) if c not in hidden_cols)
    if not _row_has_total:
        for col_idx in range(2, min(10, ws.max_column + 1)):
            if col_idx in hidden_cols:
                continue
            cell = ws.cell(row=row_idx, column=col_idx)
            if cell.value is not None and _is_bold(cell):
                val_str = str(cell.value).strip()
                lower_val = val_str.lower()
                # Match on WORD BOUNDARIES — a plain substring test made 'rou'
                # (Right-Of-Use) match the "rou" inside "disposal g(rou)p", so the
                # "Assets/Liabilities included in disposal group held for sale"
                # sub-tables of note 32A were wrongly tagged note '3A' (colliding
                # with the real PPE note 3A) and printed with PPE's BS total.
                if re.search(r'\b(?:property|plant|equipment|intangible|right[\s-]?of[\s-]?use|rou|ppe)\b', lower_val):
                    if 'intangible' in lower_val:
                        note_num = '3(b)'
                    elif re.search(r'\b(?:right[\s-]?of[\s-]?use|rou)\b', lower_val):
                        note_num = '3A'
                    else:
                        note_num = '3(a)'
                    return note_num, val_str, col_idx

    return None, None, None

def _detect_year_subcolumns(ws, start_row, end_row, cy_col, py_col, hidden_rows, hidden_cols):
    """Some notes split each year into 'Current' / 'Non-current' sub-columns
    (e.g. Other financial assets). The year header sits on ONE column but the
    figures live in the column(s) up to the next year. Detect that split and
    return the list of value columns that belong to CY and to PY so the caller
    can sum them. Falls back to ``([cy_col], [py_col])`` for ordinary notes."""
    if cy_col is None or py_col is None or py_col <= cy_col:
        return [cy_col], [py_col]
    width = py_col - cy_col
    has_split = False
    for r in range(start_row, min(start_row + 6, end_row + 1)):
        if r in hidden_rows:
            continue
        joined = ' '.join(
            str(ws.cell(row=r, column=c).value or '').lower()
            for c in range(cy_col, min(py_col + width, ws.max_column + 1)))
        if 'non-current' in joined or 'non current' in joined or joined.count('current') >= 2:
            has_split = True
            break
    if not has_split:
        return [cy_col], [py_col]
    cy_cols = [c for c in range(cy_col, py_col) if c not in hidden_cols]
    py_cols = [c for c in range(py_col, min(py_col + width, ws.max_column + 1))
               if c not in hidden_cols]
    return (cy_cols or [cy_col]), (py_cols or [py_col])

def _sum_value_cols(ws, row, cols):
    """Sum the numeric values across ``cols`` (used for Current+Non-current).
    Returns the sum when any cell is numeric, else the first cell's raw value
    (so a '-' / blank is preserved)."""
    total = None
    for c in cols:
        v = _get_value(ws.cell(row=row, column=c))
        if isinstance(v, (int, float)):
            total = (total or 0.0) + v
    if total is not None:
        return total
    return _get_value(ws.cell(row=row, column=cols[0])) if cols else None

# Feature 2: these note types are inherently ambiguous to auto-extract (matrix
# layouts, multiple value columns / authorised-vs-issued rows). The tool only
# SUGGESTS a value for them and routes them to the Review panel for the user to
# confirm — it never silently finalises them.
_SUGGEST_ONLY_RE = re.compile(
    r'\b(?:deferred\s+tax|intangible|income\s+tax|'
    r'(?:equity\s+)?share\s+capital|right[\s-]?of[\s-]?use|rou)\b', re.I)


def _is_suggest_only_note(heading):
    return bool(heading and _SUGGEST_ONLY_RE.search(str(heading)))


def _columns_from_target(ws, start_row, end_row, target_cy, target_py,
                         hidden_rows, hidden_cols):
    """Feature 1: pick the note's value columns by finding where the BS/P&L total
    actually appears. Scan the note region for a cell equal to ``target_cy``; its
    column is the CY column. Strongly prefer a row that ALSO holds ``target_py``
    (a two-figure match is almost never coincidental), which pins both columns.
    Returns ``(cy_col, py_col, matched)`` — ``matched`` False means no column's
    value matches the referenced total, so the note should go to manual review."""
    if not target_cy:
        return None, None, False
    tol_cy = max(1.0, abs(target_cy) * 0.01)
    tol_py = max(1.0, abs(target_py) * 0.01) if target_py else None
    cy_only = None
    for r in range(start_row, end_row + 1):
        if r in hidden_rows:
            continue
        cy_hit = None
        for c in range(2, ws.max_column + 1):
            if c in hidden_cols:
                continue
            v = _get_value(ws.cell(row=r, column=c))
            if isinstance(v, (int, float)) and abs(v - target_cy) <= tol_cy:
                cy_hit = c
                break
        if cy_hit is None:
            continue
        if tol_py is not None:
            for c in range(cy_hit + 1, ws.max_column + 1):
                if c in hidden_cols:
                    continue
                v = _get_value(ws.cell(row=r, column=c))
                if isinstance(v, (int, float)) and abs(v - target_py) <= tol_py:
                    return cy_hit, c, True          # both years matched — strongest
        if cy_only is None:
            cy_only = cy_hit
    if cy_only is not None:
        return cy_only, cy_only + 1, True
    return None, None, False


# Rows whose label contains any of these are signatures/boilerplate, not data.
_NOTE_GARBAGE_PATTERNS = (
    "see accompanying notes", "accompanying notes",
    "significant accounting policies", "material accounting policies",
    "for and on behalf", "as per our report",
    "director", "partner", "membership no", "membership number",
    "place:", "date:", "udin",
)

# A NOTE-classified row carrying one of these labels closes the note table.
_NOTE_FINAL_TOTAL_KEYWORDS = (
    "grand total", "net total", "closing balance", "total carrying amount",
    "total value", "total net block", "total gross block", "net block",
)

def _parse_notes_sheet(ws, cy_year=2025, py_year=2024, target_notes=None):
    notes_groups = []
    sheet_notes = []
    signatures = []
    footers = []

    hidden_rows = getattr(ws, 'hidden_rows', set())
    hidden_cols = getattr(ws, 'hidden_cols', set())

    # Detect every note-heading row in ONE pass up front. _is_note_heading is
    # expensive (multi-column regex scan); the loop below previously re-ran it for
    # every note to find that note's end row (twice) AND for every data row, which
    # was O(notes x rows). With the headings known, those become dict lookups.
    heading_map = {}
    for _r in range(1, ws.max_row + 1):
        if _r in hidden_rows:
            continue
        _hn, _hh, _hc = _is_note_heading(ws, _r)
        if _hn is not None:
            heading_map[_r] = (_hn, _hh, _hc)
    _heading_rows = sorted(heading_map)

    def _next_heading_after(r):
        for hr in _heading_rows:
            if hr > r:
                return hr
        return None

    row = 1
    while row <= ws.max_row:
        if row in hidden_rows:
            row += 1
            continue

        note_num, note_heading, heading_col = heading_map.get(row, (None, None, None))

        # NOTE: we used to skip any note whose number wasn't in target_notes
        # (the BS/PL-referenced set), which dropped genuine narrative/disclosure
        # notes (Related party, EPS, etc.) during parsing. We now extract ALL
        # notes and let data_engine._keep_note decide what reaches the output, so
        # those disclosure notes survive. target_notes is still used below (value
        # match) to stop reading a BS-linked note once its total is reached.

        if note_num is None:
            part_text = ""
            is_bold = False
            for col in range(1, ws.max_column + 1):
                txt = _get_text(ws.cell(row=row, column=col))
                if txt and not re.match(r'^[\d\.,\(\)\-\s]+$', txt):
                    part_text = txt
                    is_bold = _is_bold(ws.cell(row=row, column=col))
                    break
            cy_val = None
            py_val = None
            row_class = _classify_row(ws, row, part_text, cy_val, py_val, is_bold)
            row_cells = _extract_row_cells(ws, row)
            if any(c != '' and c != '-' for c in row_cells):
                if row_class == 'SIGNATURE':
                    signatures.append(row_cells)
                elif row_class == 'NOTE':
                    sheet_notes.append(row_cells)
                elif row_class == 'FOOTER':
                    footers.append(row_cells)
            row += 1
            continue

        _nh = _next_heading_after(row)
        note_end_row_pre = (_nh - 1) if _nh is not None else ws.max_row

        cy_col, py_col, cy_yr, py_yr, date_row = _find_date_columns(
            ws, search_rows=range(row, note_end_row_pre + 1),
            default_cy_year=cy_year, default_py_year=py_year)

        heading_clean = note_heading.lower().replace('-', ' ')
        # Word-boundary match — a plain substring test made 'rou' match the "rou"
        # in "reg(rou)ped" ("Previous year's figures have been regrouped"), so a
        # narrative note was wrongly flagged is_asset_note (and then survived the
        # BS-reference filter as if it were a fixed-asset note).
        is_asset_note = bool(re.search(
            r'\b(?:property|plant|equipment|intangible|right[\s-]?of[\s-]?use|rou|ppe|deferred tax)\b',
            heading_clean))

        est_part_col = heading_col if heading_col is not None else 2
        for r in range(row, min(row + 5, note_end_row_pre + 1)):
            if r in hidden_rows: continue
            for c in range(1, min(5, ws.max_column + 1)):
                if c in hidden_cols: continue
                val = str(ws.cell(row=r, column=c).value or '').lower().strip()
                if 'particular' in val or 'description' in val or 'detail' in val:
                    est_part_col = c
                    break

        if cy_col is None:
            cy_col = est_part_col + 1
            py_col = cy_col + 1
            cy_yr = cy_year
            py_yr = py_year
            date_row = row + 1
            logger.info("Note %s: Default column heuristic → cy_col=%d py_col=%d",
                        note_num, cy_col, py_col)
        else:
            cy_year = cy_yr
            py_year = py_yr

        # Handle notes that split each year into Current / Non-current columns.
        cy_cols, py_cols = _detect_year_subcolumns(
            ws, row, note_end_row_pre, cy_col, py_col, hidden_rows, hidden_cols)

        part_col = heading_col if heading_col is not None else 2
        
        note_end_row = note_end_row_pre

        best_part_col = None
        data_start = date_row + 1 if date_row else row + 3
        for r in range(row, min(data_start + 3, note_end_row + 1)):
            if r in hidden_rows:
                continue
            for c in range(1, ws.max_column + 1):
                if c in hidden_cols or c == cy_col or c == py_col:
                    continue
                val = str(ws.cell(row=r, column=c).value or '').lower().strip()
                if 'particular' in val or 'description' in val or 'detail' in val:
                    best_part_col = c
                    break
            if best_part_col is not None:
                break
                
        if best_part_col is None:
            col_lengths = {}
            for r in range(data_start, min(data_start + 15, note_end_row + 1)):
                if r in hidden_rows:
                    continue
                for c in range(1, min(10, ws.max_column + 1)):
                    if c in hidden_cols or c == cy_col or c == py_col:
                        continue
                    val = str(ws.cell(row=r, column=c).value or '').strip()
                    if val and not re.match(r'^[\d\.,\(\)\-\s%]+$', val):
                        if val.lower() not in ['note', 'no.', 'sch', 'sch.', 'notes', 'particulars', 'description', 'amount', 'rs', 'rupees']:
                            col_lengths[c] = col_lengths.get(c, 0) + len(val)
            if col_lengths:
                best_col = max(col_lengths.items(), key=lambda x: x[1])
                if best_col[1] > 0:
                    best_part_col = best_col[0]
                    
        if best_part_col is not None:
            part_col = best_part_col

        # Feature 1: when the BS/P&L references this note with a known total, pick
        # the value columns by matching that total inside the note (instead of the
        # date-header heuristic, which grabs the wrong column on matrix/odd notes).
        # If nothing matches, leave the heuristic columns but flag for review.
        needs_review = False
        norm_note = re.sub(r'[^A-Z0-9]', '', str(note_num).upper())
        tgt = target_notes.get(norm_note) if isinstance(target_notes, dict) else None
        # Skip asset/matrix notes: those are rebuilt from their Total column by the
        # fixed-asset parser. Overriding their columns here can make a mis-parsed
        # matrix fragment (e.g. a 'Office and other equipment' sub-block) gain
        # values and wrongly survive the rebuild merge as a junk note.
        if isinstance(tgt, dict) and tgt.get('cy') and not is_asset_note:
            m_cy, m_py, ok = _columns_from_target(
                ws, row, note_end_row, tgt.get('cy'), tgt.get('py'),
                hidden_rows, hidden_cols)
            if ok:
                cy_col, py_col = m_cy, m_py
                cy_cols, py_cols = [m_cy], [m_py]
            else:
                needs_review = True

        # Feature 2: the hard note types are always suggest-only, even if a value
        # was matched — the user confirms them in the Review panel.
        if _is_suggest_only_note(note_heading):
            needs_review = True

        data_start = row + 1

        data_rows = []

        is_note_table_closed = False

        data_row = data_start
        while data_row <= ws.max_row:
            if data_row in hidden_rows:
                data_row += 1
                continue

            if data_row in heading_map:
                break

            part_text = _get_text(ws.cell(row=data_row, column=part_col))
            cy_val = _sum_value_cols(ws, data_row, cy_cols)
            py_val = _sum_value_cols(ws, data_row, py_cols)
            is_bold_row = _is_bold(ws.cell(row=data_row, column=part_col))

            # Indented sub-items put their label in a column to the RIGHT of the
            # particulars column (e.g. note 21 'Other expenses' has main items in
            # C but 'Related parties' / 'Others' in D). Without this the row looks
            # label-less, gets classed as a footer and prematurely closes the
            # note. Recover the label from the nearest text column when the row
            # actually carries a value.
            if not part_text and (isinstance(cy_val, (int, float))
                                  or isinstance(py_val, (int, float))):
                for _c in range(part_col + 1, ws.max_column + 1):
                    if _c in cy_cols or _c in py_cols or _c in hidden_cols:
                        continue
                    _t = _get_text(ws.cell(row=data_row, column=_c))
                    if _t and not re.match(r'^[\d\.,\(\)\-\s%]+$', _t):
                        part_text = _t
                        break

            if part_text:
                lower_txt = part_text.lower()
                if any(x in lower_txt for x in _NOTE_GARBAGE_PATTERNS):
                    data_row += 1
                    continue

            if part_text in ('', '-') and cy_val in (None, '-') and py_val in (None, '-'):
                data_row += 1
                continue

            # Header skipping logic is covered by _classify_row returning 'HEADER'

            row_class = _classify_row(ws, data_row, part_text, cy_val, py_val, is_bold_row)

            # Close note if footer/signature reached after collecting data
            if row_class in ["FOOTER", "SIGNATURE"] and len(data_rows) > 0:
                is_note_table_closed = True

            # Skip headers
            if row_class == 'HEADER':
                data_row += 1
                continue
            
            if is_note_table_closed:
                row_cells = _extract_row_cells(ws, data_row)
                if any(c not in ('', '-', None) for c in row_cells):
                    if row_class == 'SIGNATURE':
                        signatures.append(row_cells)
                    elif row_class == 'NOTE' or _is_narrative_text(part_text) or len(str(part_text)) > 40:
                        sheet_notes.append(row_cells)
                    else:
                        footers.append(row_cells)
                data_row += 1
                continue

            if row_class == 'SIGNATURE':
                is_note_table_closed = True
                signatures.append(_extract_row_cells(ws, data_row))
                data_row += 1
                continue

            if row_class == 'NOTE':
                part_lower = str(part_text).lower().strip()

                if any(k in part_lower for k in _NOTE_FINAL_TOTAL_KEYWORDS):
                    data_rows.append({
                        'particulars': part_text,
                        'cy': cy_val,
                        'py': py_val,
                        'is_bold': is_bold_row,
                        'row_num': data_row
                    })
                    is_note_table_closed = True
                    
                    if target_notes is not None:
                        norm_num = re.sub(r'[^A-Z0-9]', '', str(note_num).upper())
                        _t = target_notes.get(norm_num, 0)
                        target_cy = _t.get('cy', 0) if isinstance(_t, dict) else _t
                        if cy_val is not None and abs(cy_val - target_cy) <= 1.0:
                            data_row += 1
                            break # stop reading further
                            
                    data_row += 1
                    continue
                else:
                    part_text = _append_adjustments(ws, data_row, part_text, part_col, cy_col, py_col)
                    data_rows.append({
                        'particulars': part_text,
                        'cy': cy_val if cy_val is not None else None,
                        'py': py_val if py_val is not None else None,
                        'is_bold': is_bold_row,
                        'row_num': data_row
                    })
                    data_row += 1
                    continue

            if row_class == 'FOOTER':
                footers.append(_extract_row_cells(ws, data_row))
                data_row += 1
                continue

            part_text = _append_adjustments(ws, data_row, part_text, part_col, cy_col, py_col)
            data_rows.append({
                'particulars': part_text,
                'cy': cy_val if cy_val is not None else None,
                'py': py_val if py_val is not None else None,
                'is_bold': is_bold_row,
                'row_num': data_row
            })

            data_row += 1

        notes_groups.append({
            'note_num': note_num,
            'note_heading': note_heading,
            'data': data_rows,
            'is_asset_note': is_asset_note,
            'cy_year': cy_yr,
            'py_year': py_yr,
            'needs_review': needs_review
        })

        row = data_row - 1
        row += 1

    return notes_groups, sheet_notes, signatures, footers

def _is_narrative_text(particulars):
    if not particulars:
        return False
    text = particulars.strip()
    text_lower = text.lower()
    
    if text.endswith('.') and not text_lower.endswith(('no.', 'co.', 'llp.', 'ltd.', 'a.m.', 'p.m.', 'i.e.', 'e.g.')):
        return True
        
    narrative_phrases = [
        'represents', 'refers to', 'referred to', 'refer to', 'see note', 'refer note', 
        'during the year', 'previous year', 'current year', 'company has', 'company has not', 
        'amount less than', 'pursuant to', 'disclosed', 'explained', 'clarification', 
        'regrouped', 'reclassified', 'management representation', 'bonus shares', 
        'of even date', 'as per our report', 'carried at', 'measured at', 'accounting policy', 
        'useful lives', 'estimated by', 'depreciation is', 'method of', 'financial statements', 
        'subject to', 'written down', 'residual value', 'useful life', 'in respect of', 
        'valuation of', 'valued by', 'estimated useful', 'carrying amount', 'realisable value', 
        'net book value', 'book value of', 'useful lives of', 'under the', 'agree with', 
        'reconciled to', 'outstanding for a period', 'outstanding for following', 
        'due from directors', 'due from officers', 'due from firms', 'due from private', 
        'held by holding', 'holder of', 'ultimate holding', 'subsidiaries/ associates', 'subsidiary/ associate', 
        'promoter\'s holding', 'promoters\' holding', 'reconciliation of', 'shares outstanding', 
        'beginning of the year', 'end of the year', 'nature and purpose', 're-measurements', 
        'defined benefit', 'continuing operations', 'discontinued operations', 'zero represents', 
        'represents amount', 'less than', 'exceeded its cost', 'overdue',
        'face value of', 'face value', 'accompanying notes', 'integral part',
        'material accounting polic', 'significant accounting polic',
        'explanatory notes', 'explanatory information',
        'will not be reclassified', 'not be reclassified subsequently',
        'items that will not be', 'items that may be reclassified',
        'net of mat credit',
        'as per our report of even date', 'report of even date',
        'as per our attached report', 'as per our separate report',
        'forming part of', 'form part of', 'form an integral part',
        'in terms of our report', 'in terms of information',
        'the above statement', 'the above results', 'above financial',
        'per equity share',
    ]
    for phrase in narrative_phrases:
        if phrase in text_lower:
            return True
            
    words = re.findall(r'\b[a-zA-Z]{2,}\b', text_lower)
    if not words:
        return False
        
    narrative_verbs = {
        'is', 'are', 'was', 'were', 'have', 'has', 'had', 'been', 'be',
        'does', 'do', 'did', 'should', 'would', 'could', 'will', 'shall', 'may',
        'recommends', 'recommended', 'proposes', 'proposed', 'values', 'valued',
        'defines', 'defined', 'measure', 'measured', 'estimates', 'estimated',
        'expects', 'expected', 'settle', 'settled', 'reclassify', 'reclassified',
        'regroup', 'regrouped', 'opted', 'outstanding', 'disclosed', 'incurred',
        'earned'
    }
    
    narrative_others = {
        'the', 'our', 'their', 'we', 'they', 'it', 'them', 'us', 'who', 'which',
        'whose', 'since', 'because', 'although', 'though', 'about', 'against', 
        'between', 'into', 'through', 'during', 'before', 'after', 'above', 
        'below', 'under', 'over', 'again', 'further', 'then', 'once', 'here', 
        'there', 'when', 'where', 'why', 'how', 'each', 'any', 'both', 'some', 
        'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 
        'very', 'just', 'now'
    }
    
    verb_count = sum(1 for w in words if w in narrative_verbs)
    other_count = sum(1 for w in words if w in narrative_others)
    
    if verb_count >= 1 and other_count >= 2:
        standard_accs = ['property, plant and equipment', 'assets classified as held for sale',
                         'cost of materials consumed', 'changes in inventories',
                         'employee benefits expense', 'depreciation and amortisation',
                         'depreciation and amortization', 'finance costs', 'other expenses',
                         'income tax expense', 'deferred tax', 'current tax', 'earnings per share']
        for acc in standard_accs:
            if acc in text_lower:
                return False
        return True
        
    return False

# Signature-detection patterns, compiled once at import (this runs per data row
# of every sheet, so recompiling them inside _classify_row dominated the loop).
_SIG_EXACT_ROLES = frozenset({
    'partner', 'partners',
    'director', 'directors',
    'managing director',
    'cfo', 'chief financial officer',
    'company secretary',
    'auditor', 'auditors',
    'authorised signatory', 'authorized signatory'
})

_SIG_HIGH_CONF_RE = [re.compile(p) for p in (
    r'\bchartered\s+accountants\b',
    r'\bmembership\s+no\b',
    r'\bmembership\s+number\b',
    r'\bregistration\s+no\b',
    r'\bregistration\s+number\b',
    r'\bfirm\s+registration\s+no\b',
    r'^\s*place\s*:',
    r'^\s*date\s*:',
    r'\budin\b',
    r'\bauthorised\s+signatory\b',
    r'\bauthorized\s+signatory\b',
    r'\bfor\s+and\s+on\s+behalf\s+of\b',
    r'\bas\s+per\s+our\s+report\b',
    r'\bof\s+even\s+date\b',
    r'\bllp\b',
)]

_SIG_EXCLUDE_WORDS = '(?:the|year|period|note|each|services|raw|other|depreciation|amortisation|amortization|interest|tax|purchase|sale|employee|allowance|provision|doubtful|bad|financial|operating|current|non-current)'
_SIG_FOR_PATTERN = re.compile(rf'^for\s+(?!{_SIG_EXCLUDE_WORDS}\b)[A-Za-z0-9\s&\.,\']+(?:llp|ltd|limited|associates|co|board|directors)?$', re.I)
_SIG_CLEAN_RE = re.compile(r'[^a-z0-9\s]')

def _classify_row(ws, row_idx, particulars, cy_val, py_val, is_bold):
    part_lower = particulars.lower().strip()
    if not part_lower:
        return 'FOOTER'

    for col in range(1, ws.max_column + 1):
        cell_val = ws.cell(row=row_idx, column=col).value
        if cell_val is None:
            continue
        val = str(cell_val).strip()
        if not val:
            continue
        val_lower = val.lower()

        for p in _SIG_HIGH_CONF_RE:
            if p.search(val_lower):
                return 'SIGNATURE'

        if _SIG_FOR_PATTERN.match(val) and len(val) < 80:
            return 'SIGNATURE'

        cleaned_val = _SIG_CLEAN_RE.sub('', val_lower).strip()
        if cleaned_val in _SIG_EXACT_ROLES:
            return 'SIGNATURE'

    if _is_narrative_text(particulars):
        return 'NOTE'

    if part_lower.startswith('(') and len(part_lower) > 10:
        if not re.match(r'^\([a-z0-9]{1,3}\)\s+', part_lower):
            return 'NOTE'

    if not cy_val and not py_val:
        pt_lower = particulars.strip().lower()
        if (pt_lower in ('as at', 'particulars', 'description', 'for the year ended',
                         '(₹ in lakhs)', '(₹ in lacs)', '(rs. in lakhs)', 'amount', 'amount in rs.', 'amount in rupees', 'amount in lakhs', 'amount in lacs', 'amount in millions')
            or re.match(r'^\d{1,2}\s+(?:march|april)\s+20\d{2}$', pt_lower)
            or re.match(r'^\d{1,2}[\-\/](?:mar|apr|march|april)[\-\/]\d{2,4}$', pt_lower)
            or re.match(r'^for the year ended', pt_lower)
            or re.match(r'^\(₹', pt_lower)
            or re.match(r'^20\d{2}$', pt_lower)):
            return 'HEADER'

    if cy_val is None and py_val is None and not is_bold:
        return 'NOTE'

    return 'FINANCIAL_DATA'

def _extract_row_cells(ws, row_idx):
    row_cells = []
    for col in range(1, ws.max_column + 1):
        cell_val = ws.cell(row=row_idx, column=col).value
        row_cells.append(_clean_footer_cell(cell_val))
    return row_cells

# Placeholders that don't count as a real label ('-' is what _clean_footer_cell
# emits for any masked number, so a row of only these carries no information).
_EXTRA_PLACEHOLDERS = ('', '-', '--', '—', '–', 'none')

def _meaningful_extra_rows(rows):
    """Clean the trailing 'extras' (notes / signatures / footers) shown beneath
    the BS / PL analysis tables.

    Two kinds of noise were leaking into the UI as garbage rows:
      * label-less rows — every cell is blank, a dash placeholder or a bare year
        (e.g. ``['-', '-']``), so the row says nothing; and
      * exact duplicates — the same label row repeated (e.g. 'Financial assets'
        twice from a fair-value disclosure block).

    Keep a row only if it has a human-readable label, and collapse duplicates.
    """
    seen = set()
    cleaned = []
    for row in rows:
        cells = [str(c).strip() for c in row]
        has_label = any(
            t and t.lower() not in _EXTRA_PLACEHOLDERS
            and not re.fullmatch(r'(19|20)\d{2}', t)
            for t in cells)
        if not has_label:
            continue
        key = tuple(cells)
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(row)
    return cleaned

def _clean_footer_cell(val):
    if val is None:
        return ''
    if isinstance(val, (int, float)):
        if isinstance(val, int) and 2000 <= val <= 2100:
            return str(val)
        return '-'
    val_str = str(val).strip()
    if not val_str:
        return ''
    cleaned_num = val_str.replace(',', '').replace(' ', '').replace('(', '').replace(')', '').replace('-', '').strip()
    if cleaned_num == '':
        return '-'
    try:
        float_val = float(cleaned_num)
        if float_val.is_integer() and 2000 <= int(float_val) <= 2100:
            return str(int(float_val))
        return '-'
    except ValueError:
        return val_str

def _col_letter(col_idx):
    result = ''
    while col_idx > 0:
        col_idx, remainder = divmod(col_idx - 1, 26)
        result = chr(65 + remainder) + result
    return result

def _find_first_nonzero(data, keywords, match_type='includes'):
    first_match_cy = None
    first_match_py = None

    for kw in keywords:
        kw_lower = kw.lower().strip()
        for row in data:
            p = row.get('particulars', '').lower().strip()
            matched = False
            if match_type == 'exact':
                matched = (p == kw_lower)
            else:
                matched = (kw_lower in p)

            if matched:
                cy = float(row.get('cy', 0) or 0)
                py = float(row.get('py', 0) or 0)

                if cy != 0 or py != 0:
                    logger.info("Found non-zero value for '%s' on row '%s': CY=%.2f, PY=%.2f",
                                kw, row.get('particulars', ''), cy, py)
                    return cy, py

                if first_match_cy is None:
                    first_match_cy = cy
                    first_match_py = py
                    logger.warning(
                        "Keyword '%s' matched row '%s' but value is ZERO — "
                        "may be a heading row; scanning further",
                        kw, row.get('particulars', ''))

    if first_match_cy is not None:
        logger.warning(
            "All matches for keywords %s returned zero — using zero as fallback", keywords)
        return first_match_cy, first_match_py

    logger.warning("No row found matching any of keywords: %s", keywords)
    return None, None

def _safe_float(v, default=0.0):
    if v is None:
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default

def extract_bs_summary(bs_data):
    summary = {}

    def find_value(keyword, match_type='includes'):
        kw = keyword.lower().strip()
        for row in bs_data:
            p = row.get('particulars', '').lower().strip()
            if match_type == 'exact':
                if p == kw:
                    return row.get('cy'), row.get('py')
            else:
                if kw in p:
                    return row.get('cy'), row.get('py')
        return None, None

    def find_borrowings(is_current):
        # Debt for Debt-Equity / ROCE = ONLY line items literally named
        # "Borrowing(s)". If the sheet has no such particular, borrowings are 0 and
        # both ratios show -NA- (they can't be computed without borrowings) — this
        # is what the user wants. Lease liabilities and employee-benefit obligations
        # are NOT borrowings and are excluded. Only LIABILITY-section rows count.
        keywords = ('borrowing',)
        cy_total = 0.0
        py_total = 0.0
        found = False
        in_current_section = False
        in_liabilities = False
        for row in bs_data:
            p = row.get('particulars', '').lower().strip()
            if 'current liabilities' in p and 'non' not in p:
                in_current_section = True
                in_liabilities = True
            elif 'non current liabilities' in p or 'non-current liabilities' in p:
                in_current_section = False
                in_liabilities = True

            if (in_liabilities and in_current_section == is_current
                    and any(k in p for k in keywords)):
                found = True
                cy_total += _safe_float(row.get('cy'))
                py_total += _safe_float(row.get('py'))

        return cy_total, py_total, found
    cy, py = find_value('total equity', 'exact')
    if cy is None:
        cy, py = find_value('total equity')
    summary['total_equity_cy'] = _safe_float(cy)
    summary['total_equity_py'] = _safe_float(py)

    cy, py = find_value('total current assets')
    summary['total_ca_cy'] = _safe_float(cy)
    summary['total_ca_py'] = _safe_float(py)

    cy, py = find_value('total current liabilities')
    summary['total_cl_cy'] = _safe_float(cy)
    summary['total_cl_py'] = _safe_float(py)

    cy, py = find_value('total non-current liabilities')
    if cy is None:
        cy, py = find_value('total non current liabilities')
    summary['total_ncl_cy'] = _safe_float(cy)
    summary['total_ncl_py'] = _safe_float(py)

    cy, py = find_value('total assets')
    summary['total_assets_cy'] = _safe_float(cy)
    summary['total_assets_py'] = _safe_float(py)

    ltb_cy, ltb_py, ltb_found = find_borrowings(False)
    stb_cy, stb_py, stb_found = find_borrowings(True)
    summary['ltb_cy'], summary['ltb_py'] = ltb_cy, ltb_py
    summary['stb_cy'], summary['stb_py'] = stb_cy, stb_py
    summary['has_borrowings'] = ltb_found or stb_found

    debtors_keywords = [
        'trade receivables',
        'sundry debtors',
        'trade and other receivables',
        'receivables',
        'debtors',
    ]
    cy, py = _find_first_nonzero(bs_data, debtors_keywords)
    summary['debtors_cy'] = _safe_float(cy)
    summary['debtors_py'] = _safe_float(py)

    cy, py = _find_first_nonzero(bs_data, [
        'cash and cash equivalents', 'cash and bank', 'cash & cash equivalents',
        'cash and cash equivalent', 'cash'])
    summary['cash_cy'] = _safe_float(cy)
    summary['cash_py'] = _safe_float(py)

    cy, py = _find_first_nonzero(bs_data, ['inventories', 'inventory', 'stock-in-trade'])
    summary['inventory_cy'] = _safe_float(cy)
    summary['inventory_py'] = _safe_float(py)

    if not summary.get('debtors_cy'):
        logger.warning(
            "DEBTORS: Could not find non-zero trade receivables in BS — "
            "Debtor Turnover Ratio will be 0. "
            "Check that the Notes sheet contains the actual receivables figures.")

    logger.info("BS Summary: total_ca=%.0f, total_cl=%.0f, debtors=%.0f, equity=%.0f",
                summary['total_ca_cy'], summary['total_cl_cy'],
                summary['debtors_cy'], summary['total_equity_cy'])

    return summary

def extract_pl_summary(pl_data):
    summary = {}

    revenue_keywords = [
        'revenue from operations',
        'net revenue from operations',
        'income from operations',
        'software services',
        'sale of products',
        'sale of services',
        'sales',
        'turnover',
        'revenue',
    ]
    cy, py = _find_first_nonzero(pl_data, revenue_keywords)
    summary['revenue_ops_cy'] = _safe_float(cy)
    summary['revenue_ops_py'] = _safe_float(py)

    if cy is None or cy == 0:
        logger.warning(
            "REVENUE: Could not find non-zero revenue from operations in P&L — "
            "Net Profit Ratio and Debtor Turnover Ratio will be 0. "
            "Check P&L sheet structure.")

    total_income_cy, total_income_py = 0.0, 0.0
    for kw in ['total income', 'total revenue']:
        cy_t, py_t = _find_first_nonzero(pl_data, [kw])
        if cy_t is not None and cy_t != 0:
            total_income_cy, total_income_py = _safe_float(cy_t), _safe_float(py_t)
            break
    summary['total_revenue_cy'] = total_income_cy
    summary['total_revenue_py'] = total_income_py

    pbt_cy, pbt_py = 0.0, 0.0
    pbt_keywords = [
        'profit before tax',
        'profit/(loss) before tax',
        'profit before income tax',
        'earnings before tax',
        'pbt',
    ]
    for row in pl_data:
        p = row.get('particulars', '').lower().strip()
        if 'profit' in p and 'before' in p and 'tax' in p:
            cy_v = _safe_float(row.get('cy'))
            py_v = _safe_float(row.get('py'))
            pbt_cy = cy_v
            pbt_py = py_v
            logger.info("PBT found: row='%s', CY=%.2f, PY=%.2f",
                        row.get('particulars', ''), cy_v, py_v)
            break
    else:
        raw_pbt_cy, raw_pbt_py = _find_first_nonzero(pl_data, pbt_keywords)
        pbt_cy = _safe_float(raw_pbt_cy)
        pbt_py = _safe_float(raw_pbt_py)
        logger.warning("PBT: exact match failed, using keyword fallback: CY=%.2f", pbt_cy)

    summary['pbt_cy'] = pbt_cy
    summary['pbt_py'] = pbt_py

    pat_cy, pat_py = 0.0, 0.0
    pat_row_candidates = [
        ('profit after tax', False),
        ('profit/(loss) after tax', False),
        ('net profit after tax', False),
        ('profit for the year', False),
        ('profit/(loss) for the year', False),
        ('net profit for the year', False),
        ('net profit', False),
        ('profit for the period', False),
        ('total comprehensive income', False),
    ]
    for kw, exact in pat_row_candidates:
        kw_lower = kw.lower()
        for row in pl_data:
            p = row.get('particulars', '').lower().strip()
            if (exact and p == kw_lower) or (not exact and kw_lower in p):
                cy_v = _safe_float(row.get('cy'))
                py_v = _safe_float(row.get('py'))
                if cy_v != 0 or py_v != 0:
                    pat_cy = cy_v
                    pat_py = py_v
                    logger.info("PAT found via keyword '%s': row='%s', CY=%.2f, PY=%.2f",
                                kw, row.get('particulars', ''), cy_v, py_v)
                    break
        if pat_cy != 0 or pat_py != 0:
            break

    if pat_cy == 0 and pat_py == 0:
        pat_cy = pbt_cy
        pat_py = pbt_py
        logger.warning(
            "PAT: Could not find Profit After Tax row — falling back to PBT (%.2f). "
            "Net Profit Ratio may be slightly overstated (ignores tax).", pat_cy)

    summary['pat_cy'] = pat_cy
    summary['pat_py'] = pat_py

    finance_keywords = ['finance charge', 'finance cost', 'interest expense',
                        'interest and finance cost', 'borrowing cost']
    cy, py = _find_first_nonzero(pl_data, finance_keywords)
    summary['finance_cost_cy'] = _safe_float(cy)
    summary['finance_cost_py'] = _safe_float(py)

    cy, py = _find_first_nonzero(pl_data, [
        'cost of materials consumed', 'cost of material consumed',
        'cost of goods sold', 'purchases of stock-in-trade'])
    summary['cost_materials_cy'] = _safe_float(cy)
    summary['cost_materials_py'] = _safe_float(py)

    cy, py = _find_first_nonzero(pl_data, [
        'depreciation and amortisation', 'depreciation and amortization',
        'depreciation expense', 'depreciation'])
    summary['depreciation_cy'] = _safe_float(cy)
    summary['depreciation_py'] = _safe_float(py)

    logger.info("PL Summary: revenue_ops=%.0f, pbt=%.0f, pat=%.0f, finance_cost=%.0f",
                summary['revenue_ops_cy'], summary['pbt_cy'],
                summary['pat_cy'], summary['finance_cost_cy'])

    return summary
