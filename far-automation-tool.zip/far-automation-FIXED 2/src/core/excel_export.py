
import os
import logging
import math
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side
)

logger = logging.getLogger(__name__)

FILL_HEADER = PatternFill(start_color='7030A0', end_color='7030A0', fill_type='solid')
FILL_YELLOW = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
FILL_LIGHT = PatternFill(start_color='F3F4F6', end_color='F3F4F6', fill_type='solid')

FONT_TITLE = Font(name='Arial', size=11, bold=True, color='000000')
FONT_SUBTITLE = Font(name='Arial', size=11, bold=True, color='000000')
FONT_HEADER = Font(name='Arial', size=11, bold=True, color='FFFFFF')
FONT_NORMAL = Font(name='Arial', size=11, color='000000')
FONT_BOLD = Font(name='Arial', size=11, bold=True, color='000000')
FONT_GREEN = Font(name='Arial', size=11, color='16A34A')
FONT_RED = Font(name='Arial', size=11, color='DC2626')
FONT_LEGEND = Font(name='Arial', size=11, color='000000')
FONT_LEGEND_KEY = Font(name='Arial', size=11, bold=False, color='FF0000')

THIN_BORDER = Border(
    left=Side(style='thin', color='D1D5DB'),
    right=Side(style='thin', color='D1D5DB'),
    top=Side(style='thin', color='D1D5DB'),
    bottom=Side(style='thin', color='D1D5DB')
)

ALIGN_CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
ALIGN_LEFT = Alignment(horizontal='left', vertical='center', wrap_text=True)
ALIGN_RIGHT = Alignment(horizontal='right', vertical='center')
NUMBER_FORMAT = '#,##0'
NUMBER_FORMAT_2DP = '#,##0.00'
PCT_FORMAT = '0.0%'

def _set_col_widths(ws, widths):
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

def _write_legends(ws, start_row, start_col, legends, cy_year, py_year):
    legend_items = [
        ('a', f'Traced to Financials for the year ended 31 March {py_year}'),
        ('b', f'Traced to Financials for the year ended 31 March {cy_year}'),
        ('e', 'Recomputed'),
    ]

    ws.cell(row=start_row, column=start_col, value='Legends').font = FONT_LEGEND_KEY
    for i, (key, desc) in enumerate(legend_items):
        r = start_row + 1 + i
        ws.cell(row=r, column=start_col, value=key).font = FONT_LEGEND_KEY
        ws.cell(row=r, column=start_col + 1, value=desc).font = FONT_LEGEND

def _write_notes_legends(ws, start_row, start_col, cy_year, py_year):
    legend_items = [
        ('a', f'Traced to Financials for the year ended 31 March {py_year}'),
        ('b', f'Traced to Financials for the year ended 31 March {cy_year}'),
        ('j', 'Linked'),
        ('e', 'Recomputed'),
        ('h', 'Immaterial. Hence ignored'),
    ]

    ws.cell(row=start_row, column=start_col, value='Legend:').font = FONT_LEGEND_KEY
    for i, (key, desc) in enumerate(legend_items):
        r = start_row + 1 + i
        ws.cell(row=r, column=start_col, value=key).font = FONT_LEGEND_KEY
        ws.cell(row=r, column=start_col + 1, value=desc).font = FONT_LEGEND

def _apply_data_row_style(ws, row_idx, max_col, row_data, variance_pct_col, variance_abs_col):
    is_bold = row_data.get('is_bold', False)
    variance_pct = row_data.get('variance_pct', 0)

    # Yellow (flag) and grey (subtotal) cell fills removed per request — the
    # output sheets stay clean/white on every generation. Bold subtotal font and
    # the green/red variance-% text are kept.
    for col in range(1, max_col + 1):
        cell = ws.cell(row=row_idx, column=col)
        cell.border = THIN_BORDER
        cell.font = FONT_BOLD if is_bold else FONT_NORMAL

    if variance_pct is not None and variance_pct_col:
        pct_cell = ws.cell(row=row_idx, column=variance_pct_col)
        if isinstance(variance_pct, (int, float)) and not math.isnan(variance_pct):
            if variance_pct > 0:
                pct_cell.font = Font(name='Arial', size=11, color='22C55E',
                                    bold=is_bold)
            elif variance_pct < 0:
                pct_cell.font = Font(name='Arial', size=11, color='EF4444',
                                     bold=is_bold)

def export_far_workbook(output_path, bs_result, pl_result, notes_result,
                        ratios, remarks_bs, remarks_pl,
                        client_name, firm_name, financial_year,
                        rounding_unit, cy_year, py_year,
                        chart_paths=None,
                        notes_sheet_notes=None, notes_signatures=None, notes_footers=None,
                        report_type='FAR', meta=None, note_mapping=None):
    wb = Workbook()

    wb.calculation.calcMode = 'auto'
    wb.calculation.fullCalcOnLoad = True

    ws_cover = wb.active
    ws_cover.title = 'COVER PAGE'
    _write_cover_sheet(ws_cover, client_name, firm_name, financial_year,
                       rounding_unit, cy_year, py_year, include_visuals=bool(chart_paths),
                       report_type=report_type, meta=meta)

    ws_bs = wb.create_sheet('BS Analysis')
    bs_row_map, bs_row_index = _write_analysis_sheet(
        ws_bs, bs_result, remarks_bs,
        client_name, firm_name, cy_year, py_year, rounding_unit,
        title='Analysis of Balance Sheet',
        date_prefix='As at',
        note_col_header='Note number'
    )

    ws_pl = wb.create_sheet('P&L Analysis')
    pl_row_map, pl_row_index = _write_analysis_sheet(
        ws_pl, pl_result, remarks_pl,
        client_name, firm_name, cy_year, py_year, rounding_unit,
        title='Analysis of Statement of Profit and Loss',
        date_prefix='For the Year ended',
        note_col_header='Note number'
    )

    if isinstance(notes_result, dict):
        from src.core.template_mapper import note_totals_from_mapping
        note_bs_totals = note_totals_from_mapping(note_mapping)
        sheet_notes_dict = notes_sheet_notes or {}
        signatures_dict = notes_signatures or {}
        footers_dict = notes_footers or {}
        for sheet_name, note_groups in notes_result.items():
            ws_notes = wb.create_sheet(f"Notes {sheet_name}"[:30])
            sh_notes = sheet_notes_dict.get(sheet_name)
            sh_sigs = signatures_dict.get(sheet_name)
            sh_footers = footers_dict.get(sheet_name)
            _write_notes_sheet(ws_notes, note_groups,
                             client_name, firm_name, cy_year, py_year, rounding_unit,
                             notes=sh_notes,
                             signatures=sh_sigs,
                             footers=sh_footers,
                             note_totals=note_bs_totals)
                             
    # BS-Notes Mapping sheet intentionally omitted from the output workbook.

    # MANUAL REVIEW sheet intentionally omitted from the output workbook.
    # (The Manual Review & Correction panel remains available in the app; its
    # reviewed line-items just no longer get written as a separate output sheet.)

    ws_ratio = wb.create_sheet('Ratio & Relations')
    _write_ratio_sheet(ws_ratio, ratios, client_name, firm_name, cy_year, py_year,
                       bs_row_map, pl_row_map, bs_result=bs_result, pl_result=pl_result,
                       bs_row_index=bs_row_index, pl_row_index=pl_row_index)

    # Dashboard sheet intentionally omitted from the output workbook.

    if chart_paths:
        ws_visuals = wb.create_sheet('Visual Analytics')
        _write_visuals_sheet(ws_visuals, chart_paths, client_name, firm_name, cy_year, rounding_unit)

    wb.save(output_path)
    logger.info("FAR workbook saved to %s", output_path)
    return True

def _write_cover_sheet(ws, client_name, firm_name, financial_year,
                       rounding_unit, cy_year, py_year, include_visuals=False,
                       report_type='FAR', meta=None):
    ws.views.sheetView[0].showGridLines = True

    ws.column_dimensions['A'].width = 4
    for col in ['B', 'C', 'D', 'E', 'F', 'G']:
        ws.column_dimensions[col].width = 16
    ws.column_dimensions['H'].width = 4

    def write_banner(row_idx, text):
        ws.merge_cells(start_row=row_idx, start_column=2, end_row=row_idx, end_column=7)
        cell = ws.cell(row=row_idx, column=2, value=text)
        cell.font = Font(name='Arial', size=11, bold=True, color='FFFFFF')
        cell.fill = FILL_HEADER
        cell.alignment = ALIGN_CENTER
        ws.row_dimensions[row_idx].height = 35

    def write_detail(row_idx, text, is_bullet=False):
        ws.merge_cells(start_row=row_idx, start_column=2, end_row=row_idx, end_column=7)
        cell = ws.cell(row=row_idx, column=2, value=text)
        cell.font = FONT_NORMAL
        cell.alignment = ALIGN_LEFT if is_bullet else ALIGN_CENTER
        ws.row_dimensions[row_idx].height = 24
        
        for col_idx in range(2, 8):
            ws.cell(row=row_idx, column=col_idx).border = THIN_BORDER

    write_banner(2, firm_name if firm_name else "Walker Chandiok & Co LLP")

    _REPORT_LABELS = {
        'FAR': 'Final Analytical Report',
        'PAR': 'Preliminary Analytical Report',
    }
    report_heading = _REPORT_LABELS.get(report_type, 'Final Analytical Report')
    write_banner(4, report_heading)

    write_detail(6, f"Client: {client_name}")

    analysis_date = datetime.now().strftime("%B %d, %Y")
    write_detail(8, f"Analysis Date: {analysis_date}")

    write_banner(11, "Year-over-Year Financial Comparison")

    if meta:
        py_days = meta.get('py_days', 365)
        py_months = meta.get('py_months', 12.0)
        py_cov = meta.get('py_coverage', 100.0)
        cy_days = meta.get('cy_days', 365)
        cy_months = meta.get('cy_months', 12.0)
        cy_cov = meta.get('cy_coverage', 100.0)
    else:
        py_days = cy_days = 365
        py_months = cy_months = 12.0
        py_cov = cy_cov = 100.0

    write_detail(13, f"Previous Year ({py_year}): Days: {py_days} | Months: {py_months} | Coverage: {py_cov}%", is_bullet=True)
    write_detail(14, f"Current Year ({cy_year}): Days: {cy_days} | Months: {cy_months} | Coverage: {cy_cov}%", is_bullet=True)

    write_banner(17, "Analysis Summary")

    bullets = [
        "  • Balance Sheet Analysis",
        "  • Profit and Loss Analysis",
        "  • Ratio and Relations Analysis",
        "  • Visual Analytics and Charts"
    ]
    for idx, bullet in enumerate(bullets):
        write_detail(19 + idx, bullet, is_bullet=True)

    ws.merge_cells(start_row=27, start_column=2, end_row=27, end_column=7)
    conf_cell = ws.cell(row=27, column=2, value="Confidential - For Internal Use Only")
    conf_cell.font = Font(name='Arial', size=11, italic=True, color='7F7F7F')
    conf_cell.alignment = ALIGN_CENTER
    ws.row_dimensions[27].height = 20

def _write_analysis_sheet(ws, data, remarks, client_name, firm_name, cy_year, py_year,
                          rounding_unit, title, date_prefix, note_col_header):
    _set_col_widths(ws, {
        'A': 40, 'B': 12, 'C': 16, 'D': 16, 'E': 16, 'F': 12, 'G': 45
    })

    # Firm name intentionally omitted from analysis sheets (shown only on the
    # Cover page). Client name is retained.
    ws.cell(row=2, column=1, value='Client Name:').font = FONT_BOLD
    ws.cell(row=2, column=3, value=client_name).font = FONT_NORMAL
    ws.cell(row=3, column=1, value=title).font = FONT_SUBTITLE
    ws.cell(row=4, column=1,
            value=f'{date_prefix} 31 March {cy_year} vs 31 March {py_year}').font = FONT_NORMAL
    ws.cell(row=5, column=1,
            value=f'(Rs. In {rounding_unit})').font = FONT_LEGEND

    _write_legends(ws, 1, 6, None, cy_year, py_year)

    ws.cell(row=6, column=1,
            value='Scope: All variances above TE and (+/-) 10% have been selected for analysis').font = FONT_LEGEND

    headers_legend = [('', ''), ('', ''), ('b', ''), ('a', ''), ('e', ''), ('e', ''), ('', '')]
    for i, (legend, _) in enumerate(headers_legend):
        if legend:
            ws.cell(row=7, column=i + 1, value=legend).font = FONT_LEGEND_KEY
            ws.cell(row=7, column=i + 1).alignment = ALIGN_CENTER

    col_headers = [
        'Particulars', note_col_header,
        f'{date_prefix}\n31 March {cy_year}',
        f'{date_prefix}\n31 March {py_year}',
        'Variance\n(Absolute)' if 'As at' in date_prefix else 'Absolute Variance',
        'Variance %' if 'As at' in date_prefix else 'Variance \n%',
        'Remarks'
    ]
    for i, h in enumerate(col_headers):
        cell = ws.cell(row=8, column=i + 1, value=h)
        cell.font = FONT_HEADER
        cell.fill = FILL_HEADER
        cell.alignment = ALIGN_CENTER
        cell.border = THIN_BORDER

    ws.freeze_panes = 'A9'

    row_map = {}
    row_index = []  # ordered [{row, p, note, cy, py}] — keeps duplicate particulars
                    # (e.g. two "Lease Liabilities" lines) that row_map would lose,
                    # so the Ratio sheet can map each figure to its exact cell.
    excel_row = 9  # running counter — a blank gap row after each Total advances it
    for idx, row_data in enumerate(data):
        p_lower = row_data.get('particulars', '').lower().strip()
        if p_lower:
            row_map[p_lower] = excel_row

        _note_raw = str(row_data.get('note', '')).strip()
        if _note_raw.endswith('.0'):
            _note_raw = _note_raw[:-2]

        def _num_or_none(v):
            try:
                if v is None or v == '-':
                    return None
                return float(v)
            except (TypeError, ValueError):
                return None

        row_index.append({
            'row': excel_row, 'p': p_lower, 'note': _note_raw,
            'cy': _num_or_none(row_data.get('cy')),
            'py': _num_or_none(row_data.get('py')),
        })

        ws.cell(row=excel_row, column=1, value=row_data.get('particulars', ''))
        ws.cell(row=excel_row, column=2, value=row_data.get('note', ''))

        cy_val = row_data.get('cy')
        py_val = row_data.get('py')
        decimals = 2  # all rounding units (incl. Crore/Thousands) keep 2 decimals

        def _write_val(val):
            if val is None:
                return ''
            if val == '-':
                return ''
            try:
                return round(float(val), decimals)
            except (ValueError, TypeError):
                return ''

        ws.cell(row=excel_row, column=3, value=_write_val(cy_val))
        ws.cell(row=excel_row, column=4, value=_write_val(py_val))

        abs_cell = ws.cell(row=excel_row, column=5)
        abs_cell.value = (
            f'=IF(AND(NOT(ISNUMBER(C{excel_row})), NOT(ISNUMBER(D{excel_row}))), "", '
            f'IF(ISNUMBER(C{excel_row}), C{excel_row}, 0) - IF(ISNUMBER(D{excel_row}), D{excel_row}, 0))'
        )

        pct_cell = ws.cell(row=excel_row, column=6)
        pct_cell.value = (
            f'=IF(AND(NOT(ISNUMBER(C{excel_row})), NOT(ISNUMBER(D{excel_row}))), "", '
            f'IF(OR(NOT(ISNUMBER(D{excel_row})), D{excel_row}=0), "-", '
            f'(IF(ISNUMBER(C{excel_row}), C{excel_row}, 0) - D{excel_row})/ABS(D{excel_row})))'
        )

        fmt = NUMBER_FORMAT_2DP  # 2 decimals for every rounding unit
        for col in [3, 4, 5]:
            ws.cell(row=excel_row, column=col).number_format = fmt
        pct_cell.number_format = PCT_FORMAT

        remark = remarks.get(idx, row_data.get('remark', ''))
        ws.cell(row=excel_row, column=7, value=remark)

        _apply_data_row_style(ws, excel_row, 7, row_data, 6, 5)

        # Accounting underline convention for Total / subtotal rows: a single rule
        # ABOVE the row and a double rule BELOW it.
        _is_total = 'total' in str(row_data.get('particulars', '')).lower()
        if _is_total:
            for col in range(1, 8):
                c = ws.cell(row=excel_row, column=col)
                ex = c.border
                c.border = Border(
                    left=ex.left, right=ex.right,
                    top=Side(style='thin', color='000000'),
                    bottom=Side(style='double', color='000000'))

        # Advance the row counter; leave a one-row blank gap after a Total row.
        excel_row += 2 if _is_total else 1

    return row_map, row_index

def _write_notes_sheet(ws, notes_groups, client_name, firm_name, cy_year, py_year, rounding_unit,
                       notes=None, signatures=None, footers=None,
                       note_totals=None):
    _set_col_widths(ws, {
        'A': 5, 'B': 40, 'C': 16, 'D': 16, 'E': 16, 'F': 12, 'G': 45,
        'H': 5, 'I': 50
    })

    # Firm name omitted (Cover page only). Client name retained.
    ws.cell(row=2, column=1, value='Client:').font = FONT_BOLD
    ws.cell(row=2, column=3, value=client_name).font = FONT_NORMAL
    ws.cell(row=3, column=1, value='Analysis of Notes to Accounts').font = FONT_SUBTITLE

    _write_notes_legends(ws, 1, 8, cy_year, py_year)

    current_row = 10

    for note_group in notes_groups:
        heading = f"Note {note_group['note_num']}: {note_group['note_heading']}"
        ws.merge_cells(start_row=current_row, start_column=2, end_row=current_row, end_column=7)
        cell_h = ws.cell(row=current_row, column=2, value=heading)
        cell_h.font = FONT_SUBTITLE
        cell_h.alignment = ALIGN_LEFT

        current_row += 1
        ws.cell(row=current_row, column=3, value='a').font = FONT_LEGEND_KEY
        ws.cell(row=current_row, column=4, value='b').font = FONT_LEGEND_KEY
        ws.cell(row=current_row, column=5, value='e').font = FONT_LEGEND_KEY
        ws.cell(row=current_row, column=6, value='e').font = FONT_LEGEND_KEY

        current_row += 1
        sub_headers = ['', 'Particulars', f'As at 31st March {cy_year}',
                       f'As at 31st March {py_year}', 'Variance', 'Variance %', 'Remarks']
        for i, h in enumerate(sub_headers):
            cell = ws.cell(row=current_row, column=i + 1, value=h)
            cell.font = FONT_HEADER
            cell.fill = FILL_HEADER
            cell.alignment = ALIGN_CENTER
            cell.border = THIN_BORDER

        current_row += 1

        decimals = 2  # all rounding units (incl. Crore/Thousands) keep 2 decimals
        fmt = NUMBER_FORMAT_2DP  # 2 decimals for every rounding unit

        def _nv(v):
            if v is None or v == '-':
                return ''
            try:
                return round(float(v), decimals)
            except (TypeError, ValueError):
                return ''

        def _write_note_row(particulars, cy_val, py_val, row_data):
            nonlocal current_row
            r = current_row
            ws.cell(row=r, column=2, value=particulars)
            ws.cell(row=r, column=3, value=_nv(cy_val))
            ws.cell(row=r, column=4, value=_nv(py_val))
            ws.cell(row=r, column=5, value=(
                f'=IF(AND(NOT(ISNUMBER(C{r})), NOT(ISNUMBER(D{r}))), "", '
                f'IF(ISNUMBER(C{r}), C{r}, 0) - IF(ISNUMBER(D{r}), D{r}, 0))'))
            ws.cell(row=r, column=6, value=(
                f'=IF(AND(NOT(ISNUMBER(C{r})), NOT(ISNUMBER(D{r}))), "", '
                f'IF(OR(NOT(ISNUMBER(D{r})), D{r}=0), "-", '
                f'(IF(ISNUMBER(C{r}), C{r}, 0) - D{r})/ABS(D{r})))'))
            for col in (3, 4, 5):
                ws.cell(row=r, column=col).number_format = fmt
            ws.cell(row=r, column=6).number_format = PCT_FORMAT
            _apply_data_row_style(ws, r, 7, row_data, 6, 5)
            # Single rule above / double rule below a Total (or Net Block /
            # Closing balance) row — same convention as the BS/P&L sheets.
            if any(k in str(particulars).lower()
                   for k in ('total', 'net block', 'net carrying', 'closing balance')):
                for col in range(1, 8):
                    c = ws.cell(row=r, column=col)
                    ex = c.border
                    c.border = Border(
                        left=ex.left, right=ex.right,
                        top=Side(style='thin', color='000000'),
                        bottom=Side(style='double', color='000000'))
            current_row += 1

        from src.core.template_mapper import normalize_name
        sc_bs = (note_totals or {}).get(
            normalize_name(note_group.get('note_num', ''))) if note_totals else None
        is_share_capital = 'sharecapital' in normalize_name(note_group.get('note_heading', ''))

        if is_share_capital and sc_bs and (sc_bs.get('cy') is not None or sc_bs.get('py') is not None):
            # BS-anchored clean presentation — mirrors the Manual Review panel fix
            # (_force_review_notes). The raw share-capital note rows are unreliable:
            # the "Issued, Subscribed and Paid-up" subtotal is lost to a parser
            # split, so only "Authorised" (e.g. 2,500) survives and the figures
            # don't tie to the BS amount (e.g. 901). Show the authoritative BS
            # figure instead of the messy/incomplete rows.
            _write_note_row('Issued, Subscribed and Paid-up (per Balance Sheet)',
                            sc_bs.get('cy'), sc_bs.get('py'), {})
            _write_note_row('Total (per Balance Sheet)',
                            sc_bs.get('cy'), sc_bs.get('py'), {'is_bold': True})
        else:
            has_total = False
            for row_data in note_group.get('data', []):
                part = str(row_data.get('particulars', '')).lower()
                if any(k in part for k in ('total', 'net block', 'net carrying', 'closing balance')):
                    has_total = True
                _write_note_row(row_data.get('particulars', ''),
                                row_data.get('cy'), row_data.get('py'), row_data)

            # Some notes (e.g. Deferred Tax) lose their total row to a parser
            # split, so the note shows no total. Surface the authoritative BS
            # total so every linked note ends with a total. Only for notes that
            # actually have data rows (never fabricate a total for an empty note).
            if note_group.get('data') and not has_total and note_totals:
                bs = note_totals.get(normalize_name(note_group.get('note_num', '')))
                if bs and (bs.get('cy') is not None or bs.get('py') is not None):
                    _write_note_row('Total (per Balance Sheet)',
                                    bs.get('cy'), bs.get('py'), {'is_bold': True})

        current_row += 2

# Ratio cell mapping. Each ratio's numerator and denominator are expressed as a
# list of terms (coeff, kind, sheet, [keywords]) that resolve to the EXACT BS/PL
# ANALYSIS cells feeding the ratio. The CY/PY value cell becomes a live
# cross-sheet formula (e.g. =('BS ANALYSIS'!C34+'BS ANALYSIS'!C38+'BS ANALYSIS'!C42)
# /'BS ANALYSIS'!C31) and a separate CELL MAPPING column shows the same in short
# form ((C34+C38+C42)/C31). Before any reference is used the resolved figures are
# VERIFIED against the engine's numerator/denominator; if they don't match the
# cell falls back to the literal-number formula, so the displayed value is always
# correct.
_RATIO_ANALYSIS_SHEET = {'BS': 'BS Analysis', 'PL': 'P&L Analysis'}
_RATIO_COL = {'cy': 'C', 'py': 'D'}

_PBT_KW = ['profit for the year before tax', 'profit / (loss) before', 'profit/(loss) before',
           'profit before tax', 'before exceptional items and tax', 'before tax']
_PAT_KW = ['profit/(loss) after tax', 'profit / (loss) after tax', 'profit after tax',
           'after tax (a)', 'profit/(loss) for the year', 'profit for the year']
_FIN_KW = ['finance cost', 'finance charge', 'finance costs']
_NCL_KW = ['total non-current liabilities', 'total non current liabilities']
_REV_KW = ['revenue from operations', 'revenue from contracts', 'software services',
           'sale of products', 'sale of services', 'revenue from']

# term = (coeff, kind, sheet, keywords); kind in {'line','avg','borr'}.
_RATIO_SPEC = {
    'Trade Receivables Turnover Ratio': {
        'num': [(1, 'line', 'PL', _REV_KW)],
        'den': [(1, 'avg', 'BS', ['trade receivables'])]},
    'Accounts Receivable Collection Period': {
        'num': [(365, 'avg', 'BS', ['trade receivables'])],
        'den': [(1, 'line', 'PL', _REV_KW)]},
    'Total Assets Ratio': {
        'num': [(1, 'line', 'PL', ['total income', 'total revenue'])],
        'den': [(1, 'line', 'BS', ['total assets'])]},
    'Net Working Capital Ratio': {
        'num': [(1, 'line', 'BS', ['total current assets']),
                (-1, 'line', 'BS', ['total current liabilities'])],
        'den': [(1, 'line', 'BS', ['total assets'])]},
    'Cash Ratio': {
        'num': [(1, 'line', 'BS', ['cash and cash equivalents', 'cash and bank'])],
        'den': [(1, 'line', 'BS', ['total current liabilities'])]},
    'Current Ratio': {
        'num': [(1, 'line', 'BS', ['total current assets'])],
        'den': [(1, 'line', 'BS', ['total current liabilities'])]},
    'Debt Equity Ratio': {
        'num': [(1, 'borr', 'BS', None)],
        'den': [(1, 'line', 'BS', ['total equity'])]},
    'Return on Equity (ROE)': {
        'num': [(1, 'line', 'PL', _PBT_KW)],
        'den': [(1, 'avg', 'BS', ['total equity'])], 'pct': True},
    'GCA Days': {
        'num': [(1, 'line', 'BS', ['total current assets'])],
        'den': [(1, 'line', 'PL', ['total income', 'total revenue'])],
        'mult': 365},
    'Total Outside Liab. vs Total Equity': {
        'num': [(1, 'line', 'BS', ['total current liabilities']),
                (1, 'line', 'BS', _NCL_KW)],
        'den': [(1, 'line', 'BS', ['total equity'])]},
    'Net Profit Ratio': {
        # PAT first; fall back to the PBT line when the FS has no separate
        # profit-after-tax row (the engine itself falls back PAT=PBT there, so the
        # value-check still confirms the referenced cell).
        'num': [(1, 'line', 'PL', _PAT_KW + _PBT_KW)],
        'den': [(1, 'line', 'PL', _REV_KW)], 'pct': True},
    'Return on Capital Employed (ROCE)': {
        'num': [(1, 'line', 'PL', _PBT_KW), (1, 'line', 'PL', _FIN_KW)],
        'den': [(1, 'line', 'BS', ['total equity']), (1, 'borr', 'BS', None)],
        'pct': True},
    'Debt Service Coverage Ratio': {
        'num': [(1, 'line', 'PL', _PBT_KW), (1, 'line', 'PL', _FIN_KW),
                (1, 'line', 'PL', ['depreciation'])],
        'den': [(1, 'line', 'PL', _FIN_KW)]},
    'Inventory Turnover Ratio': {
        'num': [(1, 'line', 'PL', ['cost of materials'])],
        'den': [(1, 'avg', 'BS', ['inventories', 'inventory'])]},
}


def _ratio_close(a, b):
    try:
        return abs(float(a) - float(b)) <= max(1.0, 0.01 * abs(float(b)))
    except (TypeError, ValueError):
        return False


def _line_cell(idx, sheet_key, keywords, year):
    col = _RATIO_COL[year]
    sheet = _RATIO_ANALYSIS_SHEET[sheet_key]
    for kw in keywords:
        for it in idx:
            if kw in it['p']:
                v = it['cy'] if year == 'cy' else it['py']
                if isinstance(v, (int, float)):
                    return f"'{sheet}'!{col}{it['row']}", f"{col}{it['row']}", float(v)
    return None


def _avg_cell(idx, sheet_key, keywords, year):
    # CY = average of (CY, PY); PY = closing — matches the engine (avg for CY,
    # closing for PY) for turnover / ROE denominators.
    sheet = _RATIO_ANALYSIS_SHEET[sheet_key]
    for kw in keywords:
        for it in idx:
            if kw in it['p']:
                cy = it['cy'] if isinstance(it['cy'], (int, float)) else None
                py = it['py'] if isinstance(it['py'], (int, float)) else None
                if year == 'cy':
                    if cy is None or py is None:
                        continue
                    return (f"('{sheet}'!C{it['row']}+'{sheet}'!D{it['row']})/2",
                            f"(C{it['row']}+D{it['row']})/2", (cy + py) / 2.0)
                if py is None:
                    continue
                return f"'{sheet}'!D{it['row']}", f"D{it['row']}", float(py)
    return None


def _borrowings_cells(bs_idx, year):
    # Borrowings = LIABILITY-section rows literally named "Borrowing(s)" only
    # (mirrors excel_parser.find_borrowings). Lease liabilities and the
    # Right-of-use asset are NOT borrowings and are excluded. When the sheet has
    # no borrowings this returns None and Debt-Equity / ROCE show -NA-.
    col = _RATIO_COL[year]
    sheet = _RATIO_ANALYSIS_SHEET['BS']
    in_liab = False
    refs, maps, total = [], [], 0.0
    for it in bs_idx:
        if 'current liabilities' in it['p']:  # matches both NC and current headers
            in_liab = True
        if in_liab and 'borrowing' in it['p']:
            v = it['cy'] if year == 'cy' else it['py']
            if isinstance(v, (int, float)) and v != 0:
                refs.append(f"'{sheet}'!{col}{it['row']}")
                maps.append(f"{col}{it['row']}")
                total += v
    if not refs:
        return None
    return refs, maps, total


def _resolve_side(terms, year, bs_idx, pl_idx):
    """Return (excel_expr, map_expr, value) for one side of a ratio, or None if
    any term can't be resolved to a verified cell."""
    ref_parts, map_parts, total = [], [], 0.0
    for (coeff, kind, sheet_key, keywords) in terms:
        idx = bs_idx if sheet_key == 'BS' else pl_idx
        if kind == 'borr':
            res = _borrowings_cells(bs_idx, year)
            if not res:
                # No borrowings line — it contributes 0. Skip the term so the side
                # still resolves to a live ref from its other parts (e.g. ROCE
                # denominator = Equity alone). If borrowings is the ONLY term
                # (Debt-Equity numerator) the side ends up empty and we return
                # None below — but that ratio is already -NA- so it never gets here.
                continue
            refs, maps, v = res
            # No inner parens — borrowings only ever appears in additive contexts
            # (alone, or Equity + Borrowings), so the outer _wrap handles grouping.
            seg_ref, seg_map = '+'.join(refs), '+'.join(maps)
        elif kind == 'avg':
            res = _avg_cell(idx, sheet_key, keywords, year)
            if not res:
                return None
            seg_ref, seg_map, v = res
        else:
            res = _line_cell(idx, sheet_key, keywords, year)
            if not res:
                return None
            seg_ref, seg_map, v = res
        mag = abs(coeff)
        if mag != 1:
            seg_ref, seg_map, v = f'{seg_ref}*{int(mag)}', f'{seg_map}*{int(mag)}', v * mag
        ref_parts.append((coeff > 0, seg_ref))
        map_parts.append((coeff > 0, seg_map))
        total += v if coeff > 0 else -v

    if not ref_parts:
        return None
    def _join(parts):
        s = ''
        for i, (pos, seg) in enumerate(parts):
            if i == 0:
                s = seg if pos else f'-{seg}'
            else:
                s += f'+{seg}' if pos else f'-{seg}'
        return s
    return _join(ref_parts), _join(map_parts), total


def _build_ratio_cell(ratio, year, bs_idx, pl_idx, ratio_row_map=None):
    """Return (value_cell, map_text, comment) for one year of a ratio.

    Prefers a live cell-reference formula; falls back to the literal-number
    formula if the cells can't be verified against the engine's figures.

    ratio_row_map: dict of {ratio_key: excel_row} for already-written ratio
    rows; used so ARCP can reference the TRTR cell directly (365/TRTR_cell)."""
    label = 'CY' if year == 'cy' else 'PY'
    ftext = ratio.get('formula', '')
    # --- Yellow Line 1: ARCP uses the already-written TRTR row directly ---
    if ratio.get('key') == 'Accounts Receivable Collection Period' and ratio_row_map:
        trtr_row = ratio_row_map.get('Trade Receivables Turnover Ratio')
        if trtr_row:
            col = 'D' if year == 'cy' else 'E'
            formula = f'=IF(ISNUMBER({col}{trtr_row}), IF({col}{trtr_row}=0, "-NA-", 365/{col}{trtr_row}), "-NA-")'
            mapping = f'365/{col}{trtr_row}'
            comment = (f"{ratio.get('key', '')} ({label})\n{ftext}\n"
                       f"= 365 / {col}{trtr_row} (Trade Receivables Turnover Ratio)")
            return formula, mapping, comment

    if ratio.get(year) is None:
        return '-NA-', '-NA-', (f"{ratio.get('key', '')} ({label})\n{ftext}\n"
                                "-NA- : a required source value was not found.")

    spec = _RATIO_SPEC.get(ratio.get('key'))
    eng_num, eng_den = ratio.get(f'{year}_num'), ratio.get(f'{year}_den')
    if spec and eng_num is not None and eng_den is not None and bs_idx is not None:
        num = _resolve_side(spec['num'], year, bs_idx, pl_idx)
        den = _resolve_side(spec['den'], year, bs_idx, pl_idx)
        mult = spec.get('mult')  # e.g. 365 for GCA Days
        # For ratios with a post-multiplication (GCA Days: result * 365),
        # eng_num already contains ca*365, so verify against ca (eng_num/mult)
        # to get the raw numerator, then build formula as (num/den)*mult.
        eng_num_raw = (eng_num / mult) if mult else eng_num
        if (num and den and den[2] not in (0, None)
                and _ratio_close(num[2], eng_num_raw) and _ratio_close(den[2], eng_den)):
            pct = spec.get('pct')

            def _wrap(expr, also='+-'):
                return f'({expr})' if any(op in expr for op in also) else expr
            nE = _wrap(num[0], '+-')
            dE = _wrap(den[0], '+-*/')
            nM = _wrap(num[1], '+-')
            dM = _wrap(den[1], '+-*/')
            if mult:
                formula = f'=({nE}/{dE})*{int(mult)}'
                mapping = f'({nM}/{dM})*{int(mult)}'
            else:
                formula = f'={nE}/{dE}' + ('*100' if pct else '')
                mapping = f'{nM}/{dM}' + ('*100' if pct else '')
            comment = (f"{ratio.get('key', '')} ({label})\n{ftext}\n"
                       f"= {ratio.get(f'{year}_calc', '')}\nCells: {mapping}")
            return formula, mapping, comment

    # Fallback — literal-number formula (always numerically correct).
    calc = ratio.get(f'{year}_calc')
    if not calc:
        return '-NA-', '-NA-', f"{ratio.get('key', '')} ({label})\n{ftext}\n-NA-"
    comment = (f"{ratio.get('key', '')} ({label})\n{ftext}\n= {calc}\n"
               "(source cells could not be verified — showing literal values)")
    return f'={calc}', f'(literal) {calc}', comment


def _write_ratio_sheet(ws, ratios, client_name, firm_name, cy_year, py_year,
                       bs_row_map, pl_row_map, bs_result=None, pl_result=None,
                       bs_row_index=None, pl_row_index=None):
    _set_col_widths(ws, {
        'A': 5, 'B': 35, 'C': 45, 'D': 16, 'E': 16, 'F': 14, 'G': 45
    })

    # Firm name omitted (Cover page only). Client name retained.
    ws.cell(row=2, column=2, value='Client:').font = FONT_BOLD
    ws.cell(row=2, column=3, value=client_name).font = FONT_NORMAL
    ws.cell(row=3, column=2, value='Ratio Analysis').font = FONT_SUBTITLE
    ws.cell(row=4, column=2,
            value=f'As at 31 March {cy_year} vs 31 March {py_year}').font = FONT_NORMAL
    ws.cell(row=5, column=2,
            value='Scope: Percentage variance of +/- 10% have been selected for analysis').font = FONT_LEGEND
    ws.cell(row=6, column=2,
            value='Each CY/PL value cell links to the exact BS/P&L ANALYSIS source cells '
                  '(click a cell to see its formula).').font = FONT_LEGEND

    headers = ['', 'KEY METRIC', 'FORMULA', f'{cy_year}-{str(cy_year+1)[-2:]} (CY)',
               f'{py_year}-{str(py_year+1)[-2:]} (PY)', 'CHANGE (%)', 'REMARKS']
    for i, h in enumerate(headers):
        cell = ws.cell(row=7, column=i + 1, value=h)
        cell.font = FONT_HEADER
        cell.fill = FILL_HEADER
        cell.alignment = ALIGN_CENTER
        cell.border = THIN_BORDER

    ws.freeze_panes = 'A8'

    r = 8
    current_section = None
    ratio_row_map = {}  # {ratio_key: excel_row} for cross-ratio references (e.g. ARCP→TRTR)
    for ratio in ratios:
        section = ratio.get('section', '')
        if section and section != current_section:
            if current_section is not None:
                r += 1  # blank gap row separating each ratio section
            current_section = section
            sc = ws.cell(row=r, column=2, value=section)
            sc.font = FONT_BOLD
            for cc in range(1, 8):
                cell = ws.cell(row=r, column=cc)
                cell.fill = FILL_LIGHT
                cell.border = THIN_BORDER
            r += 1

        ws.cell(row=r, column=2, value=ratio['key']).font = FONT_BOLD
        ws.cell(row=r, column=3, value=ratio['formula']).font = FONT_NORMAL

        # Record this ratio's row before writing so later ratios can reference it
        ratio_row_map[ratio['key']] = r

        # CY (D) and PY (E): a live cross-sheet formula to the real source cells.
        for col, year in ((4, 'cy'), (5, 'py')):
            value, _map_text, _comment = _build_ratio_cell(
                ratio, year, bs_row_index, pl_row_index, ratio_row_map)
            ws.cell(row=r, column=col).value = value

        change = ratio.get('change', None)
        change_cell = ws.cell(row=r, column=6)
        cy_v, py_v = ratio.get('cy'), ratio.get('py')
        if cy_v is not None and py_v not in (None, 0):
            change_cell.value = f'=(D{r}-E{r})/ABS(E{r})'
        else:
            change_cell.value = '-'

        ws.cell(row=r, column=4).number_format = NUMBER_FORMAT_2DP
        ws.cell(row=r, column=5).number_format = NUMBER_FORMAT_2DP
        change_cell.number_format = PCT_FORMAT

        for col in range(1, 8):
            ws.cell(row=r, column=col).border = THIN_BORDER

        if change is not None:
            if change > 0:
                change_cell.font = Font(name='Arial', size=11, color='22C55E')
            elif change < 0:
                change_cell.font = Font(name='Arial', size=11, color='EF4444')

        r += 1

def _write_visuals_sheet(ws, chart_paths, client_name, firm_name, cy_year, rounding_unit):
    ws.views.sheetView[0].showGridLines = True

    _set_col_widths(ws, {
        'A': 4, 'B': 12, 'C': 12, 'D': 12, 'E': 12, 'F': 12, 'G': 12,
        'H': 4, 'I': 12, 'J': 12, 'K': 12, 'L': 12, 'M': 12, 'N': 12
    })

    ws.cell(row=2, column=2, value='Visual Analytics Dashboard').font = FONT_TITLE
    # Firm name omitted (Cover page only).
    ws.cell(row=4, column=2, value=f'Client: {client_name} — FY {cy_year}').font = FONT_SUBTITLE
    ws.cell(row=5, column=2, value=f'Amounts in: Rs. {rounding_unit}').font = FONT_LEGEND

    from openpyxl.drawing.image import Image

    positions = [
        'B7',
        'I7',
        'B29',
        'I29',
        'B51',
        'I51',
    ]

    for idx, path in enumerate(chart_paths):
        if idx >= len(positions):
            break
        if not os.path.exists(path):
            logger.warning("Chart image path does not exist: %s", path)
            continue
        try:
            img = Image(path)
            img.width = 500
            img.height = 350
            ws.add_image(img, positions[idx])
        except Exception as e:
            logger.error("Failed to add chart %d to Excel: %s", idx, e)

