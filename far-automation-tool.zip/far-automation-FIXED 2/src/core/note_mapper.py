import re
import difflib
import logging
import os

os.makedirs('logs', exist_ok=True)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
    fh = logging.FileHandler('logs/note_mapping.log', mode='w', encoding='utf-8')
    fh.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

def _normalize_note_num(note_str):
    if not note_str:
        return ""
    s = str(note_str).upper()
    s = re.sub(r'NOTE', '', s)
    s = re.sub(r'NO\.?', '', s)
    s = re.sub(r'[^A-Z0-9]', '', s)
    return s

def _is_total_row(particulars):
    if not particulars:
        return False
    p = str(particulars).lower()
    keywords = [
        'total', 'grand total', 'net total', 'closing balance',
        'total carrying amount', 'total value'
    ]
    return any(k in p for k in keywords)

def _get_float_val(val):
    if val is None or val == '-':
        return 0.0
    try:
        return float(str(val).replace(',', '').replace(' ', ''))
    except (ValueError, TypeError):
        return 0.0

def _find_best_total_row(data_rows, target_amount, scales_to_try):
    """Find the row whose value best matches ``target_amount`` (the BS/P&L figure).

    Every row is considered — not just 'total'-labelled ones — so notes without an
    explicit total row (e.g. share capital's 'Issued and subscribed' line) still
    match the referenced figure. A 'total'/'closing balance'/'net block' row is
    preferred only when it is just as close as the best non-total row.
    """
    scored = []
    for cand in data_rows:
        cand_cy_val = _get_float_val(cand.get('cy'))
        for scale in scales_to_try:
            scored.append((abs(target_amount - cand_cy_val * scale), cand, scale))
    if not scored:
        return None, float('inf'), 1.0

    scored.sort(key=lambda x: x[0])
    best_var, best_cand, best_scale = scored[0]

    # Among rows essentially as close as the best, prefer a real total row.
    tol = max(1.0, abs(target_amount) * 0.005)
    chosen_cand, chosen_var, chosen_scale = best_cand, best_var, best_scale
    for var, cand, scale in scored:
        if var > best_var + tol:
            break
        p = str(cand.get('particulars', '')).lower()
        if _is_total_row(p) or 'closing balance' in p or 'net block' in p:
            chosen_cand, chosen_var, chosen_scale = cand, var, scale
            break

    # Fallback — a note may list its components without an explicit total row
    # (e.g. Trade Receivables split into related-party / others / unbilled).
    # When no single row ties out, test whether the COMPONENT ROWS SUM to the
    # target; if so, that sum is the real tie-out. Gated on chosen_var > tol so
    # any note that already matches a real total/closing/net-block row is left
    # completely unchanged.
    if chosen_var > tol:
        leaf = [r for r in data_rows
                if not _is_total_row(str(r.get('particulars', '')).lower())]
        if len(leaf) >= 2:
            sum_cy = sum(_get_float_val(r.get('cy')) for r in leaf)
            sum_py = sum(_get_float_val(r.get('py')) for r in leaf)
            for scale in scales_to_try:
                sv = abs(target_amount - sum_cy * scale)
                if sv < chosen_var:
                    chosen_cand = {'particulars': 'Total (sum of components)',
                                   'cy': sum_cy, 'py': sum_py}
                    chosen_var, chosen_scale = sv, scale
    return chosen_cand, chosen_var, chosen_scale

def map_bs_to_notes(bs_data, notes_data_dict, rounding_factor=1.0, tolerance=1.0):
    """
    Matches Balance Sheet items to their corresponding Notes to Accounts total rows.
    """
    results = []
    
    all_note_groups = []
    for sheet_notes in notes_data_dict.values():
        if isinstance(sheet_notes, list):
            all_note_groups.extend(sheet_notes)
    
    for ng in all_note_groups:
        ng['norm_num'] = _normalize_note_num(ng.get('note_num'))
        
    scales_to_test = [1.0]
    if rounding_factor > 1.0:
        scales_to_test.append(1.0 / rounding_factor)
        scales_to_test.append(rounding_factor)
        
    for bs_row in bs_data:
        bs_part = bs_row.get('particulars', '')
        bs_note = str(bs_row.get('note', '')).strip()
        
        bs_cy_raw = bs_row.get('cy')
        bs_py_raw = bs_row.get('py')
        
        if not bs_note and bs_cy_raw in (None, '-', ''):
            continue
            
        bs_cy_val = _get_float_val(bs_cy_raw)
        bs_py_val = _get_float_val(bs_py_raw)
        
        match_found = False
        best_ng = None
        best_cand = None
        best_var_cy = float('inf')
        matched_by = "Not Found"
        match_conf = 0.0
        used_scale = 1.0
        
        norm_bs_note = _normalize_note_num(bs_note)
        
        # When the BS note number points to a table whose total does NOT tie out,
        # we don't blindly trust the number (source numbering is sometimes
        # misaligned). Remember that table as a fallback and let the total-match
        # search (Strategy 3) re-point to the table whose total actually matches.
        num_fallback = None  # (ng, cand, var_cy, scale)

        # 1. Exact Normalized Note Number Match
        if norm_bs_note:
            for ng in all_note_groups:
                if ng['norm_num'] == norm_bs_note:
                    cand, var_cy, scale = _find_best_total_row(ng.get('data', []), bs_cy_val, scales_to_test)
                    if cand:
                        if var_cy <= tolerance:
                            # Number and total agree — authoritative match.
                            best_ng = ng
                            best_cand = cand
                            best_var_cy = var_cy
                            used_scale = scale
                            match_found = True
                            matched_by = "Note Number"
                            match_conf = 1.00
                        else:
                            # Number matches but total is off — keep as a fallback
                            # and try to re-point to a total-matching table below.
                            num_fallback = (ng, cand, var_cy, scale)
                    break

        # 2. Heading Similarity Match (Fallback) — skipped when a numbered note
        #    already gave us a fallback, so the total-match search (Strategy 3)
        #    takes precedence when re-pointing a misaligned note number.
        if not match_found and num_fallback is None:
            best_sim = 0.0
            best_sim_ng = None
            for ng in all_note_groups:
                h_sim = difflib.SequenceMatcher(None, bs_part.lower(), str(ng.get('note_heading', '')).lower()).ratio()
                p_part = str(ng.get('data', [{}])[-1].get('particulars', '') if ng.get('data') else '').lower()
                p_sim = difflib.SequenceMatcher(None, bs_part.lower(), p_part).ratio()
                
                weighted_sim = 0.7 * p_sim + 0.3 * h_sim
                if weighted_sim > best_sim:
                    best_sim = weighted_sim
                    best_sim_ng = ng
            if best_sim > 0.80 and best_sim_ng is not None:
                cand, var_cy, scale = _find_best_total_row(best_sim_ng.get('data', []), bs_cy_val, scales_to_test)
                if cand:
                    best_ng = best_sim_ng
                    best_cand = cand
                    best_var_cy = var_cy
                    used_scale = scale
                    match_found = True
                    matched_by = "Heading Similarity"
                    match_conf = best_sim

        # 3. Amount Discovery Match (Fallback) — also re-points a numbered note
        #    whose total did not tie out to the table whose total does.
        ENABLE_AMOUNT_DISCOVERY = True
        if not match_found and ENABLE_AMOUNT_DISCOVERY and bs_cy_val > 0:
            best_cand_var = float('inf')
            best_cand_ng = None
            best_cand_row = None
            best_cand_scale = 1.0

            for ng in all_note_groups:
                cand, var_cy, scale = _find_best_total_row(ng.get('data', []), bs_cy_val, scales_to_test)
                if cand and var_cy < best_cand_var:
                    best_cand_var = var_cy
                    best_cand_ng = ng
                    best_cand_row = cand
                    best_cand_scale = scale

            # Light heading guard so a coincidental total in an unrelated note
            # can't hijack the match — only enforced when re-pointing a numbered
            # note (pure amount discovery on un-numbered rows is unaffected).
            guard_ok = True
            if num_fallback is not None and best_cand_ng is not None:
                h_sim = difflib.SequenceMatcher(
                    None, bs_part.lower(),
                    str(best_cand_ng.get('note_heading', '')).lower()).ratio()
                guard_ok = h_sim >= 0.40

            if best_cand_var <= tolerance and guard_ok:
                best_ng = best_cand_ng
                best_cand = best_cand_row
                best_var_cy = best_cand_var
                used_scale = best_cand_scale
                match_found = True
                if num_fallback is not None:
                    matched_by = "Note Number (re-pointed by total)"
                    match_conf = 0.90
                else:
                    matched_by = "Amount Discovery"
                    match_conf = 0.60

        # No total-matching table found — fall back to the table the note number
        # pointed at, surfaced as a Mismatch for manual review rather than dropped
        # as Not Found.
        if not match_found and num_fallback is not None:
            best_ng, best_cand, best_var_cy, used_scale = num_fallback
            match_found = True
            matched_by = "Note Number (total mismatch)"
            match_conf = 0.50

        if match_found and best_cand:
            cand_cy_val = _get_float_val(best_cand.get('cy')) * used_scale
            cand_py_val = _get_float_val(best_cand.get('py')) * used_scale
            
            var_py = abs(bs_py_val - cand_py_val)
            
            status_cy = "Matched" if best_var_cy <= tolerance else "Mismatch"
            status_py = "Matched" if var_py <= tolerance else "Mismatch"
            
            final_note_num = best_ng.get('note_num', '')
            if not final_note_num and bs_note:
                final_note_num = bs_note
                
            results.append({
                'bs_particular': bs_part,
                'note_num': final_note_num,
                'bs_cy': bs_cy_raw,
                'bs_py': bs_py_raw,
                'note_total_row': best_cand.get('particulars', ''),
                'note_cy': cand_cy_val,
                'note_py': cand_py_val,
                'variance_cy': best_var_cy,
                'variance_py': var_py,
                'status_cy': status_cy,
                'status_py': status_py,
                'matched_by': matched_by,
                'match_confidence': match_conf
            })
            
            logger.info(
                "MAPPED: Note %s | BS Particular: '%s' | BS Amount CY=%s PY=%s | "
                "Note Row: '%s' | Note Amount CY=%s PY=%s | Variance CY=%s PY=%s | "
                "Match By: %s (%.2f) | Validation Status CY=%s PY=%s",
                final_note_num, bs_part, bs_cy_raw, bs_py_raw,
                best_cand.get('particulars', ''), cand_cy_val, cand_py_val,
                best_var_cy, var_py, matched_by, match_conf, status_cy, status_py)
            
        elif bs_note:
            results.append({
                'bs_particular': bs_part,
                'note_num': bs_note,
                'bs_cy': bs_cy_raw,
                'bs_py': bs_py_raw,
                'note_total_row': '-',
                'note_cy': '-',
                'note_py': '-',
                'variance_cy': '-',
                'variance_py': '-',
                'status_cy': 'Not Found',
                'status_py': 'Not Found',
                'matched_by': 'Not Found',
                'match_confidence': 0.0
            })
            
            logger.info("NOT FOUND: Note %s | BS Particular: '%s' | BS Amount: %s", bs_note, bs_part, bs_cy_raw)
            
    return results
