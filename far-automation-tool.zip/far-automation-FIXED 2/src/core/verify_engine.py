"""
FAR Verification Engine (Engine 2).

Two-engine design:
  * Engine 1 (src/core/cpp_bridge.py) performs the variance and ratio CALCULATION.
  * Engine 2 — this module — runs AFTER Engine 1. It independently re-derives every
    variance and every ratio, cross-checks them against accounting identities, and
    returns the FINAL, verified result plus a structured verification report.

Goals:
  * Independent.  The variance core is recomputed in a vectorised NumPy pass and the
    ratios are re-derived directly from the BS/PL summaries by a second, separate
    implementation. An implementation drift or field corruption in Engine 1 then
    surfaces as a mismatch instead of silently shipping a wrong number. (This is the
    class of bug that the retired C++ engine had: "Net Profit Ratio" using PBT
    instead of PAT — Engine 2 catches exactly that.)
  * Fast.  NumPy vectorises the per-row variance arithmetic; the ratio checks are
    O(number of ratios). NumPy is optional — a pure-Python fallback keeps the engine
    working in a packaged build where NumPy may be absent.
  * Final authority.  Engine 2 independently re-derives every numeric field (the
    four variance fields; each ratio's cy / py / change / flag / display) and the
    re-derivation is the FINALISED value. In the normal case Engine 1 already agrees,
    so nothing changes. Where it diverged, Engine 2's value wins AND the change is
    recorded as a mismatch + correction, so the report is a full audit trail rather
    than a silent rewrite. Engine 1's structural fields (formula text, section,
    cy_num/den, the worked cy_calc/py_calc strings) are preserved.

Scope note: Engine 2 verifies the CALCULATION layer. It does not re-extract the
BS/PL summaries from the raw workbook (both engines share that input), so summary
mis-extraction is left to src/core/validation.py's business-rule checks.
"""

import logging
import math

logger = logging.getLogger(__name__)

try:
    import numpy as _np
except Exception:  # pragma: no cover - packaged build without NumPy
    _np = None

# Tolerances. Real matches are exact (both engines round identically); these only
# absorb floating-point noise and the rounding chain, while still catching gross
# errors (wrong formula, swapped field, missing ×100, wrong sign, 10x slip).
_VAR_ABS_TOL = 0.02      # variance_abs / variance_pct (Engine 1 rounds to 2 dp)
_RATIO_ABS_TOL = 0.01    # ratio cy/py absolute
_RATIO_REL_TOL = 0.005   # ratio cy/py relative (0.5%)
_CHANGE_ABS_TOL = 0.2    # % change absolute
_CHANGE_REL_TOL = 0.01   # % change relative


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #
class VerificationReport:
    ENGINE = "verify_engine v1"

    def __init__(self):
        self.checks = 0
        self.passed = 0
        self.mismatches = []   # serious: value disagreements (reported, not silently fixed)
        self.corrections = []  # derived fields Engine 2 re-derived and overwrote
        self.warnings = []

    @property
    def ok(self):
        return len(self.mismatches) == 0

    def add_pass(self):
        self.checks += 1
        self.passed += 1

    def add_mismatch(self, scope, key, field, engine1, engine2, detail):
        self.checks += 1
        self.mismatches.append({
            "scope": scope, "key": key, "field": field,
            "engine1": engine1, "engine2": engine2, "detail": detail,
        })
        logger.warning("VERIFY MISMATCH [%s] %s.%s: engine1=%r engine2=%r — %s",
                       scope, key, field, engine1, engine2, detail)

    def add_correction(self, scope, key, field, old, new):
        self.corrections.append({
            "scope": scope, "key": key, "field": field, "old": old, "new": new,
        })
        logger.info("VERIFY CORRECT [%s] %s.%s: %r -> %r", scope, key, field, old, new)

    def add_warning(self, msg):
        self.warnings.append(msg)
        logger.warning("VERIFY WARN - %s", msg)

    def summary_text(self):
        return (f"{self.passed}/{self.checks} checks passed, "
                f"{len(self.mismatches)} mismatch(es), "
                f"{len(self.corrections)} correction(s)")

    def to_dict(self):
        return {
            "engine": self.ENGINE,
            "ok": self.ok,
            "summary": self.summary_text(),
            "counts": {
                "checks": self.checks,
                "passed": self.passed,
                "mismatches": len(self.mismatches),
                "corrections": len(self.corrections),
                "warnings": len(self.warnings),
            },
            "mismatches": self.mismatches,
            "corrections": self.corrections,
            "warnings": self.warnings,
        }


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _is_absent(v):
    return v is None or v == '-'


def _close(a, b, abs_tol, rel_tol):
    """Numeric closeness that treats None and inf safely."""
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    try:
        a = float(a)
        b = float(b)
    except (TypeError, ValueError):
        return a == b
    if math.isinf(a) or math.isinf(b) or math.isnan(a) or math.isnan(b):
        return (math.isinf(a) and math.isinf(b)) or (math.isnan(a) and math.isnan(b))
    return abs(a - b) <= max(abs_tol, rel_tol * max(abs(a), abs(b)))


def _parse_pct(s):
    if not isinstance(s, str) or not s.endswith('%'):
        return None
    try:
        return float(s[:-1])
    except ValueError:
        return None


def _display_equiv(a, b):
    """Two percentage strings that mean the same number (absorbs .1f rounding)."""
    if a == b:
        return True
    pa, pb = _parse_pct(a), _parse_pct(b)
    if pa is None or pb is None:
        return False
    return abs(pa - pb) <= 0.05


def _row_label(row):
    part = str(row.get('particulars', '') or '').strip() or '?'
    note = str(row.get('note', '') or '').strip()
    return f"{part}" + (f" (Note {note})" if note else "")


# --------------------------------------------------------------------------- #
# Variance re-derivation (mirrors Engine 1's spec exactly)
# --------------------------------------------------------------------------- #
def _variance_record(cy_val, py_val, var_abs=None):
    """Canonical {variance_abs, variance_pct, display_pct, flag} for one row.

    `var_abs` may be supplied pre-computed (vectorised NumPy path); otherwise it is
    derived here. All decision/rounding logic lives in this one function so the
    NumPy and pure-Python paths can never diverge.
    """
    cy_absent = _is_absent(cy_val)
    py_absent = _is_absent(py_val)

    if cy_absent and py_absent:
        display = '-NA-' if (cy_val is None and py_val is None) else '-'
        return {'variance_abs': None, 'variance_pct': None, 'display_pct': display, 'flag': False}

    cy = 0.0 if cy_absent else float(cy_val)
    py = 0.0 if py_absent else float(py_val)
    if var_abs is None:
        var_abs = cy - py

    if py == 0.0:
        if cy == 0.0:
            pct = 0.0
            display = '0.0%'
        else:
            pct = math.inf
            display = 'N/A'
    else:
        pct = (var_abs / abs(py)) * 100.0
        display = f'{pct:.1f}%'

    abs_pct = 0.0 if (py == 0.0 and cy == 0.0) else (100.0 if py == 0.0 else abs(pct))
    flag = abs_pct >= 10.0

    return {
        'variance_abs': round(var_abs, 2),
        'variance_pct': round(pct, 2) if not math.isinf(pct) else None,
        'display_pct': display,
        'flag': flag,
    }


def _reference_variances(rows):
    """Independent {variance fields} for every row. Vectorised with NumPy where
    available, otherwise a scalar loop. Same numbers either way."""
    n = len(rows)
    if _np is not None and n:
        cy = _np.zeros(n, dtype=float)
        py = _np.zeros(n, dtype=float)
        for i, row in enumerate(rows):
            cv, pv = row.get('cy'), row.get('py')
            if not (_is_absent(cv) and _is_absent(pv)):
                cy[i] = 0.0 if _is_absent(cv) else float(cv)
                py[i] = 0.0 if _is_absent(pv) else float(pv)
        var_abs = cy - py  # one vectorised pass
        return [_variance_record(rows[i].get('cy'), rows[i].get('py'), var_abs=float(var_abs[i]))
                for i in range(n)]
    return [_variance_record(r.get('cy'), r.get('py')) for r in rows]


def _verify_variances(rows, label, report):
    """Compare Engine 1's rows against the independent recompute; finalise with the
    Engine 2 value on any mismatch (variances are a deterministic recompute, so
    Engine 2 is authoritative here)."""
    refs = _reference_variances(rows)
    final = []
    for row, ref in zip(rows, refs):
        merged = dict(row)
        for field in ('variance_abs', 'variance_pct', 'display_pct', 'flag'):
            e1 = row.get(field)
            e2 = ref[field]
            if field in ('variance_abs', 'variance_pct'):
                match = _close(e1, e2, _VAR_ABS_TOL, 0.0)
            elif field == 'flag':
                match = bool(e1) == bool(e2)
            else:  # display_pct
                match = (e1 == e2)
            if match:
                report.add_pass()
            else:
                report.add_mismatch(label, _row_label(row), field, e1, e2,
                                    "variance field differs from independent recompute")
                merged[field] = e2
                report.add_correction(label, _row_label(row), field, e1, e2)
        final.append(merged)
    return final


# --------------------------------------------------------------------------- #
# Ratio re-derivation (independent second implementation of the 14 ratios)
# --------------------------------------------------------------------------- #
def _reference_ratios(bs, pl):
    def g(d, key):
        v = d.get(key, 0.0)
        try:
            return float(v) if v is not None else 0.0
        except (TypeError, ValueError):
            return 0.0

    eq_cy, eq_py = g(bs, 'total_equity_cy'), g(bs, 'total_equity_py')
    ca_cy, ca_py = g(bs, 'total_ca_cy'), g(bs, 'total_ca_py')
    cl_cy, cl_py = g(bs, 'total_cl_cy'), g(bs, 'total_cl_py')
    ncl_cy, ncl_py = g(bs, 'total_ncl_cy'), g(bs, 'total_ncl_py')
    at_cy, at_py = g(bs, 'total_assets_cy'), g(bs, 'total_assets_py')
    ltb_cy, ltb_py = g(bs, 'ltb_cy'), g(bs, 'ltb_py')
    stb_cy, stb_py = g(bs, 'stb_cy'), g(bs, 'stb_py')
    debt_cy, debt_py = g(bs, 'debtors_cy'), g(bs, 'debtors_py')
    cash_cy, cash_py = g(bs, 'cash_cy'), g(bs, 'cash_py')
    inv_cy, inv_py = g(bs, 'inventory_cy'), g(bs, 'inventory_py')

    rev_cy, rev_py = g(pl, 'revenue_ops_cy'), g(pl, 'revenue_ops_py')
    inc_cy, inc_py = g(pl, 'total_revenue_cy'), g(pl, 'total_revenue_py')
    pbt_cy, pbt_py = g(pl, 'pbt_cy'), g(pl, 'pbt_py')
    pat_cy, pat_py = g(pl, 'pat_cy'), g(pl, 'pat_py')
    fin_cy, fin_py = g(pl, 'finance_cost_cy'), g(pl, 'finance_cost_py')
    com_cy, com_py = g(pl, 'cost_materials_cy'), g(pl, 'cost_materials_py')
    dep_cy, dep_py = g(pl, 'depreciation_cy'), g(pl, 'depreciation_py')

    adebt_cy = (debt_cy + debt_py) / 2.0 if (debt_cy + debt_py) > 0 else 0.0
    adebt_py = debt_py
    aeq_cy = (eq_cy + eq_py) / 2.0
    ainv_cy = (inv_cy + inv_py) / 2.0 if (inv_cy + inv_py) > 0 else 0.0
    ainv_py = inv_py
    borr_cy, borr_py = ltb_cy + stb_cy, ltb_py + stb_py

    def rr(num, den, is_pct=False, na=False):
        if na or den == 0:
            return None
        v = num / den
        return v * 100.0 if is_pct else v

    return {
        'Trade Receivables Turnover Ratio': {
            'cy': rr(rev_cy, adebt_cy, na=(adebt_cy == 0)),
            'py': rr(rev_py, adebt_py, na=(adebt_py == 0))},
        'Accounts Receivable Collection Period': {
            'cy': rr(365.0 * adebt_cy, rev_cy, na=(adebt_cy == 0 or rev_cy == 0)),
            'py': rr(365.0 * adebt_py, rev_py, na=(adebt_py == 0 or rev_py == 0))},
        'Total Assets Ratio': {
            'cy': rr(inc_cy, at_cy, na=(at_cy == 0 or inc_cy == 0)),
            'py': rr(inc_py, at_py, na=(at_py == 0 or inc_py == 0))},
        'Net Working Capital Ratio': {
            'cy': rr(ca_cy - cl_cy, at_cy, na=(at_cy == 0)),
            'py': rr(ca_py - cl_py, at_py, na=(at_py == 0))},
        'Cash Ratio': {
            'cy': rr(cash_cy, cl_cy, na=(cl_cy == 0 or cash_cy == 0)),
            'py': rr(cash_py, cl_py, na=(cl_py == 0 or cash_py == 0))},
        'Current Ratio': {
            'cy': rr(ca_cy, cl_cy, na=(cl_cy == 0)),
            'py': rr(ca_py, cl_py, na=(cl_py == 0))},
        'Debt Equity Ratio': {
            'cy': rr(borr_cy, eq_cy, na=(borr_cy == 0 or eq_cy == 0)),
            'py': rr(borr_py, eq_py, na=(borr_py == 0 or eq_py == 0))},
        'Return on Equity (ROE)': {
            'cy': rr(pbt_cy, aeq_cy, is_pct=True, na=(aeq_cy == 0)),
            'py': rr(pbt_py, eq_py, is_pct=True, na=(eq_py == 0))},
        'GCA Days': {
            'cy': rr(ca_cy * 365.0, inc_cy, na=(inc_cy == 0)),
            'py': rr(ca_py * 365.0, inc_py, na=(inc_py == 0))},
        'Total Outside Liab. vs Total Equity': {
            'cy': rr(cl_cy + ncl_cy, eq_cy, na=(eq_cy == 0)),
            'py': rr(cl_py + ncl_py, eq_py, na=(eq_py == 0))},
        'Net Profit Ratio': {
            'cy': rr(pat_cy, rev_cy, is_pct=True, na=(rev_cy == 0)),
            'py': rr(pat_py, rev_py, is_pct=True, na=(rev_py == 0))},
        'Return on Capital Employed (ROCE)': {
            # Borrowings are only PART of the denominator (Equity + Borrowings).
            # If borrowings are absent but Equity/PBT/Finance exist, ROCE still
            # computes (Capital Employed = Equity). NA only when the whole
            # denominator (Equity + Borrowings) is zero.
            'cy': rr(pbt_cy + fin_cy, eq_cy + borr_cy, is_pct=True,
                     na=(eq_cy + borr_cy == 0)),
            'py': rr(pbt_py + fin_py, eq_py + borr_py, is_pct=True,
                     na=(eq_py + borr_py == 0))},
        'Debt Service Coverage Ratio': {
            'cy': rr(pbt_cy + fin_cy + dep_cy, fin_cy, na=(fin_cy == 0)),
            'py': rr(pbt_py + fin_py + dep_py, fin_py, na=(fin_py == 0))},
        'Inventory Turnover Ratio': {
            'cy': rr(com_cy, ainv_cy, na=(ainv_cy == 0 or com_cy == 0)),
            'py': rr(com_py, ainv_py, na=(ainv_py == 0 or com_py == 0))},
    }


def _change_record(cy, py):
    """Canonical (change, display_change, flag) for a ratio given its cy/py —
    mirrors Engine 1's change logic exactly."""
    if cy is None and py is None:
        return None, '-NA-', False
    if cy is None or py is None:
        return None, '-', False
    if py == 0:
        if cy == 0:
            return 0.0, '0.0%', False
        return 100.0, 'N/A', True
    change = ((cy - py) / abs(py)) * 100.0
    return round(change, 2), f'{change:.1f}%', abs(change) >= 10.0


def _verify_ratios(ratios, bs_summary, pl_summary, report):
    ref = _reference_ratios(bs_summary, pl_summary)
    final = []
    for r in ratios:
        key = r.get('key', '')
        merged = dict(r)

        rv = ref.get(key)
        if rv is not None:
            cy_ref, py_ref = rv['cy'], rv['py']
        else:
            # No independent formula for this key — fall back to Engine 1's own
            # cy/py (nothing to re-derive; this only checks internal consistency).
            cy_ref, py_ref = r.get('cy'), r.get('py')

        cy_fin = round(cy_ref, 4) if isinstance(cy_ref, (int, float)) else None
        py_fin = round(py_ref, 4) if isinstance(py_ref, (int, float)) else None
        # change / display / flag are derived from the FULL-PRECISION reference
        # values, so a correct Engine 1 matches exactly — no rounding-chain false
        # positives (Engine 1 also derives them from full-precision cy/py).
        exp_change, exp_disp, exp_flag = _change_record(cy_ref, py_ref)

        # Engine 2 is the final authority: each numeric field is the independent
        # re-derivation. Where Engine 1 agreed (the normal case) nothing changes;
        # where it diverged the value is corrected AND recorded (mismatch +
        # correction) so the report is a full audit trail. Engine 1's structural
        # fields (formula, section, cy_num/den, cy_calc) are preserved.
        checks = (
            ('cy', r.get('cy'), cy_fin,
             lambda a, b: _close(a, b, _RATIO_ABS_TOL, _RATIO_REL_TOL),
             "value differs from independent re-derivation from the BS/PL summary"),
            ('py', r.get('py'), py_fin,
             lambda a, b: _close(a, b, _RATIO_ABS_TOL, _RATIO_REL_TOL),
             "value differs from independent re-derivation from the BS/PL summary"),
            ('change', r.get('change'), exp_change,
             lambda a, b: _close(a, b, _CHANGE_ABS_TOL, _CHANGE_REL_TOL),
             "change inconsistent with cy/py"),
            ('flag', r.get('flag'), exp_flag,
             lambda a, b: bool(a) == bool(b),
             "flag inconsistent with change"),
            ('display_change', r.get('display_change'), exp_disp,
             _display_equiv,
             "display inconsistent with change"),
        )
        for field, e1, e2, matcher, detail in checks:
            if matcher(e1, e2):
                report.add_pass()
            else:
                report.add_mismatch('RATIO', key, field, e1, e2, detail)
                merged[field] = e2
                report.add_correction('RATIO', key, field, e1, e2)

        final.append(merged)

    _check_arcp_relation(final, report)
    return final


def _check_arcp_relation(ratios, report):
    """Cross-relation identity: AR Collection Period == 365 / Trade Receivables
    Turnover Ratio (independent of how either ratio was computed)."""
    by = {r.get('key'): r for r in ratios}
    trtr = by.get('Trade Receivables Turnover Ratio')
    arcp = by.get('Accounts Receivable Collection Period')
    if not trtr or not arcp:
        return
    for yr in ('cy', 'py'):
        t = trtr.get(yr)
        a = arcp.get(yr)
        if isinstance(t, (int, float)) and t != 0 and isinstance(a, (int, float)):
            expected = 365.0 / t
            if _close(a, expected, 0.5, 0.01):
                report.add_pass()
            else:
                report.add_mismatch(
                    'CROSS', 'Accounts Receivable Collection Period', yr, a,
                    round(expected, 4),
                    "should equal 365 / Trade Receivables Turnover Ratio")


# --------------------------------------------------------------------------- #
# Public entry point
# --------------------------------------------------------------------------- #
def verify_and_finalize(bs_variances, pl_variances, ratios, bs_summary, pl_summary):
    """Verify Engine-1 output and return the finalised, verified result.

    Returns a dict:
        {
          'bs_data':  finalised BS variance rows,
          'pl_data':  finalised PL variance rows,
          'ratios':   finalised ratios,
          'verification': <report.to_dict()>,
        }
    """
    report = VerificationReport()
    bs_final = _verify_variances(list(bs_variances or []), 'BS', report)
    pl_final = _verify_variances(list(pl_variances or []), 'PL', report)
    ratios_final = _verify_ratios(list(ratios or []), bs_summary or {}, pl_summary or {}, report)

    level = logger.info if report.ok else logger.warning
    level("Verification engine: %s", report.summary_text())

    return {
        'bs_data': bs_final,
        'pl_data': pl_final,
        'ratios': ratios_final,
        'verification': report.to_dict(),
    }
