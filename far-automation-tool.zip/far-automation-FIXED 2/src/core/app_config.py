"""Shared application-config helpers.

Single source of truth for loading the user's font / zoom preferences and for
scaling the QSS stylesheet. Used by both the startup path (``main.py``) and the
in-app Settings panel (``main_window.py``) so the two never drift apart.
"""

import os
import re
import json
import logging

logger = logging.getLogger(__name__)

DEFAULTS = {
    'font_family': 'Segoe UI',
    'font_size': 11,
    'ui_zoom': 100,
}


def config_path():
    """Per-user config location (``%APPDATA%/FAR_Automation/config.json``)."""
    config_dir = os.path.join(os.environ.get('APPDATA', ''), 'FAR_Automation')
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, 'config.json')


def load_config():
    """Load and validate the user config, falling back to ``DEFAULTS`` for any
    missing or out-of-range value."""
    path = config_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            fs = data.get('font_size', DEFAULTS['font_size'])
            if not isinstance(fs, (int, float)) or not (6 <= fs <= 36):
                data['font_size'] = DEFAULTS['font_size']

            uz = data.get('ui_zoom', DEFAULTS['ui_zoom'])
            if not isinstance(uz, (int, float)) or not (50 <= uz <= 200):
                data['ui_zoom'] = DEFAULTS['ui_zoom']

            ff = data.get('font_family', DEFAULTS['font_family'])
            if not isinstance(ff, str):
                data['font_family'] = DEFAULTS['font_family']

            return {**DEFAULTS, **data}
        except Exception:
            pass
    return dict(DEFAULTS)


def scale_stylesheet(css, family, size, zoom):
    """Return ``css`` with the font-family swapped to ``family`` and every
    ``font-size: Npx`` scaled by the combined zoom x size factor."""
    total_factor = (zoom / 100.0) * (size / 11.0)

    css = re.sub(r"font-family:\s*[^;]+;",
                 f"font-family: '{family}', sans-serif;", css)

    def _scale(match):
        val = int(match.group(1))
        return f"font-size: {max(8, int(round(val * total_factor)))}px"

    return re.sub(r"font-size:\s*(\d+)\s*px", _scale, css)
