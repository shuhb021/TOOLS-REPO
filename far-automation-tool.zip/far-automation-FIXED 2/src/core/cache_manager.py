import hashlib
import json
import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class CacheManager:
    
    def __init__(self, cache_dir=".far_cache"):
        localappdata = os.environ.get('LOCALAPPDATA', '')
        self.cache_dir = Path(localappdata) / 'FAR_Automation' / cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_hash(self, file_paths, params=None):
        hasher = hashlib.sha256()
        for fp in sorted(file_paths):
            if os.path.exists(fp):
                stat = os.stat(fp)
                hasher.update(f"{fp}_{stat.st_size}_{stat.st_mtime}".encode('utf-8'))
                try:
                    with open(fp, 'rb') as f:
                        while chunk := f.read(1024 * 1024):
                            hasher.update(chunk)
                except Exception as e:
                    logger.warning("Cache hash failed for %s: %s", fp, e)
                    
        if params:
            if isinstance(params, dict):
                hasher.update(str(sorted(params.items())).encode('utf-8'))
            else:
                hasher.update(str(params).encode('utf-8'))
            
        return hasher.hexdigest()
    
    def get(self, cache_key):
        import time
        cache_file = self.cache_dir / f"{cache_key}.json"
        if cache_file.exists():
            if time.time() - os.path.getmtime(cache_file) > 7 * 24 * 3600:
                try: os.remove(cache_file)
                except OSError: pass
                return None
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    logger.info("Cache hit for %s — Returning instantly.", cache_key)
                    return json.load(f)
            except Exception as e:
                logger.warning("Failed to read cache: %s", e)
        return None

    def set(self, cache_key, data):
        cache_file = self.cache_dir / f"{cache_key}.json"
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, default=str)
                logger.info("Data cached to %s", cache_file)
        except Exception as e:
            logger.warning("Failed to write cache: %s", e)

