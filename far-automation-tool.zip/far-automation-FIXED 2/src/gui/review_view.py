"""
review_view.py
==============

Manual Review & Correction Mode page.

Shown in the main panel (as a stacked page) whenever the automatic note
extraction cannot confidently match one or more notes. It lets the auditor:

  * see every note flagged for review (not found / mismatch / low confidence)
  * browse the original Excel sheets in a grid (row numbers + column letters)
  * select a single cell, multiple cells, a full row, or a range
  * preview the selected data (count + sum)
  * map the selection to the target template field (CY or PY)
  * optionally save the correction as a reusable rule
  * confirm, which regenerates only the affected notes and continues the run
"""

import re
import logging

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QTableWidget, QTableWidgetItem, QListWidget, QListWidgetItem, QFrame,
    QGroupBox, QCheckBox, QAbstractItemView, QMessageBox, QSlider
)
from PyQt6.QtCore import Qt, QEvent, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QBrush

from src.core.template_mapper import (
    MappingStore, normalize_name, TIER_MANUAL, TIER_WARNING,
)
from src.gui.worker_threads import SheetLoaderWorker

logger = logging.getLogger(__name__)

_TIER_ICON = {
    TIER_MANUAL: '🔴',
    TIER_WARNING: '🟠',
    'AUTO': '🟢',
}


def _is_note_sheet(name):
    """True only for NOTE sheets — BS / PL / cover / dashboard / ratio are excluded
    so the template-match review works on notes sheets only."""
    low = str(name).strip().lower()
    if any(x in low for x in ('bs', 'balance sheet', 'pl', 'p&l', 'profit')):
        return False
    if low in ('dashboard', 'ratios', 'ratio analysis', 'cover page', 'cover', 'index'):
        return False
    return bool(re.search(r'\d', str(name)) or 'note' in low or 'sch' in low)


def _to_float(text):
    if text is None:
        return None
    s = str(text).strip().replace(',', '').replace(' ', '')
    if not s:
        return None
    neg = False
    if s.startswith('(') and s.endswith(')'):
        neg = True
        s = s[1:-1]
    for sym in ('₹', '$', '£', '€', 'Rs.', 'Rs'):
        s = s.replace(sym, '')
    try:
        v = float(s)
        return -v if neg else v
    except (TypeError, ValueError):
        return None


class ReviewView(QWidget):

    # Emitted when the user confirms corrections. Payload: overrides dict
    # {mapping_index(str): {'cy':float|None, 'py':float|None, 'source':str, ...}}
    correctionsConfirmed = pyqtSignal(dict)
    # Emitted when the user chooses to proceed without corrections.
    reviewSkipped = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._review_items = []
        self._note_mapping = []
        self._list_rows = []      # maps each visible list row -> ('item', obj) | ('summary', None)
        self._overrides = {}
        self._grids = {}
        self._source_file = ''
        self._loader = None
        self._pending_highlight = None
        self._zoom = 100            # magnification percent (50-300)
        self._base_font_pt = 10
        self._suggested = (None, None)   # (cy, py) BS/PL total suggested for a Total line
        self._store = MappingStore()
        self._setup_ui()

    # ------------------------------------------------------------------ UI
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 16, 24, 16)
        layout.setSpacing(10)

        title = QLabel('🔍 Manual Review & Correction')
        title.setObjectName('headingLabel')
        layout.addWidget(title)

        self.subtitle = QLabel(
            'Only notes that still need attention are listed. Pick a flagged line, '
            'view its full sheet, select the correct cells and map them to the template.')
        self.subtitle.setObjectName('mutedLabel')
        self.subtitle.setWordWrap(True)
        layout.addWidget(self.subtitle)

        body = QHBoxLayout()
        body.setSpacing(12)

        # ---- Left: list of flagged notes + target details ----
        left = QVBoxLayout()
        left.setSpacing(8)

        lbl = QLabel('Notes needing review')
        lbl.setObjectName('subheadingLabel')
        left.addWidget(lbl)

        self.notes_list = QListWidget()
        self.notes_list.setMinimumWidth(320)
        self.notes_list.setMaximumWidth(360)
        self.notes_list.currentRowChanged.connect(self._on_item_selected)
        left.addWidget(self.notes_list, 1)

        self.target_box = QGroupBox('Target template field')
        tb = QVBoxLayout(self.target_box)
        self.target_label = QLabel('Select a note on the left.')
        self.target_label.setWordWrap(True)
        tb.addWidget(self.target_label)

        self.apply_suggestion_btn = QPushButton('✓ Use suggested BS/PL total')
        self.apply_suggestion_btn.setToolTip(
            'Fill this Total from the BS/PL figure (already cross-checked against the note).')
        self.apply_suggestion_btn.clicked.connect(self._apply_suggestion)
        self.apply_suggestion_btn.setVisible(False)
        tb.addWidget(self.apply_suggestion_btn)

        left.addWidget(self.target_box)

        body.addLayout(left)

        # ---- Right: sheet grid + selection tools ----
        right = QVBoxLayout()
        right.setSpacing(8)

        sheet_row = QHBoxLayout()
        sheet_row.addWidget(QLabel('Source sheet:'))
        self.sheet_combo = QComboBox()
        self.sheet_combo.setMinimumWidth(220)
        self.sheet_combo.currentTextChanged.connect(self._populate_grid)
        sheet_row.addWidget(self.sheet_combo)
        sheet_row.addStretch()

        # --- Magnification / zoom controls for the grid ---
        sheet_row.addWidget(QLabel('🔍 Zoom:'))
        self.zoom_out_btn = QPushButton('➖')
        self.zoom_out_btn.setObjectName('zoomBtn')
        self.zoom_out_btn.setFixedSize(30, 28)
        self.zoom_out_btn.setToolTip('Zoom out')
        self.zoom_out_btn.clicked.connect(lambda: self._set_zoom(self._zoom - 10))
        sheet_row.addWidget(self.zoom_out_btn)

        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setMinimum(50)
        self.zoom_slider.setMaximum(300)
        self.zoom_slider.setValue(self._zoom)
        self.zoom_slider.setFixedWidth(140)
        self.zoom_slider.valueChanged.connect(self._set_zoom)
        sheet_row.addWidget(self.zoom_slider)

        self.zoom_in_btn = QPushButton('➕')
        self.zoom_in_btn.setObjectName('zoomBtn')
        self.zoom_in_btn.setFixedSize(30, 28)
        self.zoom_in_btn.setToolTip('Zoom in')
        self.zoom_in_btn.clicked.connect(lambda: self._set_zoom(self._zoom + 10))
        sheet_row.addWidget(self.zoom_in_btn)

        self.zoom_label = QLabel('100%')
        self.zoom_label.setFixedWidth(48)
        sheet_row.addWidget(self.zoom_label)

        self.zoom_reset_btn = QPushButton('↺ Reset')
        self.zoom_reset_btn.setObjectName('secondaryButton')
        self.zoom_reset_btn.setToolTip('Reset zoom to 100%')
        self.zoom_reset_btn.clicked.connect(lambda: self._set_zoom(100))
        sheet_row.addWidget(self.zoom_reset_btn)

        self.loading_label = QLabel('')
        self.loading_label.setObjectName('mutedLabel')
        sheet_row.addWidget(self.loading_label)
        right.addLayout(sheet_row)

        self.grid = QTableWidget()
        self.grid.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.grid.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.grid.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.grid.itemSelectionChanged.connect(self._on_grid_selection_changed)
        self.grid.viewport().installEventFilter(self)  # Ctrl+wheel to zoom
        right.addWidget(self.grid, 1)

        # selection preview + apply controls
        prev_frame = QFrame()
        prev_frame.setObjectName('cardFrame')
        prev = QHBoxLayout(prev_frame)
        prev.setContentsMargins(12, 8, 12, 8)
        self.preview_label = QLabel('Selected: 0 cells')
        self.preview_label.setObjectName('mutedLabel')
        prev.addWidget(self.preview_label)
        prev.addStretch()

        self.reuse_cb = QCheckBox('Save as reusable rule')
        self.reuse_cb.setChecked(True)
        prev.addWidget(self.reuse_cb)

        self.apply_cy_btn = QPushButton('Apply → CY')
        self.apply_cy_btn.clicked.connect(lambda: self._apply_to('cy'))
        prev.addWidget(self.apply_cy_btn)

        self.apply_py_btn = QPushButton('Apply → PY')
        self.apply_py_btn.clicked.connect(lambda: self._apply_to('py'))
        prev.addWidget(self.apply_py_btn)

        right.addWidget(prev_frame)
        body.addLayout(right, 1)

        layout.addLayout(body, 1)

        # ---- Bottom action bar ----
        bottom = QHBoxLayout()
        self.summary_label = QLabel('')
        self.summary_label.setObjectName('mutedLabel')
        bottom.addWidget(self.summary_label)
        bottom.addStretch()

        self.skip_btn = QPushButton('Proceed Without Corrections')
        self.skip_btn.setObjectName('secondaryButton')
        self.skip_btn.clicked.connect(self._on_skip)
        bottom.addWidget(self.skip_btn)

        self.confirm_btn = QPushButton('✓ Confirm Corrections & Regenerate')
        self.confirm_btn.setFixedHeight(40)
        self.confirm_btn.setFont(QFont('Segoe UI', 12, QFont.Weight.Bold))
        self.confirm_btn.clicked.connect(self._on_confirm)
        bottom.addWidget(self.confirm_btn)

        layout.addLayout(bottom)

    # --------------------------------------------------------------- data
    def set_data(self, review_items, note_mapping, source_file, grids=None):
        """Populate the panel. ``grids`` may be pre-loaded; otherwise the
        source workbook is read on a background thread."""
        self._review_items = review_items or []
        self._note_mapping = note_mapping or []
        self._source_file = source_file or ''
        self._overrides = {}

        self._populate_notes_list()
        self._update_summary()

        if grids:
            self._set_grids({'sheets': list(grids.keys()), 'grids': grids})
        elif source_file:
            self.loading_label.setText('⏳ Loading sheets…')
            self._loader = SheetLoaderWorker(source_file)
            self._loader.loaded.connect(self._set_grids)
            self._loader.error.connect(self._on_loader_error)
            self._loader.start()

    def _populate_notes_list(self):
        """Show ONLY the notes that still need attention. Sections where every
        template line is already matched are hidden entirely — the panel is a
        problem list, not a full inventory. When nothing needs review a single
        'all matched' line is shown."""
        from collections import OrderedDict
        self.notes_list.clear()
        self._list_rows = []

        groups = OrderedDict()
        for it in self._review_items:
            sec = it.get('section', it.get('note_num', '?'))
            groups.setdefault(sec, []).append(it)

        any_problem = False
        for section, its in groups.items():
            unmatched = [x for x in its if not x.get('template_matched')]
            if not unmatched:
                continue                      # fully matched -> hidden

            any_problem = True
            matched_n = len(its) - len(unmatched)
            hdr_txt = f"🟠  {section}  —  {len(unmatched)} line(s) need filling"
            if matched_n:
                hdr_txt += f"  ({matched_n} ok)"
            hdr = QListWidgetItem(hdr_txt)
            hdr.setForeground(QBrush(QColor('#92400E')))
            f = hdr.font()
            f.setBold(True)
            hdr.setFont(f)
            self.notes_list.addItem(hdr)
            self._list_rows.append(('summary', None))

            for x in unmatched:
                part = x.get('particular', x.get('bs_particular', ''))
                li = QListWidgetItem(f"        🔴  {part}")
                li.setForeground(QBrush(QColor('#991B1B')))
                self.notes_list.addItem(li)
                self._list_rows.append(('item', x))

        if not any_problem:
            n = len(self._review_items)
            row = QListWidgetItem(f"✓  All {n} template line(s) matched — nothing to review")
            row.setForeground(QBrush(QColor('#166534')))
            fnt = row.font()
            fnt.setBold(True)
            row.setFont(fnt)
            self.notes_list.addItem(row)
            self._list_rows.append(('summary', None))

        # Select the first actionable (red) line, else the first row.
        first_item = next((i for i, (t, _) in enumerate(self._list_rows) if t == 'item'), None)
        if first_item is not None:
            self.notes_list.setCurrentRow(first_item)
        elif self._list_rows:
            self.notes_list.setCurrentRow(0)

    def _set_grids(self, payload):
        self.loading_label.setText('')
        all_grids = payload.get('grids', {})
        all_sheets = payload.get('sheets', list(all_grids.keys()))
        # Notes sheets only — exclude BS / PL / cover / dashboard / ratio.
        note_sheets = [s for s in all_sheets if _is_note_sheet(s)]
        if not note_sheets:
            note_sheets = all_sheets  # fallback: never leave the panel empty
        self._grids = {s: all_grids[s] for s in note_sheets if s in all_grids}
        sheets = note_sheets
        self.sheet_combo.blockSignals(True)
        self.sheet_combo.clear()
        self.sheet_combo.addItems(sheets)
        self.sheet_combo.blockSignals(False)

        # Prefer a notes-looking sheet for the first selected item.
        preferred = self._guess_sheet_for_current()
        if preferred and preferred in sheets:
            self.sheet_combo.setCurrentText(preferred)
        elif sheets:
            self.sheet_combo.setCurrentText(sheets[0])
        self._populate_grid(self.sheet_combo.currentText())
        # Grids are now available: (re)apply the current note's locate+highlight
        # (the list may have selected an item before the sheets finished loading).
        if self.notes_list.currentRow() >= 0:
            self._on_item_selected(self.notes_list.currentRow())

    def _on_loader_error(self, msg):
        self.loading_label.setText('')
        QMessageBox.warning(self, 'Could not load sheets',
                            f'Failed to read the source workbook:\n\n{msg}')

    def _guess_sheet_for_current(self):
        for name in self._grids.keys():
            low = name.lower()
            if 'note' in low or 'sch' in low or any(ch.isdigit() for ch in low):
                return name
        return None

    def _populate_grid(self, sheet_name):
        grid = self._grids.get(sheet_name)
        self.grid.clear()
        if not grid:
            self.grid.setRowCount(0)
            self.grid.setColumnCount(0)
            return
        rows = grid['rows']
        n_cols = grid['n_cols']
        self.grid.setRowCount(len(rows))
        self.grid.setColumnCount(n_cols)
        self.grid.setHorizontalHeaderLabels(grid['col_letters'])
        row_numbers = grid.get('row_numbers') or [i + 1 for i in range(len(rows))]
        self.grid.setVerticalHeaderLabels([str(n) for n in row_numbers])
        right_align = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        self.grid.setUpdatesEnabled(False)
        for r, cells in enumerate(rows):
            for c in range(n_cols):
                raw = cells[c] if c < len(cells) else ''
                val = '' if raw is None else str(raw)
                item = QTableWidgetItem(val)
                if _to_float(val) is not None:
                    item.setTextAlignment(right_align)
                self.grid.setItem(r, c, item)
        self.grid.setUpdatesEnabled(True)
        self._apply_zoom()
        self._apply_pending_highlight()
        self._on_grid_selection_changed()

    def eventFilter(self, obj, event):
        if obj is self.grid.viewport() and event.type() == QEvent.Type.Wheel:
            if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
                step = 10 if event.angleDelta().y() > 0 else -10
                self._set_zoom(self._zoom + step)
                return True
        return super().eventFilter(obj, event)

    def _set_zoom(self, value):
        """Set grid magnification (50%-300%)."""
        value = max(50, min(300, int(value)))
        self._zoom = value
        if self.zoom_slider.value() != value:
            self.zoom_slider.blockSignals(True)
            self.zoom_slider.setValue(value)
            self.zoom_slider.blockSignals(False)
        self.zoom_label.setText(f'{value}%')
        self._apply_zoom()

    def _apply_zoom(self):
        """Scale the grid font, row heights and column widths to the zoom %."""
        factor = self._zoom / 100.0
        pt = max(6, int(round(self._base_font_pt * factor)))
        font = QFont('Segoe UI', pt)
        self.grid.setFont(font)
        self.grid.horizontalHeader().setFont(font)
        self.grid.verticalHeader().setFont(font)
        row_h = max(16, int(round(22 * factor)))
        self.grid.verticalHeader().setDefaultSectionSize(row_h)
        for r in range(self.grid.rowCount()):
            self.grid.setRowHeight(r, row_h)
        self.grid.resizeColumnsToContents()

    # ---------------------------------------------------------- selection
    def _selected_numbers(self):
        vals = []
        refs = []
        for item in self.grid.selectedItems():
            f = _to_float(item.text())
            if f is not None:
                vals.append(f)
                col_letter = self.grid.horizontalHeaderItem(item.column())
                cl = col_letter.text() if col_letter else str(item.column() + 1)
                row_hdr = self.grid.verticalHeaderItem(item.row())
                rn = row_hdr.text() if row_hdr else str(item.row() + 1)
                refs.append(f"{cl}{rn}")
        return vals, refs

    def _on_grid_selection_changed(self):
        vals, refs = self._selected_numbers()
        total_sel = len(self.grid.selectedItems())
        if not vals:
            self.preview_label.setText(f'Selected: {total_sel} cells (no numeric values)')
        else:
            s = sum(vals)
            sheet = self.sheet_combo.currentText()
            ref_str = f'{sheet}!{refs[0]}' if len(refs) == 1 else f'{sheet}!{refs[0]}…{refs[-1]}'
            self.preview_label.setText(
                f'Selected: {total_sel} cells  |  {len(vals)} numeric  |  Sum = {s:,.2f}  |  {ref_str}')

    def _current_review_item(self):
        row = self.notes_list.currentRow()
        if 0 <= row < len(self._list_rows):
            kind, obj = self._list_rows[row]
            if kind == 'item':
                return obj
        return None

    def _on_item_selected(self, _row):
        it = self._current_review_item()
        if not it:
            self.target_label.setText('Select a note on the left.')
            return
        ov = self._overrides.get(str(it.get('_index')), {})
        ov_txt = ''
        if ov:
            ov_txt = (f"\n\nPending override → CY: {ov.get('cy', '—')} | "
                      f"PY: {ov.get('py', '—')}")

        # For a Total line that was found in BS/PL but not in the note, show the
        # BS/PL figure as a suggestion the user can apply with one click.
        sug_txt = ''
        sug_cy = it.get('suggested_cy')
        sug_py = it.get('suggested_py')
        if sug_cy is not None or sug_py is not None:
            sug_txt = (f"\n\n💡 Suggested from BS/PL → CY: {sug_cy if sug_cy is not None else '—'} | "
                       f"PY: {sug_py if sug_py is not None else '—'}")
        self._suggested = (sug_cy, sug_py)
        self.apply_suggestion_btn.setVisible(sug_cy is not None or sug_py is not None)

        self.target_label.setText(
            f"Template section: {it.get('section', it.get('note_num', ''))}\n"
            f"Template line: {it.get('particular', it.get('bs_particular', ''))}\n"
            f"Template sheet: {it.get('sheet', '-')}  (row {it.get('row', '-')})\n"
            f"Current value  CY: {it.get('value_cy', it.get('bs_cy', '-'))}   "
            f"PY: {it.get('value_py', it.get('bs_py', '-'))}\n"
            f"Status: {it.get('review_reason', '')}"
            f"{sug_txt}"
            f"{ov_txt}")

        # Jump to and highlight the matching section in the source workbook so
        # the user can see the full sheet and select the correct cells.
        loc = self._find_note_location(
            it.get('section', it.get('note_num', '')),
            it.get('particular', it.get('bs_particular', '')))
        if loc:
            self._pending_highlight = loc
            if self.sheet_combo.currentText() == loc['sheet']:
                self._populate_grid(loc['sheet'])   # rebuild + re-apply highlight
            else:
                self.sheet_combo.setCurrentText(loc['sheet'])  # triggers _populate_grid
        else:
            self._pending_highlight = None
            preferred = self._guess_sheet_for_current()
            if preferred and self.sheet_combo.currentText() != preferred:
                self.sheet_combo.setCurrentText(preferred)
            elif self.sheet_combo.currentText():
                self._populate_grid(self.sheet_combo.currentText())

    def _find_note_location(self, note_num, particular):
        """Locate the sheet + row range of a note's block across all grids.

        Matches a heading like ``Note 3``/``Note-3``/``Note No. 3`` first, then
        falls back to a row whose normalised text contains the BS particular.
        Returns ``{'sheet', 'row', 'end'}`` (0-based rows) or ``None``.
        """
        nn = str(note_num or '').strip()
        heading_re = re.compile(r'\bnote\s*[-:.]?\s*0*' + re.escape(nn) + r'\b', re.I) if nn else None
        part_norm = normalize_name(particular)
        sec_norm = normalize_name(nn)
        any_note_re = re.compile(r'\bnote\s*[-:.]?\s*\d', re.I)

        for sheet, grid in self._grids.items():
            rows = grid['rows']
            for r, cells in enumerate(rows):
                joined = ' '.join(str(c) for c in cells if c)
                if not joined:
                    continue
                matched = False
                if heading_re and heading_re.search(joined):
                    matched = True
                else:
                    for c in cells:
                        cn = normalize_name(c)
                        if not cn:
                            continue
                        if part_norm and len(part_norm) > 4 and (part_norm in cn or cn in part_norm):
                            matched = True
                            break
                        if sec_norm and len(sec_norm) > 4 and (sec_norm in cn or cn in sec_norm):
                            matched = True
                            break
                if not matched:
                    continue
                # Block ends just before the next "Note N" heading.
                end = len(rows) - 1
                for r2 in range(r + 1, len(rows)):
                    j2 = ' '.join(str(c) for c in rows[r2] if c)
                    if any_note_re.search(j2):
                        end = r2 - 1
                        break
                return {'sheet': sheet, 'row': r, 'end': end}
        return None

    def _apply_pending_highlight(self):
        h = self._pending_highlight
        if not h or h.get('sheet') != self.sheet_combo.currentText():
            return
        start = h['row']
        end = min(h['end'], self.grid.rowCount() - 1)
        for r in range(start, end + 1):
            bg = QColor('#FDE68A') if r == start else QColor('#FEF3C7')
            for c in range(self.grid.columnCount()):
                cell = self.grid.item(r, c)
                if cell:
                    cell.setBackground(QBrush(bg))
        target = self.grid.item(start, 0)
        if target:
            self.grid.scrollToItem(
                target, QAbstractItemView.ScrollHint.PositionAtTop)

    def _apply_suggestion(self):
        """Apply the BS/PL-derived total suggestion to the selected Total line."""
        it = self._current_review_item()
        if not it:
            return
        sug_cy, sug_py = self._suggested
        if sug_cy is None and sug_py is None:
            return
        idx = str(it.get('_index'))
        ov = self._overrides.get(idx, {})
        if sug_cy is not None:
            ov['cy'] = sug_cy
        if sug_py is not None:
            ov['py'] = sug_py
        ov['source'] = 'BS/PL total'
        ov['source_row'] = 'BS/PL total'
        self._overrides[idx] = ov
        self._on_item_selected(self.notes_list.currentRow())
        self._update_summary()
        logger.info("Applied BS/PL total suggestion for '%s': CY=%s PY=%s",
                    it.get('bs_particular'), sug_cy, sug_py)

    def _apply_to(self, field):
        it = self._current_review_item()
        if not it:
            QMessageBox.information(self, 'No note selected',
                                    'Select a note to correct on the left first.')
            return
        vals, refs = self._selected_numbers()
        if not vals:
            QMessageBox.information(self, 'No numeric selection',
                                    'Select one or more cells containing numbers.')
            return
        value = sum(vals)
        sheet = self.sheet_combo.currentText()
        source = f"{sheet}!{refs[0]}" if len(refs) == 1 else f"{sheet}!{refs[0]}…{refs[-1]}"

        idx = str(it.get('_index'))
        ov = self._overrides.get(idx, {})
        ov[field] = value
        ov['source'] = source
        ov['source_row'] = source
        self._overrides[idx] = ov

        self._on_item_selected(self.notes_list.currentRow())
        self._update_summary()
        logger.info("Queued manual override: Note %s '%s' %s=%s from %s",
                    it.get('note_num'), it.get('bs_particular'), field.upper(), value, source)

    def _update_summary(self):
        n_total = len(self._review_items)
        n_matched = sum(1 for it in self._review_items if it.get('template_matched'))
        n_fixed = len(self._overrides)
        self.summary_label.setText(
            f'{n_matched} of {n_total} template lines populated'
            + (f'  |  {n_fixed} filled this session' if n_fixed else ''))

    # ------------------------------------------------------------- actions
    def _on_confirm(self):
        if not self._overrides:
            res = QMessageBox.question(
                self, 'No corrections made',
                'You have not applied any corrections. Proceed anyway?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if res != QMessageBox.StandardButton.Yes:
                return

        # Persist reusable rules where requested.
        if self.reuse_cb.isChecked():
            for idx_str, ov in self._overrides.items():
                try:
                    it = self._review_items[
                        next(i for i, x in enumerate(self._review_items)
                             if str(x.get('_index')) == idx_str)]
                except StopIteration:
                    continue
                self._store.put(it.get('note_num', ''), it.get('bs_particular', ''), ov)

        self.correctionsConfirmed.emit(dict(self._overrides))

    def _on_skip(self):
        self.reviewSkipped.emit()
