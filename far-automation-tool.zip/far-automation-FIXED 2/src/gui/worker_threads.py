"""
worker_threads.py
=================

Background QThread workers used by the GUI so that workbook scanning and other
slow IO never run on the UI thread (prevents the "Not Responding" freeze).

Currently hosts:
    * SheetLoaderWorker  - reads every VISIBLE sheet of a workbook into a plain
      grid structure for the Manual Review panel, using the dedicated
      ``visible_data_engine`` so the grid shows ONLY human-visible data (hidden
      rows/cols/sheets, ``;;;`` number formats and white-on-white text are all
      dropped) and matches exactly what the parser extracts.
"""

import logging

from PyQt6.QtCore import QThread, pyqtSignal

from src.core.visible_data_engine import load_visible_workbook

logger = logging.getLogger(__name__)


class SheetLoaderWorker(QThread):
    """Load a workbook's visible sheets into memory off the UI thread.

    Emits ``loaded`` with::

        {
            'sheets': ['BS', 'PL', 'Notes', ...],
            'grids': {
                'Notes': {
                    'col_letters': ['A', 'B', ...],
                    'row_numbers': [1, 2, 4, ...],   # real Excel rows (hidden skipped)
                    'rows': [['Particulars', '100'], ...],
                    'n_rows': int,
                    'n_cols': int,
                }
            }
        }
    """

    loaded = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, filepath, parent=None):
        super().__init__(parent)
        self.filepath = filepath

    def run(self):
        try:
            payload = load_visible_workbook(self.filepath)
            self.loaded.emit(payload)
        except Exception as e:  # noqa: BLE001
            logger.error("SheetLoaderWorker failed for %s: %s",
                         self.filepath, e, exc_info=True)
            self.error.emit(str(e))
