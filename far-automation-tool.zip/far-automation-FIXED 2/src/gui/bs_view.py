
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLabel, QHeaderView, QFrame, QPushButton
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QBrush

class AnalysisTableView(QWidget):

    # Emitted when the user clicks "Reload" — the window re-runs Engine 2
    # (verify + finalise) on the current data and refreshes the view. Inherited
    # by both BSView and PLView.
    reloadRequested = pyqtSignal()

    def __init__(self, title, date_prefix='As at', parent=None):
        super().__init__(parent)
        self.title = title
        self.date_prefix = date_prefix
        self.data = []
        self.remarks = {}
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 16, 24, 16)
        layout.setSpacing(12)
        
        header_frame = QFrame()
        header_frame.setObjectName('cardFrame')
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(16, 12, 16, 12)
        
        left_layout = QVBoxLayout()
        
        self.client_label = QLabel('Client: —')
        self.client_label.setObjectName('clientInfoLabel')
        left_layout.addWidget(self.client_label)
        
        self.title_label = QLabel(self.title)
        self.title_label.setObjectName('subheadingLabel')
        left_layout.addWidget(self.title_label)
        
        self.period_label = QLabel('')
        self.period_label.setObjectName('mutedLabel')
        left_layout.addWidget(self.period_label)
        
        self.scope_label = QLabel('Scope: All variances above TE and (+/-) 10% selected')
        self.scope_label.setObjectName('mutedLabel')
        left_layout.addWidget(self.scope_label)
        
        header_layout.addLayout(left_layout)
        header_layout.addStretch()
        
        right_layout = QVBoxLayout()
        legends_title = QLabel('Legends')
        legends_title.setObjectName('legendTitle')
        right_layout.addWidget(legends_title)
        
        legends = [
            ('a', 'Traced to Financials CY'),
            ('b', 'Traced to Financials PY'),
            ('e', 'Recomputed'),
        ]
        for key, desc in legends:
            row = QHBoxLayout()
            k = QLabel(key)
            k.setObjectName('legendKey')
            d = QLabel(f'= {desc}')
            d.setObjectName('legendDesc')
            row.addWidget(k)
            row.addWidget(d)
            row.addStretch()
            right_layout.addLayout(row)
        
        header_layout.addLayout(right_layout)
        layout.addWidget(header_frame)
        
        stats_frame = QFrame()
        stats_layout = QHBoxLayout(stats_frame)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        
        self.total_label = QLabel('Total items: 0')
        self.total_label.setObjectName('mutedLabel')
        stats_layout.addWidget(self.total_label)
        
        self.flagged_label = QLabel('Flagged (≥10%): 0')
        self.flagged_label.setObjectName('flaggedLabel')
        stats_layout.addWidget(self.flagged_label)
        
        stats_layout.addStretch()

        self.unit_label = QLabel('')
        self.unit_label.setObjectName('mutedLabel')
        stats_layout.addWidget(self.unit_label)

        self.reload_btn = QPushButton('🔄 Reload')
        self.reload_btn.setObjectName('reloadBtn')
        self.reload_btn.setToolTip(
            'Recalculate & verify these figures with Engine 2 (independent verifier)')
        self.reload_btn.setFixedHeight(28)
        self.reload_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reload_btn.clicked.connect(self.reloadRequested.emit)
        stats_layout.addWidget(self.reload_btn)

        layout.addWidget(stats_frame)
        
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            'Particulars', 'Note No.', 'CY (b)', 'PY (a)',
            'Var. Abs (e)', 'Var. % (e)', 'Remarks'
        ])
        
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(1, 80)
        self.table.setColumnWidth(2, 130)
        self.table.setColumnWidth(3, 130)
        self.table.setColumnWidth(4, 130)
        self.table.setColumnWidth(5, 100)
        self.table.setColumnWidth(6, 280)
        
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)
        
        layout.addWidget(self.table)
    
    def load_data(self, data, client_name='', cy_year=None, py_year=None,
                  rounding_unit='Lakhs', remarks=None):
        self.data = data
        self.remarks = remarks or {}

        self.client_label.setText(f'Client: {client_name}')
        self.rounding_unit = rounding_unit
        if cy_year and py_year:
            self.period_label.setText(
                f'{self.date_prefix} 31 March {cy_year} vs 31 March {py_year}')
        self.unit_label.setText(f'(Rs. in {rounding_unit})')

        # Show ONLY the analysis rows. The split-off footer/signature/note rows
        # are intentionally NOT rendered here so the UI matches the exported
        # sheet (which also omits them).
        self.table.setRowCount(len(data))

        # Suspend repaints + reuse one bold font/brushes across all cells, instead
        # of repainting and allocating per cell, while filling the table.
        self.table.setUpdatesEnabled(False)
        bold_font = QFont('Segoe UI', 11, QFont.Weight.Bold)
        bold_bg = QBrush(QColor('#F5F0FA'))
        flag_bg = QBrush(QColor('#EAB308'))
        black = QBrush(QColor('#000000'))
        green = QBrush(QColor('#22C55E'))
        red = QBrush(QColor('#EF4444'))
        right_align = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter

        flagged_count = 0
        for i, row in enumerate(data):
            flag = row.get('flag', False)
            is_bold = row.get('is_bold', False)
            if flag:
                flagged_count += 1
            
            cy_raw = row.get('cy')
            py_raw = row.get('py')
            var_raw = row.get('variance_abs')
            disp_pct = row.get('display_pct', '')

            cy_is_zero = cy_raw in (None, 0, 0.0, '-')
            py_is_zero = py_raw in (None, 0, 0.0, '-')
            if cy_is_zero and py_is_zero:
                disp_pct = '-'

            items = [
                row.get('particulars', ''),
                str(row.get('note', '')),
                self._format_number(cy_raw),
                self._format_number(py_raw),
                self._format_number(var_raw),
                disp_pct,
            ]
            
            for j, val in enumerate(items):
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                
                if is_bold:
                    item.setFont(bold_font)
                    item.setBackground(bold_bg)

                if flag:
                    item.setBackground(flag_bg)
                    item.setForeground(black)

                if j == 5:
                    pct = row.get('variance_pct', 0)
                    if isinstance(pct, (int, float)):
                        if pct > 0:
                            item.setForeground(green)
                        elif pct < 0:
                            item.setForeground(red)
                        if flag:
                            item.setForeground(black)

                if j >= 2:
                    item.setTextAlignment(right_align)

                self.table.setItem(i, j, item)

            remark_text = self.remarks.get(i, row.get('remark', ''))
            remark_item = QTableWidgetItem(str(remark_text))
            self.table.setItem(i, 6, remark_item)

        self.table.setUpdatesEnabled(True)
        self.total_label.setText(f'Total items: {len(data)}')
        self.flagged_label.setText(f'Flagged (≥10%): {flagged_count}')
    
    def _format_number(self, value):
        if value is None:
            return '-NA-'
        if value == '-':
            return '-'
        try:
            v = float(value)
            if v == 0:
                return '-'
            # 2 decimals for every rounding unit (Crore/Thousands were being
            # over-rounded to whole numbers).
            return f'{v:,.2f}'
        except (ValueError, TypeError):
            return str(value)
    
    def update_remark(self, row_idx, text):
        if 0 <= row_idx < self.table.rowCount():
            item = self.table.item(row_idx, 6)
            if item:
                item.setText(text)
            else:
                self.table.setItem(row_idx, 6, QTableWidgetItem(text))

class BSView(AnalysisTableView):
    
    def __init__(self, parent=None):
        super().__init__(
            title='Analysis of Balance Sheet',
            date_prefix='As at',
            parent=parent
        )

class PLView(AnalysisTableView):
    
    def __init__(self, parent=None):
        super().__init__(
            title='Analysis of Statement of Profit and Loss',
            date_prefix='For the Year ended',
            parent=parent
        )

