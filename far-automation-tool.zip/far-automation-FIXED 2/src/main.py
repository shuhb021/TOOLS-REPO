
import sys
import os
import logging
from datetime import datetime

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPalette, QColor, QFont

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def setup_logging():
    log_dir = os.path.join(project_root, 'logs')
    os.makedirs(log_dir, exist_ok=True)

    log_file = os.path.join(log_dir, 'far_app.log')

    # Make console output UTF-8 safe so logging ₹ / unicode / emoji never crashes
    # on a cp1252 Windows console.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    logger = logging.getLogger(__name__)
    logger.info("=" * 60)
    logger.info("FAR Automation Tool started at %s", datetime.now().isoformat())
    logger.info("Python %s", sys.version)
    logger.info("App started")
    return logger

def load_stylesheet():
    qss_path = resource_path(os.path.join('src', 'assets', 'styles.qss'))
    if os.path.exists(qss_path):
        with open(qss_path, 'r', encoding='utf-8') as f:
            css = f.read()
        # Inject absolute path to the checkbox tick icon (Qt QSS needs a real path).
        check_path = resource_path(os.path.join('src', 'assets', 'check.svg')).replace('\\', '/')
        css = css.replace('__CHECK_ICON__', check_path)
        return css
    return ''

def setup_light_palette(app):
    palette = QPalette()
    
    palette.setColor(QPalette.ColorRole.Window, QColor('#FFFFFF'))
    palette.setColor(QPalette.ColorRole.WindowText, QColor('#2D2D2D'))
    palette.setColor(QPalette.ColorRole.Base, QColor('#FFFFFF'))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor('#F9F7FC'))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor('#FFFFFF'))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor('#2D2D2D'))
    palette.setColor(QPalette.ColorRole.Text, QColor('#2D2D2D'))
    palette.setColor(QPalette.ColorRole.Button, QColor('#F0F0F0'))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor('#2D2D2D'))
    palette.setColor(QPalette.ColorRole.BrightText, QColor('#4A1A6B'))
    palette.setColor(QPalette.ColorRole.Link, QColor('#4A1A6B'))
    palette.setColor(QPalette.ColorRole.Highlight, QColor('#4A1A6B'))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor('#FFFFFF'))
    
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor('#AAAAAA'))
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor('#AAAAAA'))
    
    app.setPalette(palette)

def _start_import_prewarm(logger):
    import threading

    def _warm():
        try:
            import openpyxl          # noqa: F401  (~0.9s first import)
            import polars            # noqa: F401  (~0.7s first import)
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot  # noqa: F401  (~0.8s first import)
        except Exception as e:       # never let prewarming crash the app
            logger.debug("Import prewarm skipped: %s", e)

    threading.Thread(target=_warm, name='import-prewarm', daemon=True).start()

def main():
    from src.core.app_config import load_config, scale_stylesheet

    logger = setup_logging()

    config = load_config()
    
    app = QApplication(sys.argv)
    app.setApplicationName('FAR Automation Tool')
    app.setApplicationVersion('2.3')
    app.setOrganizationName('FAR Automation')
    
    family = config['font_family']
    size = config['font_size']
    zoom = config['ui_zoom']

    scaled_size = int(round(size * (zoom / 100.0)))
    font = QFont(family, scaled_size)
    app.setFont(font)

    setup_light_palette(app)

    stylesheet = load_stylesheet()
    if stylesheet:
        try:
            stylesheet = scale_stylesheet(stylesheet, family, size, zoom)
        except Exception as e:
            logger.warning("Failed to scale QSS at startup: %s", e)

        app.setStyleSheet(stylesheet)
        logger.info("Scaled stylesheet loaded")
    
    def exception_handler(exc_type, exc_value, exc_tb):
        logger.critical("Unhandled exception", exc_info=(exc_type, exc_value, exc_tb))
        sys.__excepthook__(exc_type, exc_value, exc_tb)
    
    sys.excepthook = exception_handler
    
    from src.gui.main_window import MainWindow

    window = MainWindow()
    window.show()

    logger.info("Main window shown")

    # Warm the heavy libraries (openpyxl ~0.9s, polars ~0.7s, matplotlib ~0.8s)
    # on a background thread while the user fills in the form, so the first
    # Generate / Export doesn't pay that import tax on the UI thread.
    _start_import_prewarm(logger)

    exit_code = app.exec()
    
    logger.info("Application exiting with code %d", exit_code)
    sys.exit(exit_code)

if __name__ == '__main__':
    main()

